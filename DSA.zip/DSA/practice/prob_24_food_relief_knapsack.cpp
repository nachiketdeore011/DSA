/*
24. Problem:
A relief organization needs to distribute food packages to flood-affected areas using a limited-capacity truck.
Each package type has a weight and a benefit score (importance).
Write a C++ program to select the combination of packages that maximizes total benefit using the Fractional Knapsack greedy method.
Display:
- Each package selected and its fraction
- Total benefit obtained
- Total truck weight used
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

class FoodPackage
{
public:
    string packageName;
    double weight;
    double benefit;
    double ratio;

    FoodPackage(string name = "", double w = 0, double b = 0)
    {
        packageName = name;
        weight = w;
        benefit = b;
        ratio = (w != 0) ? (b / w) : 0;
    }
};

class FoodReliefKnapsack
{
    int n;
    double truckCapacity;
    vector<FoodPackage> packages;

public:
    void input()
    {
        cout << "Enter number of food package types: ";
        cin >> n;

        packages.resize(n);
        cout << "\nEnter details of each food package (Name, Weight in kg, Benefit Score):\n";
        for (int i = 0; i < n; i++)
        {
            string name;
            double w, b;
            cout << "Package " << i + 1 << " [Name Weight Benefit]: ";
            cin >> name >> w >> b;
            packages[i] = FoodPackage(name, w, b);
        }

        cout << "\nEnter maximum weight capacity of relief truck (in kg): ";
        cin >> truckCapacity;
    }

    void solve()
    {
        // Greedy Sort by Benefit / Weight ratio descending
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (packages[i].ratio < packages[j].ratio)
                {
                    swap(packages[i], packages[j]);
                }
            }
        }

        double totalTruckWeightUsed = 0.0;
        double totalBenefit = 0.0;

        cout << "\n================ RELIEF PACKAGE LOADING SUMMARY ================\n";
        cout << "Package Name\tWeight Taken\tFraction\tBenefit Obtained\n";
        cout << "----------------------------------------------------------------\n";

        for (int i = 0; i < n; i++)
        {
            if (totalTruckWeightUsed + packages[i].weight <= truckCapacity)
            {
                // Full package taken (fraction = 1.0)
                totalTruckWeightUsed += packages[i].weight;
                totalBenefit += packages[i].benefit;

                cout << packages[i].packageName << "\t\t"
                     << packages[i].weight << " kg\t\t"
                     << "1.0 (100%)\t"
                     << packages[i].benefit << endl;
            }
            else
            {
                // Partial package taken
                double remaining = truckCapacity - totalTruckWeightUsed;
                if (remaining > 0)
                {
                    double fraction = remaining / packages[i].weight;
                    double fractionalBenefit = fraction * packages[i].benefit;

                    totalTruckWeightUsed += remaining;
                    totalBenefit += fractionalBenefit;

                    cout << packages[i].packageName << "\t\t"
                         << remaining << " kg\t\t"
                         << fraction << " (" << fraction * 100.0 << "%)\t"
                         << fractionalBenefit << endl;
                }
                break; // Truck is full
            }
        }

        cout << "----------------------------------------------------------------\n";
        cout << "Total Truck Weight Used = " << totalTruckWeightUsed << " kg / " << truckCapacity << " kg\n";
        cout << "Total Benefit Obtained  = " << totalBenefit << endl;
        cout << "================================================================\n";
    }
};

int main()
{
    FoodReliefKnapsack relief;
    relief.input();
    relief.solve();

    return 0;
}

