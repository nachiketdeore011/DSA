/*
38. Representation of Flight Routes between Cities using Adjacency list
There are several cities connected by direct flights. If a flight exists between city A and city B, there is an edge between the corresponding nodes in the graph. The weight of the edge represents the time taken (in hours) or cost (in currency units) of the flight. Represent this flight network using an Adjacency List and perform the following operations.
- Check if a Direct Flight Exists between city A and city B with time or cost.
- Display All Available Flights with their corresponding time and cost.
- Count Total Flights from a City
- Find All Reachable Cities from a Source City using matrix traversal.
- if direct flight is not available display all connected flights path
*/

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#define MAX 15

class graphNode
{
public:
    string city;
    int time; // in hours
    int cost; // in currency units
    graphNode *next;

    graphNode(string c, int t = 0, int cs = 0)
    {
        city = c;
        time = t;
        cost = cs;
        next = NULL;
    }
};

class FlightNetwork
{
    graphNode *headNode[MAX];
    string cities[MAX];
    int n;

public:
    FlightNetwork()
    {
        n = 0;
        for (int i = 0; i < MAX; i++)
            headNode[i] = NULL;
    }

    void createCities()
    {
        cout << "Enter number of cities: ";
        cin >> n;

        cout << "\nEnter city names:\n";
        for (int i = 0; i < n; i++)
        {
            cout << "City " << i + 1 << " : ";
            cin >> cities[i];
            headNode[i] = new graphNode(cities[i]);
        }
    }

    void createFlights()
    {
        char choice;
        for (int i = 0; i < n; i++)
        {
            cout << "\nSource City : " << headNode[i]->city << endl;
            cout << "Does this city have outgoing flights? (Y/N): ";
            cin >> choice;

            while (choice == 'Y' || choice == 'y')
            {
                string dst;
                int t, c;

                cout << "Enter Destination City: ";
                cin >> dst;

                cout << "Enter Flight Time (in hours): ";
                cin >> t;

                cout << "Enter Flight Cost (in currency units): ";
                cin >> c;

                graphNode *newNode = new graphNode(dst, t, c);
                graphNode *temp = headNode[i];

                while (temp->next != NULL)
                    temp = temp->next;

                temp->next = newNode;

                cout << "Add another outgoing flight for " << headNode[i]->city << " (Y/N): ";
                cin >> choice;
            }
        }
    }

    int findCity(string name)
    {
        for (int i = 0; i < n; i++)
        {
            if (cities[i] == name)
                return i;
        }
        return -1;
    }

    // 1. Check if a Direct Flight Exists between city A and city B with time or cost
    void checkDirectFlight()
    {
        string src, dst;
        cout << "Enter Source City: ";
        cin >> src;
        cout << "Enter Destination City: ";
        cin >> dst;

        int s = findCity(src);
        if (s == -1)
        {
            cout << "Source city not found.\n";
            return;
        }

        graphNode *temp = headNode[s]->next;
        while (temp != NULL)
        {
            if (temp->city == dst)
            {
                cout << "\n[DIRECT FLIGHT AVAILABLE]\n";
                cout << "Flight: " << src << " -> " << dst << endl;
                cout << "Time  : " << temp->time << " hours\n";
                cout << "Cost  : " << temp->cost << " currency units\n";
                return;
            }
            temp = temp->next;
        }

        cout << "\nNo direct flight exists between " << src << " and " << dst << ".\n";
    }

    // 2. Display All Available Flights with corresponding time and cost
    void displayAllFlights()
    {
        cout << "\n================ ALL AVAILABLE FLIGHTS (ADJACENCY LIST) ================\n";
        bool anyFlights = false;

        for (int i = 0; i < n; i++)
        {
            graphNode *temp = headNode[i]->next;
            if (temp != NULL)
                anyFlights = true;

            cout << headNode[i]->city << " -> ";
            while (temp != NULL)
            {
                cout << "[" << temp->city
                     << " | " << temp->time << " hrs"
                     << " | Cost: " << temp->cost << "] -> ";
                temp = temp->next;
            }
            cout << "NULL\n";
        }

        if (!anyFlights)
            cout << "(No flights added to network yet)\n";
        cout << "========================================================================\n";
    }

    // 3. Count Total Flights from a City
    void countFlightsFromCity()
    {
        string src;
        cout << "Enter City to count outgoing flights: ";
        cin >> src;

        int s = findCity(src);
        if (s == -1)
        {
            cout << "City not found.\n";
            return;
        }

        int count = 0;
        graphNode *temp = headNode[s]->next;
        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        cout << "\nTotal Outgoing Flights from " << src << " = " << count << endl;
    }

    // 4. Find All Reachable Cities from a Source City using matrix traversal
    void findReachableCities()
    {
        string src;
        cout << "Enter Source City: ";
        cin >> src;

        int s = findCity(src);
        if (s == -1)
        {
            cout << "City not found.\n";
            return;
        }

        // Build temporary adjacency matrix from list
        int adjMatrix[MAX][MAX] = {0};
        for (int i = 0; i < n; i++)
        {
            graphNode *temp = headNode[i]->next;
            while (temp != NULL)
            {
                int destIdx = findCity(temp->city);
                if (destIdx != -1)
                    adjMatrix[i][destIdx] = 1;
                temp = temp->next;
            }
        }

        // BFS traversal using matrix
        bool visited[MAX] = {false};
        int queue[MAX];
        int front = 0, rear = 0;

        visited[s] = true;
        queue[rear++] = s;

        cout << "\nReachable Cities from " << src << " (using Matrix Traversal):\n";
        int reachedCount = 0;

        while (front < rear)
        {
            int curr = queue[front++];
            if (curr != s)
            {
                cout << "-> " << cities[curr] << endl;
                reachedCount++;
            }

            for (int j = 0; j < n; j++)
            {
                if (adjMatrix[curr][j] == 1 && !visited[j])
                {
                    visited[j] = true;
                    queue[rear++] = j;
                }
            }
        }

        if (reachedCount == 0)
            cout << "(No other cities are reachable from " << src << ")\n";
        else
            cout << "Total Reachable Cities: " << reachedCount << endl;
    }

    // Helper: DFS path finder for connected flights
    bool findPathDFS(int curr, int target, bool visited[], vector<string> &path)
    {
        visited[curr] = true;
        path.push_back(cities[curr]);

        if (curr == target)
            return true;

        graphNode *temp = headNode[curr]->next;
        while (temp != NULL)
        {
            int nextIdx = findCity(temp->city);
            if (nextIdx != -1 && !visited[nextIdx])
            {
                if (findPathDFS(nextIdx, target, visited, path))
                    return true;
            }
            temp = temp->next;
        }

        path.pop_back();
        return false;
    }

    // 5. If direct flight is not available display all connected flights path
    void checkRouteOrConnectedPath()
    {
        string src, dst;
        cout << "Enter Source City: ";
        cin >> src;
        cout << "Enter Destination City: ";
        cin >> dst;

        int s = findCity(src);
        int d = findCity(dst);

        if (s == -1 || d == -1)
        {
            cout << "Invalid city name entered.\n";
            return;
        }

        // Check if direct exists
        graphNode *temp = headNode[s]->next;
        while (temp != NULL)
        {
            if (temp->city == dst)
            {
                cout << "\nDirect flight is ALREADY available from " << src << " to " << dst << ".\n";
                cout << "Flight Time: " << temp->time << " hrs | Cost: " << temp->cost << " currency units\n";
                return;
            }
            temp = temp->next;
        }

        // If direct not available, search for connected flight path
        cout << "\nDirect flight is NOT available.\nSearching for connected flights path...\n";

        bool visited[MAX] = {false};
        vector<string> path;

        if (findPathDFS(s, d, visited, path))
        {
            cout << "\n[CONNECTED FLIGHT PATH FOUND]:\n";
            for (int i = 0; i < (int)path.size(); i++)
            {
                cout << path[i];
                if (i < (int)path.size() - 1)
                    cout << " --> ";
            }
            cout << "\nTotal Layover Stops: " << (int)path.size() - 2 << endl;
        }
        else
        {
            cout << "\nNo connected flight path exists between " << src << " and " << dst << ".\n";
        }
    }
};

int main()
{
    FlightNetwork fn;
    int ch;

    do
    {
        cout << "\n========== AIRLINE FLIGHT NETWORK MANAGEMENT ==========\n";
        cout << "1. Create Cities\n";
        cout << "2. Create Flight Routes\n";
        cout << "3. Display All Available Flights (Adjacency List)\n";
        cout << "4. Check if Direct Flight Exists (with Time and Cost)\n";
        cout << "5. Count Total Flights from a City\n";
        cout << "6. Find All Reachable Cities from Source (Matrix Traversal)\n";
        cout << "7. Find Connected Flights Path (if Direct is Not Available)\n";
        cout << "8. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            fn.createCities();
            break;
        case 2:
            fn.createFlights();
            break;
        case 3:
            fn.displayAllFlights();
            break;
        case 4:
            fn.checkDirectFlight();
            break;
        case 5:
            fn.countFlightsFromCity();
            break;
        case 6:
            fn.findReachableCities();
            break;
        case 7:
            fn.checkRouteOrConnectedPath();
            break;
        case 8:
            cout << "Exiting Airline Flight Network. Thank you!\n";
            break;
        default:
            cout << "Invalid Choice! Please enter 1-8.\n";
        }
    } while (ch != 8);

    return 0;
}

