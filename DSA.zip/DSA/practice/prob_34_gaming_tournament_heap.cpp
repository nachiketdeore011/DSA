/*
34. Problem:
In an online gaming tournament, players receive scores for each round.
The organizer wants to find the highest and lowest scores among all participants efficiently.
Write a menu-driven C++ program using Max Heap and Min Heap to:
- Insert player scores.
- Find and display the maximum and minimum scores.
- Delete the top score when a player leaves.
- Display the leaderboard in sorted order.
- Analyze the space and time complexity of heap creation and retrieval.
*/

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

#define MAX 100

class Player
{
public:
    string name;
    int score;

    Player(string n = "", int s = 0)
    {
        name = n;
        score = s;
    }
};

class TournamentLeaderboard
{
public:
    Player maxHeap[MAX];
    Player minHeap[MAX];
    int size;

    TournamentLeaderboard()
    {
        size = 0;
    }

    void heapifyUpMax(int index)
    {
        int parent = (index - 1) / 2;
        while (index > 0 && maxHeap[index].score > maxHeap[parent].score)
        {
            swap(maxHeap[index], maxHeap[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    void heapifyDownMax(int index)
    {
        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && maxHeap[left].score > maxHeap[largest].score)
            largest = left;

        if (right < size && maxHeap[right].score > maxHeap[largest].score)
            largest = right;

        if (largest != index)
        {
            swap(maxHeap[index], maxHeap[largest]);
            heapifyDownMax(largest);
        }
    }

    void heapifyUpMin(int index)
    {
        int parent = (index - 1) / 2;
        while (index > 0 && minHeap[index].score < minHeap[parent].score)
        {
            swap(minHeap[index], minHeap[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    void heapifyDownMin(int index)
    {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && minHeap[left].score < minHeap[smallest].score)
            smallest = left;

        if (right < size && minHeap[right].score < minHeap[smallest].score)
            smallest = right;

        if (smallest != index)
        {
            swap(minHeap[index], minHeap[smallest]);
            heapifyDownMin(smallest);
        }
    }

    void rebuildMinHeap()
    {
        for (int i = 0; i < size; i++)
            minHeap[i] = maxHeap[i];

        for (int i = (size / 2) - 1; i >= 0; i--)
            heapifyDownMin(i);
    }

    // 1. Insert player score
    void insertPlayer(string name, int score)
    {
        if (size >= MAX)
        {
            cout << "Tournament is at full capacity (Max 100 players).\n";
            return;
        }

        Player p(name, score);
        maxHeap[size] = p;
        minHeap[size] = p;

        heapifyUpMax(size);
        heapifyUpMin(size);

        size++;
        cout << "Player [" << name << "] with score " << score << " added to tournament.\n";
    }

    // 2. Find and display the maximum and minimum scores
    void displayMaxAndMin()
    {
        if (size == 0)
        {
            cout << "No players registered in tournament yet.\n";
            return;
        }

        cout << "\n================ TOURNAMENT SCORE EXTREMES ================\n";
        cout << "Highest Score (Max-Heap Root) : " << maxHeap[0].score << " (Player: " << maxHeap[0].name << ")\n";
        cout << "Lowest Score (Min-Heap Root)  : " << minHeap[0].score << " (Player: " << minHeap[0].name << ")\n";
        cout << "Total Active Tournament Players: " << size << endl;
        cout << "===========================================================\n";
    }

    // 3. Delete top score when player leaves
    void deleteTopScore()
    {
        if (size == 0)
        {
            cout << "No players to remove.\n";
            return;
        }

        Player departing = maxHeap[0];
        maxHeap[0] = maxHeap[size - 1];
        size--;

        heapifyDownMax(0);
        rebuildMinHeap();

        cout << "\nTop Player [" << departing.name << "] with Score " << departing.score << " has left the tournament.\n";
    }

    // 4. Display the leaderboard in sorted order (Heap Sort)
    void displayLeaderboard()
    {
        if (size == 0)
        {
            cout << "No players in tournament.\n";
            return;
        }

        Player temp[MAX];
        int tempSize = size;
        for (int i = 0; i < size; i++)
            temp[i] = maxHeap[i];

        cout << "\n================ TOURNAMENT LEADERBOARD ================\n";
        cout << "Rank\tPlayer Name\tScore\n";
        cout << "--------------------------------------------------------\n";

        int rank = 1;
        while (tempSize > 0)
        {
            cout << rank++ << "\t" << temp[0].name << "\t\t" << temp[0].score << endl;
            temp[0] = temp[tempSize - 1];
            tempSize--;

            // Sift down
            int idx = 0;
            while (true)
            {
                int largest = idx;
                int left = 2 * idx + 1;
                int right = 2 * idx + 2;

                if (left < tempSize && temp[left].score > temp[largest].score)
                    largest = left;
                if (right < tempSize && temp[right].score > temp[largest].score)
                    largest = right;

                if (largest != idx)
                {
                    swap(temp[idx], temp[largest]);
                    idx = largest;
                }
                else
                    break;
            }
        }
        cout << "========================================================\n";
    }

    // 5. Analyze space and time complexity of heap creation and retrieval
    void analyzeComplexity()
    {
        cout << "\n================ HEAP ALGORITHMIC ANALYSIS ================\n";
        cout << "1. Heap Creation / Build Heap Complexity:\n";
        cout << "   - Bottom-up heap construction (Floyd's algorithm): O(n) Time.\n";
        cout << "   - Successive insertions (online stream of scores): O(n log n) Time.\n\n";

        cout << "2. Score Retrieval Complexity:\n";
        cout << "   - Find Maximum Score (Max-Heap top): O(1) Time.\n";
        cout << "   - Find Minimum Score (Min-Heap top): O(1) Time.\n\n";

        cout << "3. Score Insertion & Deletion Complexity:\n";
        cout << "   - Insert New Player: O(log n) Time (tree sift-up).\n";
        cout << "   - Delete Top Score: O(log n) Time (tree sift-down).\n\n";

        cout << "4. Leaderboard Generation (Heap Sort):\n";
        cout << "   - Successively extract max n times: O(n log n) Time.\n\n";

        cout << "5. Space Complexity:\n";
        cout << "   - Auxiliary Space: O(n) for continuous array representation.\n";
        cout << "===========================================================\n";
    }
};

int main()
{
    TournamentLeaderboard tb;
    int ch, score;
    string name;
    char ans;

    // Initial input loop
    do
    {
        cout << "Enter Player Name: ";
        cin >> name;
        cout << "Enter Round Score: ";
        cin >> score;

        tb.insertPlayer(name, score);

        cout << "Add another player? (Y/N): ";
        cin >> ans;
    } while (ans == 'Y' || ans == 'y');

    do
    {
        cout << "\n\n===== GAMING TOURNAMENT HEAP MENU =====\n";
        cout << "1. Insert Player Score\n";
        cout << "2. Display Highest and Lowest Scores\n";
        cout << "3. Delete Top Score (Player Leaves)\n";
        cout << "4. Display Leaderboard in Sorted Order\n";
        cout << "5. Analyze Space and Time Complexity\n";
        cout << "6. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Enter Player Name: ";
            cin >> name;
            cout << "Enter Score: ";
            cin >> score;
            tb.insertPlayer(name, score);
            break;
        case 2:
            tb.displayMaxAndMin();
            break;
        case 3:
            tb.deleteTopScore();
            break;
        case 4:
            tb.displayLeaderboard();
            break;
        case 5:
            tb.analyzeComplexity();
            break;
        case 6:
            cout << "Exiting Tournament System. Goodbye!\n";
            break;
        default:
            cout << "Invalid Choice! Please enter 1-6.\n";
        }
    } while (ch != 6);

    return 0;
}

