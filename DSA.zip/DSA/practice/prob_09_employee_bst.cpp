/*
Problem Statement:
Create a menu-driven C++ program to store and manage employee data using a Binary Search Tree.
Each node stores Employee ID and Salary.
After constructing the BST, perform:
i. Insert new employee data
ii. Search for an employee by ID
iii. Find the employee with minimum and maximum salary
iv. Display all employee IDs in ascending and descending order
v. Display the height of the BST and count leaf nodes
vi. Write all traversal function (write preorder - non recursive function)
*/

#include <iostream>
#include <string>
#include <algorithm>
#include <stack>
using namespace std;

class node
{
public:
    int emp_id;
    string name;
    float salary;
    node *left, *right;

    node(int id = 0, string n = "", float s = 0.0)
    {
        emp_id = id;
        name = n;
        salary = s;
        left = NULL;
        right = NULL;
    }
};

class bstree
{
public:
    node *root;

    bstree()
    {
        root = NULL;
    }

    // i. Insert new employee data (BST ordered by emp_id)
    void insert(int id, string n, float s)
    {
        node *curr = new node(id, n, s);
        node *temp;

        if (root == NULL)
        {
            root = curr;
            cout << "Employee record inserted as root.\n";
            return;
        }

        temp = root;
        while (temp != NULL)
        {
            if (id > temp->emp_id)
            {
                if (temp->right == NULL)
                {
                    temp->right = curr;
                    cout << "Employee record inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->right;
            }
            else if (id < temp->emp_id)
            {
                if (temp->left == NULL)
                {
                    temp->left = curr;
                    cout << "Employee record inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->left;
            }
            else
            {
                cout << "Duplicate Employee ID not allowed!\n";
                delete curr;
                break;
            }
        }
    }

    // ii. Search for an employee by ID
    node *search(int id)
    {
        node *temp = root;
        while (temp != NULL)
        {
            if (id < temp->emp_id)
                temp = temp->left;
            else if (id > temp->emp_id)
                temp = temp->right;
            else
                return temp;
        }
        return NULL;
    }

    // iii. Find employee with minimum and maximum salary
    void findMinMaxSalaryHelper(node *temp, node *&minEmp, node *&maxEmp)
    {
        if (temp == NULL)
            return;

        if (minEmp == NULL || temp->salary < minEmp->salary)
            minEmp = temp;

        if (maxEmp == NULL || temp->salary > maxEmp->salary)
            maxEmp = temp;

        findMinMaxSalaryHelper(temp->left, minEmp, maxEmp);
        findMinMaxSalaryHelper(temp->right, minEmp, maxEmp);
    }

    void displayMinMaxSalary()
    {
        if (root == NULL)
        {
            cout << "Employee database is empty.\n";
            return;
        }

        node *minEmp = NULL;
        node *maxEmp = NULL;
        findMinMaxSalaryHelper(root, minEmp, maxEmp);

        cout << "\nEmployee with MINIMUM Salary:\n";
        cout << "ID: " << minEmp->emp_id << " | Name: " << minEmp->name << " | Salary: Rs." << minEmp->salary << endl;

        cout << "\nEmployee with MAXIMUM Salary:\n";
        cout << "ID: " << maxEmp->emp_id << " | Name: " << maxEmp->name << " | Salary: Rs." << maxEmp->salary << endl;
    }

    // iv. Display all employee IDs in ascending and descending order
    void ascending(node *temp)
    {
        if (temp == NULL)
            return;
        ascending(temp->left);
        cout << "ID: " << temp->emp_id << " | Name: " << temp->name << " | Salary: Rs." << temp->salary << endl;
        ascending(temp->right);
    }

    void descending(node *temp)
    {
        if (temp == NULL)
            return;
        descending(temp->right);
        cout << "ID: " << temp->emp_id << " | Name: " << temp->name << " | Salary: Rs." << temp->salary << endl;
        descending(temp->left);
    }

    // v. Display the height of the BST and count leaf nodes
    int height(node *temp)
    {
        if (temp == NULL)
            return 0;
        return 1 + max(height(temp->left), height(temp->right));
    }

    int countLeaf(node *temp)
    {
        if (temp == NULL)
            return 0;
        if (temp->left == NULL && temp->right == NULL)
            return 1;
        return countLeaf(temp->left) + countLeaf(temp->right);
    }

    // vi. Write all traversal functions (specifically Preorder - Non-Recursive)
    void nonpreorder()
    {
        if (root == NULL)
        {
            cout << "Tree is empty.\n";
            return;
        }

        stack<node *> st;
        st.push(root);

        while (!st.empty())
        {
            node *curr = st.top();
            st.pop();

            cout << "[ID: " << curr->emp_id << ", " << curr->name << ", Rs." << curr->salary << "] ";

            // Push right first so left is processed first
            if (curr->right != NULL)
                st.push(curr->right);
            if (curr->left != NULL)
                st.push(curr->left);
        }
        cout << endl;
    }

    void inorder(node *temp)
    {
        if (temp == NULL)
            return;
        inorder(temp->left);
        cout << "[ID: " << temp->emp_id << ", " << temp->name << "] ";
        inorder(temp->right);
    }

    void preorder(node *temp)
    {
        if (temp == NULL)
            return;
        cout << "[ID: " << temp->emp_id << ", " << temp->name << "] ";
        preorder(temp->left);
        preorder(temp->right);
    }

    void postorder(node *temp)
    {
        if (temp == NULL)
            return;
        postorder(temp->left);
        postorder(temp->right);
        cout << "[ID: " << temp->emp_id << ", " << temp->name << "] ";
    }
};

int main()
{
    bstree empTree;
    int ch, id;
    string name;
    float salary;
    char ans;
    node *found;

    // Create Initial Employee Tree
    do
    {
        cout << "Enter Employee ID: ";
        cin >> id;
        cout << "Enter Employee Name: ";
        cin >> name;
        cout << "Enter Salary: ";
        cin >> salary;

        empTree.insert(id, name, salary);

        cout << "Do you want to continue (Y/N): ";
        cin >> ans;
    } while (ans == 'Y' || ans == 'y');

    do
    {
        cout << "\n\n===== EMPLOYEE MANAGEMENT BST MENU =====\n";
        cout << "1. Insert New Employee Record\n";
        cout << "2. Search Employee by ID\n";
        cout << "3. Find Employee with Minimum and Maximum Salary\n";
        cout << "4. Display Employee IDs in Ascending Order (Inorder)\n";
        cout << "5. Display Employee IDs in Descending Order\n";
        cout << "6. Display Height of BST and Count Leaf Nodes\n";
        cout << "7. Non-Recursive Preorder Traversal\n";
        cout << "8. All Recursive Traversals (Inorder, Preorder, Postorder)\n";
        cout << "9. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Enter Employee ID: ";
            cin >> id;
            cout << "Enter Employee Name: ";
            cin >> name;
            cout << "Enter Salary: ";
            cin >> salary;
            empTree.insert(id, name, salary);
            break;

        case 2:
            cout << "Enter Employee ID to search: ";
            cin >> id;
            found = empTree.search(id);
            if (found != NULL)
            {
                cout << "\nEmployee Found:\n";
                cout << "ID: " << found->emp_id << " | Name: " << found->name << " | Salary: Rs." << found->salary << endl;
            }
            else
            {
                cout << "Employee with ID " << id << " NOT found.\n";
            }
            break;

        case 3:
            empTree.displayMinMaxSalary();
            break;

        case 4:
            cout << "\nEmployees in Ascending Order of ID:\n";
            empTree.ascending(empTree.root);
            break;

        case 5:
            cout << "\nEmployees in Descending Order of ID:\n";
            empTree.descending(empTree.root);
            break;

        case 6:
            cout << "\nHeight of BST: " << empTree.height(empTree.root) << endl;
            cout << "Total Leaf Nodes: " << empTree.countLeaf(empTree.root) << endl;
            break;

        case 7:
            cout << "\nNon-Recursive Preorder Traversal:\n";
            empTree.nonpreorder();
            break;

        case 8:
            cout << "\nRecursive Inorder: ";
            empTree.inorder(empTree.root);
            cout << "\nRecursive Preorder: ";
            empTree.preorder(empTree.root);
            cout << "\nRecursive Postorder: ";
            empTree.postorder(empTree.root);
            cout << endl;
            break;

        case 9:
            cout << "Exiting Employee BST Program. Goodbye!\n";
            break;

        default:
            cout << "Invalid Choice! Please enter 1-9.\n";
        }
    } while (ch != 9);

    return 0;
}

