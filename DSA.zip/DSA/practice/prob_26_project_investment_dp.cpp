/*
26. Problem:
A company has n projects to choose from.
Each project requires a certain investment cost and yields an expected profit.
The company can invest up to a maximum budget B.
Write a C++ program using Dynamic Programming or Branch and Bound to select the set of projects that maximizes total profit without exceeding the budget.
Display the selected projects, total cost, and total profit.
*/

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;

class ProjectInvestment
{
    int n, B;
    string projectName[105];
    int cost[105];
    int profit[105];
    int dp[105][1005];

public:
    void input()
    {
        cout << "Enter number of candidate projects: ";
        cin >> n;

        cout << "\nEnter details of each project (Name, Investment Cost, Expected Profit):\n";
        for (int i = 1; i <= n; i++)
        {
            cout << "Project " << i << " [Name Cost Profit]: ";
            cin >> projectName[i] >> cost[i] >> profit[i];
        }

        cout << "\nEnter maximum investment budget (B): ";
        cin >> B;
    }

    void solve()
    {
        // 0/1 Knapsack Dynamic Programming Table
        for (int i = 0; i <= n; i++)
        {
            for (int b = 0; b <= B; b++)
            {
                if (i == 0 || b == 0)
                {
                    dp[i][b] = 0;
                }
                else if (cost[i] <= b)
                {
                    int include = profit[i] + dp[i - 1][b - cost[i]];
                    int exclude = dp[i - 1][b];
                    dp[i][b] = max(include, exclude);
                }
                else
                {
                    dp[i][b] = dp[i - 1][b];
                }
            }
        }
    }

    void display()
    {
        cout << "\n================ OPTIMAL PROJECT SELECTION ================\n";
        cout << "Maximum Profit Obtained = Rs. " << dp[n][B] << endl;
        cout << "\nSelected Projects:\n";

        int b = B;
        int totalCostUsed = 0;
        vector<int> selected;

        for (int i = n; i >= 1; i--)
        {
            if (dp[i][b] != dp[i - 1][b])
            {
                selected.push_back(i);
                totalCostUsed += cost[i];
                b -= cost[i];
            }
        }

        for (int i = (int)selected.size() - 1; i >= 0; i--)
        {
            int idx = selected[i];
            cout << "-> " << projectName[idx]
                 << " | Investment Cost: Rs. " << cost[idx]
                 << " | Expected Profit: Rs. " << profit[idx] << endl;
        }

        cout << "-----------------------------------------------------------\n";
        cout << "Total Investment Cost Used = Rs. " << totalCostUsed << " / Rs. " << B << endl;
        cout << "Total Profit Generated     = Rs. " << dp[n][B] << endl;
        cout << "===========================================================\n";
    }
};

int main()
{
    ProjectInvestment pi;
    pi.input();
    pi.solve();
    pi.display();

    return 0;
}

