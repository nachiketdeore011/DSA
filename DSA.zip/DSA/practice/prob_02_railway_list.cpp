/*
Problem Statement:
There are railway routes between major cities. If there is a train route between city A and city B, then there is an edge between the cities.
The cost of the edge can represent the distance (in km) or ticket fare between the cities.
Write a menu-driven C++ program to represent this as a graph using adjacency list
Each node represents a railway station.
The program should:
- Check whether two cities are directly connected by a train route.
- Display all possible connections from a given city.
- Display whether two stations are connected directly by one train or more.
*/

#include <iostream>
#include <string>
using namespace std;

#define MAX 20

class graphNode
{
public:
    string station;
    int distance;
    int fare;
    graphNode *next;

    graphNode(string s)
    {
        station = s;
        distance = 0;
        fare = 0;
        next = NULL;
    }
};

class RailwayGraph
{
    graphNode *headNode[MAX];
    string stations[MAX];
    int n;

public:
    RailwayGraph()
    {
        n = 0;
        for (int i = 0; i < MAX; i++)
            headNode[i] = NULL;
    }

    void createStations()
    {
        cout << "Enter number of railway stations: ";
        cin >> n;

        cout << "\nEnter station names:\n";
        for (int i = 0; i < n; i++)
        {
            cout << "Station " << i + 1 << " : ";
            cin >> stations[i];
            headNode[i] = new graphNode(stations[i]);
        }
    }

    void displayStations()
    {
        cout << "\nRailway Stations are:\n";
        for (int i = 0; i < n; i++)
            cout << headNode[i]->station << endl;
    }

    void createRoutes()
    {
        char choice;
        for (int i = 0; i < n; i++)
        {
            cout << "\nSource Station : " << headNode[i]->station << endl;
            cout << "Does this station have outgoing train routes? (Y/N): ";
            cin >> choice;

            while (choice == 'Y' || choice == 'y')
            {
                string dst;
                int dist, f;

                cout << "Enter Destination Station: ";
                cin >> dst;

                cout << "Enter Distance (in km): ";
                cin >> dist;

                cout << "Enter Ticket Fare: ";
                cin >> f;

                graphNode *newNode = new graphNode(dst);
                newNode->distance = dist;
                newNode->fare = f;

                graphNode *temp = headNode[i];
                while (temp->next != NULL)
                    temp = temp->next;

                temp->next = newNode;

                cout << "Add another train route for " << headNode[i]->station << " (Y/N): ";
                cin >> choice;
            }
        }
    }

    void displayNetwork()
    {
        cout << "\nRailway Network (Adjacency List Representation)\n\n";
        for (int i = 0; i < n; i++)
        {
            graphNode *temp = headNode[i];
            cout << temp->station << " -> ";
            temp = temp->next;

            while (temp != NULL)
            {
                cout << "[" << temp->station
                     << " , Distance: " << temp->distance << " km"
                     << " , Fare: Rs." << temp->fare << "] -> ";
                temp = temp->next;
            }
            cout << "NULL" << endl;
        }
    }

    // 1. Check whether two cities are directly connected by a train route
    void checkDirectRoute()
    {
        string src, dst;
        cout << "Enter Source Station: ";
        cin >> src;
        cout << "Enter Destination Station: ";
        cin >> dst;

        for (int i = 0; i < n; i++)
        {
            if (headNode[i]->station == src)
            {
                graphNode *temp = headNode[i]->next;
                while (temp != NULL)
                {
                    if (temp->station == dst)
                    {
                        cout << "\nDirect Train Route Available!\n";
                        cout << "Distance : " << temp->distance << " km" << endl;
                        cout << "Ticket Fare : Rs." << temp->fare << endl;
                        return;
                    }
                    temp = temp->next;
                }
                cout << "\nNo Direct Train Route Exists between " << src << " and " << dst << ".\n";
                return;
            }
        }
        cout << "Source Station Not Found.\n";
    }

    // 2. Display all possible connections from a given city
    void displayConnectionsFromCity()
    {
        string src;
        cout << "Enter Station Name to view all connections: ";
        cin >> src;

        for (int i = 0; i < n; i++)
        {
            if (headNode[i]->station == src)
            {
                graphNode *temp = headNode[i]->next;
                if (temp == NULL)
                {
                    cout << "No outgoing train routes from " << src << ".\n";
                    return;
                }

                cout << "\nAll Direct Connections from " << src << ":\n";
                while (temp != NULL)
                {
                    cout << " --> To: " << temp->station
                         << " | Distance: " << temp->distance << " km"
                         << " | Fare: Rs." << temp->fare << endl;
                    temp = temp->next;
                }
                return;
            }
        }
        cout << "Station Not Found.\n";
    }

    int findStation(string name)
    {
        for (int i = 0; i < n; i++)
        {
            if (stations[i] == name)
                return i;
        }
        return -1;
    }

    // Helper DFS to find connectivity (directly or via connecting trains)
    bool dfs(int current, int destination, bool visited[])
    {
        if (current == destination)
            return true;

        visited[current] = true;
        graphNode *temp = headNode[current]->next;

        while (temp != NULL)
        {
            int nextIdx = findStation(temp->station);
            if (nextIdx != -1 && !visited[nextIdx])
            {
                if (dfs(nextIdx, destination, visited))
                    return true;
            }
            temp = temp->next;
        }
        return false;
    }

    // 3. Display whether two stations are connected directly by one train or more
    void checkConnectionStatus()
    {
        string src, dst;
        cout << "Enter Source Station: ";
        cin >> src;
        cout << "Enter Destination Station: ";
        cin >> dst;

        int s = findStation(src);
        int d = findStation(dst);

        if (s == -1 || d == -1)
        {
            cout << "Invalid station name entered.\n";
            return;
        }

        // Check if direct train (one train) exists
        graphNode *temp = headNode[s]->next;
        bool direct = false;
        while (temp != NULL)
        {
            if (temp->station == dst)
            {
                direct = true;
                break;
            }
            temp = temp->next;
        }

        if (direct)
        {
            cout << "\nStations are directly connected by ONE direct train route.\n";
            return;
        }

        // If not direct, check if connected via one or more connecting trains using DFS
        bool visited[MAX] = {false};
        if (dfs(s, d, visited))
        {
            cout << "\nStations are connected via CONNECTING TRAINS (multiple routes / stops available).\n";
        }
        else
        {
            cout << "\nNo railway connection available between " << src << " and " << dst << ".\n";
        }
    }
};

int main()
{
    RailwayGraph g;
    int ch;

    do
    {
        cout << "\n========== RAILWAY ROUTE MANAGEMENT ==========\n";
        cout << "1. Create Stations\n";
        cout << "2. Display Stations\n";
        cout << "3. Create Railway Routes\n";
        cout << "4. Display Railway Network (Adjacency List)\n";
        cout << "5. Check Direct Train Route (Two Cities)\n";
        cout << "6. Display All Connections from a Given City\n";
        cout << "7. Check Connection by One Train or More\n";
        cout << "8. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            g.createStations();
            break;
        case 2:
            g.displayStations();
            break;
        case 3:
            g.createRoutes();
            break;
        case 4:
            g.displayNetwork();
            break;
        case 5:
            g.checkDirectRoute();
            break;
        case 6:
            g.displayConnectionsFromCity();
            break;
        case 7:
            g.checkConnectionStatus();
            break;
        case 8:
            cout << "Thank You!\n";
            break;
        default:
            cout << "Invalid Choice\n";
        }
    } while (ch != 8);

    return 0;
}

