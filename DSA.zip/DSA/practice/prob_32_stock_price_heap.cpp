/*
32. Problem:
A stock analyst records the daily stock prices of a company.
They want to quickly find the highest and lowest prices during a given period.
Write a C++ program using Heap data structures to perform the following:
- Insert daily stock prices.
- Display the maximum and minimum stock price.
- Delete the topmost (maximum) price.
- Display all prices in ascending or descending order.
- Perform algorithmic analysis for insertion and deletion operations.
*/

#include <iostream>
#include <algorithm>
using namespace std;

#define MAX 100

class StockHeap
{
public:
    int maxHeap[MAX];
    int minHeap[MAX];
    int size;

    StockHeap()
    {
        size = 0;
    }

    // Helper: Heapify up for Max Heap
    void heapifyUpMax(int index)
    {
        int parent = (index - 1) / 2;
        while (index > 0 && maxHeap[index] > maxHeap[parent])
        {
            swap(maxHeap[index], maxHeap[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    // Helper: Heapify down for Max Heap
    void heapifyDownMax(int index)
    {
        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && maxHeap[left] > maxHeap[largest])
            largest = left;

        if (right < size && maxHeap[right] > maxHeap[largest])
            largest = right;

        if (largest != index)
        {
            swap(maxHeap[index], maxHeap[largest]);
            heapifyDownMax(largest);
        }
    }

    // Helper: Heapify up for Min Heap
    void heapifyUpMin(int index)
    {
        int parent = (index - 1) / 2;
        while (index > 0 && minHeap[index] < minHeap[parent])
        {
            swap(minHeap[index], minHeap[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    // Rebuild minHeap from maxHeap elements
    void rebuildMinHeap()
    {
        for (int i = 0; i < size; i++)
            minHeap[i] = maxHeap[i];

        for (int i = (size / 2) - 1; i >= 0; i--)
        {
            heapifyDownMin(i);
        }
    }

    void heapifyDownMin(int index)
    {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && minHeap[left] < minHeap[smallest])
            smallest = left;

        if (right < size && minHeap[right] < minHeap[smallest])
            smallest = right;

        if (smallest != index)
        {
            swap(minHeap[index], minHeap[smallest]);
            heapifyDownMin(smallest);
        }
    }

    // 1. Insert daily stock price
    void insertPrice(int price)
    {
        if (size >= MAX)
        {
            cout << "Heap overflow! Maximum stock records reached.\n";
            return;
        }

        maxHeap[size] = price;
        minHeap[size] = price;

        heapifyUpMax(size);
        heapifyUpMin(size);

        size++;
        cout << "Stock price Rs." << price << " recorded successfully.\n";
    }

    // 2. Display the maximum and minimum stock price
    void displayMaxAndMin()
    {
        if (size == 0)
        {
            cout << "No stock prices recorded yet.\n";
            return;
        }

        cout << "\n================ STOCK PRICE SUMMARY ================\n";
        cout << "Maximum Stock Price (Highest) : Rs. " << maxHeap[0] << endl;
        cout << "Minimum Stock Price (Lowest)  : Rs. " << minHeap[0] << endl;
        cout << "Total Recorded Trading Days   : " << size << endl;
        cout << "=====================================================\n";
    }

    // 3. Delete the topmost (maximum) price
    void deleteMaxPrice()
    {
        if (size == 0)
        {
            cout << "No stock prices to delete.\n";
            return;
        }

        int removed = maxHeap[0];
        maxHeap[0] = maxHeap[size - 1];
        size--;

        heapifyDownMax(0);
        rebuildMinHeap();

        cout << "\nTopmost (Maximum) Stock Price Rs." << removed << " deleted successfully.\n";
    }

    // 4. Display all prices in ascending or descending order (Heap Sort)
    void displayDescending()
    {
        if (size == 0)
        {
            cout << "No stock prices recorded.\n";
            return;
        }

        // Copy maxHeap to sort
        int temp[MAX];
        int tempSize = size;
        for (int i = 0; i < size; i++)
            temp[i] = maxHeap[i];

        cout << "\nStock Prices in Descending Order (High to Low):\n";
        while (tempSize > 0)
        {
            cout << "Rs. " << temp[0] << " ";
            temp[0] = temp[tempSize - 1];
            tempSize--;

            // Sift down
            int idx = 0;
            while (true)
            {
                int largest = idx;
                int left = 2 * idx + 1;
                int right = 2 * idx + 2;

                if (left < tempSize && temp[left] > temp[largest])
                    largest = left;
                if (right < tempSize && temp[right] > temp[largest])
                    largest = right;

                if (largest != idx)
                {
                    swap(temp[idx], temp[largest]);
                    idx = largest;
                }
                else
                    break;
            }
        }
        cout << endl;
    }

    void displayAscending()
    {
        if (size == 0)
        {
            cout << "No stock prices recorded.\n";
            return;
        }

        int temp[MAX];
        int tempSize = size;
        for (int i = 0; i < size; i++)
            temp[i] = minHeap[i];

        cout << "\nStock Prices in Ascending Order (Low to High):\n";
        while (tempSize > 0)
        {
            cout << "Rs. " << temp[0] << " ";
            temp[0] = temp[tempSize - 1];
            tempSize--;

            // Sift down
            int idx = 0;
            while (true)
            {
                int smallest = idx;
                int left = 2 * idx + 1;
                int right = 2 * idx + 2;

                if (left < tempSize && temp[left] < temp[smallest])
                    smallest = left;
                if (right < tempSize && temp[right] < temp[smallest])
                    smallest = right;

                if (smallest != idx)
                {
                    swap(temp[idx], temp[smallest]);
                    idx = smallest;
                }
                else
                    break;
            }
        }
        cout << endl;
    }

    // 5. Algorithmic analysis for insertion and deletion operations
    void algorithmicAnalysis()
    {
        cout << "\n================ ALGORITHMIC COMPLEXITY ANALYSIS ================\n";
        cout << "1. Insertion Operation [insertPrice]:\n";
        cout << "   - Adds element at leaf position (index = size).\n";
        cout << "   - Sifts up to restore heap invariant (at most height of tree).\n";
        cout << "   - Time Complexity: O(log n)\n\n";

        cout << "2. Deletion Operation [deleteMaxPrice]:\n";
        cout << "   - Replaces root with last element and removes root.\n";
        cout << "   - Sifts down to restore heap invariant (at most height of tree).\n";
        cout << "   - Time Complexity: O(log n)\n\n";

        cout << "3. Find Maximum / Minimum [displayMaxAndMin]:\n";
        cout << "   - Peek at root of Max-Heap or Min-Heap.\n";
        cout << "   - Time Complexity: O(1)\n\n";

        cout << "4. Heap Sort [displayAscending / displayDescending]:\n";
        cout << "   - Extracts n elements from heap successively.\n";
        cout << "   - Time Complexity: O(n log n)\n\n";

        cout << "5. Auxiliary Space Complexity: O(n) for array-based binary heap.\n";
        cout << "=================================================================\n";
    }
};

int main()
{
    StockHeap sh;
    int ch, price;
    char ans;

    // Initial input loop
    do
    {
        cout << "Enter Daily Stock Price: Rs. ";
        cin >> price;
        sh.insertPrice(price);

        cout << "Add another stock price? (Y/N): ";
        cin >> ans;
    } while (ans == 'Y' || ans == 'y');

    do
    {
        cout << "\n\n===== STOCK ANALYST HEAP MENU =====\n";
        cout << "1. Insert New Daily Stock Price\n";
        cout << "2. Display Maximum and Minimum Stock Price\n";
        cout << "3. Delete Topmost (Maximum) Price\n";
        cout << "4. Display All Prices in Ascending Order\n";
        cout << "5. Display All Prices in Descending Order\n";
        cout << "6. View Algorithmic Analysis of Operations\n";
        cout << "7. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Enter Stock Price: Rs. ";
            cin >> price;
            sh.insertPrice(price);
            break;
        case 2:
            sh.displayMaxAndMin();
            break;
        case 3:
            sh.deleteMaxPrice();
            break;
        case 4:
            sh.displayAscending();
            break;
        case 5:
            sh.displayDescending();
            break;
        case 6:
            sh.algorithmicAnalysis();
            break;
        case 7:
            cout << "Exiting Stock Analysis System. Goodbye!\n";
            break;
        default:
            cout << "Invalid Choice! Please enter 1-7.\n";
        }
    } while (ch != 7);

    return 0;
}

