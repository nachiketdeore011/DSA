/*
13. Problem:
Construct an Expression Tree from a prefix arithmetic expression (e.g., +*ab/cd or +*23*45).
Perform the following operations:
- Display Inorder, Preorder, and Postorder traversals.
- Simplify the expression tree by reducing constant sub-expressions (e.g., *23 -> 6).
- Find total number of leaf nodes and internal nodes.
- Display the mirror image of the expression tree.
*/

#include <iostream>
#include <string>
#include <cctype>
#include <stack>
#include <algorithm>
using namespace std;

class node
{
public:
    char exp;
    node *left, *right;

    node(char val = ' ')
    {
        exp = val;
        left = NULL;
        right = NULL;
    }
};

class ArithmeticTree
{
public:
    node *root;

    ArithmeticTree()
    {
        root = NULL;
    }

    bool isOperator(char c)
    {
        return (c == '+' || c == '-' || c == '*' || c == '/');
    }

    // Construct Expression Tree using Prefix Expression
    void insert(string exp)
    {
        stack<node *> st;

        for (int i = (int)exp.size() - 1; i >= 0; i--)
        {
            char ch = exp[i];
            if (ch == ' ')
                continue;

            node *newNode = new node(ch);

            if (isOperator(ch))
            {
                if (!st.empty())
                {
                    newNode->left = st.top();
                    st.pop();
                }
                if (!st.empty())
                {
                    newNode->right = st.top();
                    st.pop();
                }
                st.push(newNode);
            }
            else
            {
                // Operand (alphabetic variable or constant digit)
                st.push(newNode);
            }
        }

        if (!st.empty())
        {
            root = st.top();
            cout << "Arithmetic Expression Tree Created Successfully.\n";
        }
        else
        {
            cout << "Invalid Expression!\n";
        }
    }

    // Traversals
    void inorder(node *temp)
    {
        if (temp == NULL)
            return;
        inorder(temp->left);
        cout << temp->exp << " ";
        inorder(temp->right);
    }

    void preorder(node *temp)
    {
        if (temp == NULL)
            return;
        cout << temp->exp << " ";
        preorder(temp->left);
        preorder(temp->right);
    }

    void postorder(node *temp)
    {
        if (temp == NULL)
            return;
        postorder(temp->left);
        postorder(temp->right);
        cout << temp->exp << " ";
    }

    // Non-recursive traversals
    void noninorder()
    {
        stack<node *> st;
        node *temp = root;

        while (temp != NULL || !st.empty())
        {
            while (temp != NULL)
            {
                st.push(temp);
                temp = temp->left;
            }

            temp = st.top();
            st.pop();
            cout << temp->exp << " ";
            temp = temp->right;
        }
        cout << endl;
    }

    // Simplify the expression tree by reducing constant sub-expressions (e.g. *23 -> 6)
    node *simplifyConstants(node *temp)
    {
        if (temp == NULL)
            return NULL;

        temp->left = simplifyConstants(temp->left);
        temp->right = simplifyConstants(temp->right);

        // Check if both left and right children are constant digits
        if (temp->left != NULL && temp->right != NULL &&
            isdigit(temp->left->exp) && isdigit(temp->right->exp))
        {
            int val1 = temp->left->exp - '0';
            int val2 = temp->right->exp - '0';
            int result = 0;

            switch (temp->exp)
            {
            case '+':
                result = val1 + val2;
                break;
            case '-':
                result = val1 - val2;
                break;
            case '*':
                result = val1 * val2;
                break;
            case '/':
                if (val2 != 0)
                    result = val1 / val2;
                else
                    result = 0;
                break;
            }

            // If result fits in a single digit character
            if (result >= 0 && result <= 9)
            {
                temp->exp = (char)('0' + result);
                delete temp->left;
                delete temp->right;
                temp->left = NULL;
                temp->right = NULL;
            }
        }

        return temp;
    }

    // Count leaf nodes
    int countLeafNodes(node *temp)
    {
        if (temp == NULL)
            return 0;
        if (temp->left == NULL && temp->right == NULL)
            return 1;
        return countLeafNodes(temp->left) + countLeafNodes(temp->right);
    }

    // Count internal nodes (nodes with at least one child)
    int countInternalNodes(node *temp)
    {
        if (temp == NULL)
            return 0;
        if (temp->left == NULL && temp->right == NULL)
            return 0;
        return 1 + countInternalNodes(temp->left) + countInternalNodes(temp->right);
    }

    // Display mirror image (swap left and right subtrees)
    void swapTree(node *temp)
    {
        if (temp == NULL)
            return;

        swap(temp->left, temp->right);
        swapTree(temp->left);
        swapTree(temp->right);
    }
};

int main()
{
    ArithmeticTree t;
    string exp;
    int ch;

    cout << "Enter Prefix Arithmetic Expression (e.g., +*ab/cd or +*23*45): ";
    cin >> exp;

    t.insert(exp);

    do
    {
        cout << "\n\n----- ARITHMETIC EXPRESSION TREE MENU -----";
        cout << "\n1. Display Inorder, Preorder, and Postorder Traversals";
        cout << "\n2. Non-Recursive Inorder Traversal";
        cout << "\n3. Simplify Tree (Reduce Constant Sub-expressions e.g. *23 -> 6)";
        cout << "\n4. Count Leaf Nodes and Internal Nodes";
        cout << "\n5. Mirror Image of Expression Tree (Swap Subtrees)";
        cout << "\n6. Exit";
        cout << "\nEnter your choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "\nInorder Traversal   : ";
            t.inorder(t.root);
            cout << "\nPreorder Traversal  : ";
            t.preorder(t.root);
            cout << "\nPostorder Traversal : ";
            t.postorder(t.root);
            cout << endl;
            break;

        case 2:
            cout << "\nNon-Recursive Inorder: ";
            t.noninorder();
            break;

        case 3:
            t.root = t.simplifyConstants(t.root);
            cout << "\nExpression Tree Simplified Successfully!\nNew Inorder Traversal: ";
            t.inorder(t.root);
            cout << endl;
            break;

        case 4:
            cout << "\nTotal Leaf Nodes (Operands)     : " << t.countLeafNodes(t.root) << endl;
            cout << "Total Internal Nodes (Operators) : " << t.countInternalNodes(t.root) << endl;
            break;

        case 5:
            t.swapTree(t.root);
            cout << "\nMirror Image Created Successfully!\nMirrored Inorder: ";
            t.inorder(t.root);
            cout << endl;
            break;

        case 6:
            cout << "Exiting Arithmetic Tree Program. Goodbye!\n";
            break;

        default:
            cout << "Invalid Choice! Please enter 1-6.\n";
        }
    } while (ch != 6);

    return 0;
}

