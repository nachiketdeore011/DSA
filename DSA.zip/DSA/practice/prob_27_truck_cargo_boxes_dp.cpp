/*
27. Problem:
A logistics company has a truck with a maximum weight capacity W.
There are n cargo boxes, each having a weight and value (profit).
Each box can either be fully loaded or not loaded at all (no fractions allowed).
Using Dynamic Programming or Branch and Bound, write a C++ program to find the combination of boxes that maximizes total profit while keeping total weight <= W.
Output the selected boxes, total weight used, and total profit.
*/

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;

class TruckCargoKnapsack
{
    int n, W;
    string boxName[105];
    int wt[105];
    int val[105];
    int dp[105][1005];

public:
    void input()
    {
        cout << "Enter number of cargo boxes: ";
        cin >> n;

        cout << "\nEnter details of each cargo box (Box Identifier/Name, Weight in kg, Value/Profit in Rs):\n";
        for (int i = 1; i <= n; i++)
        {
            cout << "Box " << i << " [Name Weight Value]: ";
            cin >> boxName[i] >> wt[i] >> val[i];
        }

        cout << "\nEnter maximum truck weight capacity (W in kg): ";
        cin >> W;
    }

    void solve()
    {
        // 0/1 Knapsack Dynamic Programming Table
        for (int i = 0; i <= n; i++)
        {
            for (int w = 0; w <= W; w++)
            {
                if (i == 0 || w == 0)
                {
                    dp[i][w] = 0;
                }
                else if (wt[i] <= w)
                {
                    int include = val[i] + dp[i - 1][w - wt[i]];
                    int exclude = dp[i - 1][w];
                    dp[i][w] = max(include, exclude);
                }
                else
                {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }
    }

    void display()
    {
        cout << "\n================ OPTIMAL CARGO TRUCK LOADING ================\n";
        cout << "Maximum Total Profit = Rs. " << dp[n][W] << endl;
        cout << "\nSelected Cargo Boxes Loaded into Truck (0/1 All or Nothing):\n";

        int w = W;
        int totalWeightUsed = 0;
        vector<int> selected;

        for (int i = n; i >= 1; i--)
        {
            if (dp[i][w] != dp[i - 1][w])
            {
                selected.push_back(i);
                totalWeightUsed += wt[i];
                w -= wt[i];
            }
        }

        for (int i = (int)selected.size() - 1; i >= 0; i--)
        {
            int idx = selected[i];
            cout << "-> " << boxName[idx]
                 << " | Weight: " << wt[idx] << " kg"
                 << " | Value: Rs. " << val[idx] << endl;
        }

        cout << "-------------------------------------------------------------\n";
        cout << "Total Weight Loaded in Truck = " << totalWeightUsed << " kg / " << W << " kg\n";
        cout << "Total Profit Obtained        = Rs. " << dp[n][W] << endl;
        cout << "=============================================================\n";
    }
};

int main()
{
    TruckCargoKnapsack truck;
    truck.input();
    truck.solve();
    truck.display();

    return 0;
}

