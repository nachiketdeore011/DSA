/*
Problem Statement:
A group of servers in a network are connected by data cables.
If a direct cable exists between Server A and Server B, there is an edge between them.
The weight of the edge denotes data transfer speed (Mbps) or latency (ms).
Write a C++ program to represent this network using adjacency matrix and adjacency list.
The program should:
- Display the connectivity between servers.
- Determine if all servers are reachable from a given node.
*/

#include <iostream>
#include <string>
using namespace std;

#define MAX 10

class graphNode
{
public:
    string serverName;
    int speed;   // in Mbps
    int latency; // in ms
    graphNode *next;

    graphNode(string s, int sp = 0, int lat = 0)
    {
        serverName = s;
        speed = sp;
        latency = lat;
        next = NULL;
    }
};

class ServerNetwork
{
public:
    int n;
    string servers[MAX];
    int speedMatrix[MAX][MAX];
    int latencyMatrix[MAX][MAX];
    graphNode *headNode[MAX];

    ServerNetwork()
    {
        n = 0;
        for (int i = 0; i < MAX; i++)
        {
            headNode[i] = NULL;
            for (int j = 0; j < MAX; j++)
            {
                speedMatrix[i][j] = 0;
                latencyMatrix[i][j] = 0;
            }
        }
    }

    void readNetwork()
    {
        cout << "Enter the number of servers: ";
        cin >> n;

        cout << "\nEnter server names:\n";
        for (int i = 0; i < n; i++)
        {
            cout << "Server " << i + 1 << " : ";
            cin >> servers[i];
            headNode[i] = new graphNode(servers[i]);
        }

        cout << "\nEnter cable connections (Speed in Mbps, 0 if no direct cable):\n";
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    speedMatrix[i][j] = 0;
                    latencyMatrix[i][j] = 0;
                }
                else
                {
                    cout << "Transfer Speed between " << servers[i] << " and " << servers[j] << " (Mbps): ";
                    cin >> speedMatrix[i][j];

                    if (speedMatrix[i][j] != 0)
                    {
                        cout << "Latency between " << servers[i] << " and " << servers[j] << " (ms): ";
                        cin >> latencyMatrix[i][j];

                        // Insert into Adjacency List as well
                        graphNode *newNode = new graphNode(servers[j], speedMatrix[i][j], latencyMatrix[i][j]);
                        graphNode *temp = headNode[i];
                        while (temp->next != NULL)
                            temp = temp->next;
                        temp->next = newNode;
                    }
                    else
                    {
                        latencyMatrix[i][j] = 0;
                    }
                }
            }
        }
        cout << "\nNetwork topology created successfully in both Matrix and List formats!\n";
    }

    void displayMatrix()
    {
        cout << "\n--- Adjacency Matrix: Data Transfer Speed (Mbps) ---\n\t";
        for (int i = 0; i < n; i++)
            cout << servers[i] << "\t";
        cout << endl;

        for (int i = 0; i < n; i++)
        {
            cout << servers[i] << "\t";
            for (int j = 0; j < n; j++)
            {
                cout << speedMatrix[i][j] << "\t";
            }
            cout << endl;
        }

        cout << "\n--- Adjacency Matrix: Latency (ms) ---\n\t";
        for (int i = 0; i < n; i++)
            cout << servers[i] << "\t";
        cout << endl;

        for (int i = 0; i < n; i++)
        {
            cout << servers[i] << "\t";
            for (int j = 0; j < n; j++)
            {
                cout << latencyMatrix[i][j] << "\t";
            }
            cout << endl;
        }
    }

    void displayList()
    {
        cout << "\n--- Adjacency List Representation ---\n";
        for (int i = 0; i < n; i++)
        {
            graphNode *temp = headNode[i];
            cout << temp->serverName << " -> ";
            temp = temp->next;

            while (temp != NULL)
            {
                cout << "[" << temp->serverName
                     << " | " << temp->speed << " Mbps"
                     << " | " << temp->latency << " ms] -> ";
                temp = temp->next;
            }
            cout << "NULL" << endl;
        }
    }

    int findServer(string name)
    {
        for (int i = 0; i < n; i++)
        {
            if (servers[i] == name)
                return i;
        }
        return -1;
    }

    void dfs(int current, bool visited[])
    {
        visited[current] = true;
        for (int j = 0; j < n; j++)
        {
            if (speedMatrix[current][j] != 0 && !visited[j])
            {
                dfs(j, visited);
            }
        }
    }

    // Determine if all servers are reachable from a given node
    void checkAllServersReachable()
    {
        if (n == 0)
        {
            cout << "Please enter network details first.\n";
            return;
        }

        string startServer;
        cout << "Enter Source Server to test reachability: ";
        cin >> startServer;

        int src = findServer(startServer);
        if (src == -1)
        {
            cout << "Invalid server name.\n";
            return;
        }

        bool visited[MAX] = {false};
        dfs(src, visited);

        int count = 0;
        for (int i = 0; i < n; i++)
        {
            if (visited[i])
                count++;
        }

        cout << "\nReachability Analysis from [" << startServer << "]:\n";
        if (count == n)
        {
            cout << "STATUS: ALL servers are reachable from " << startServer << "! (Network is strongly connected from this node)\n";
        }
        else
        {
            cout << "STATUS: NOT all servers are reachable from " << startServer << ".\n";
            cout << "Reachable Servers: ";
            for (int i = 0; i < n; i++)
                if (visited[i])
                    cout << servers[i] << " ";
            cout << "\nUnreachable Servers: ";
            for (int i = 0; i < n; i++)
                if (!visited[i])
                    cout << servers[i] << " ";
            cout << endl;
        }
    }
};

int main()
{
    ServerNetwork net;
    int choice;

    do
    {
        cout << "\n========== SERVER NETWORK MANAGEMENT ==========\n";
        cout << "1. Create Server Network (Input Cable Connections)\n";
        cout << "2. Display Connectivity (Adjacency Matrix)\n";
        cout << "3. Display Connectivity (Adjacency List)\n";
        cout << "4. Determine if All Servers are Reachable from a Node\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            net.readNetwork();
            break;
        case 2:
            net.displayMatrix();
            break;
        case 3:
            net.displayList();
            break;
        case 4:
            net.checkAllServersReachable();
            break;
        case 5:
            cout << "Program ended. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice! Please select 1-5.\n";
        }
    } while (choice != 5);

    return 0;
}

