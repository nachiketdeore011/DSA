/*
Problem Statement:
Write a menu-driven C++ program to maintain student records using a Binary Search Tree.
Each node contains a student's roll number and name.
Starting with an empty tree, insert the records in the order given. After constructing the BST, perform the following operations:
i. Insert a new student record
ii. Write all traversal function (write Inorder - non recursive function)
iii. Search for a student using roll number
iv. Display student records in ascending and descending order of roll numbers
v. Find the height and total number of nodes in the BST
vi. Delete a student record using roll number (optional)
*/

#include <iostream>
#include <string>
#include <algorithm>
#include <stack>
using namespace std;

class node
{
public:
    int roll;
    string name;
    node *left, *right;

    node(int r, string n)
    {
        roll = r;
        name = n;
        left = NULL;
        right = NULL;
    }
};

class bstree
{
public:
    node *root;

    bstree()
    {
        root = NULL;
    }

    // i. Insert a new student record
    void insert(int r, string n)
    {
        node *curr = new node(r, n);
        node *temp;

        if (root == NULL)
        {
            root = curr;
            cout << "Record inserted as root.\n";
            return;
        }

        temp = root;
        while (temp != NULL)
        {
            if (r > temp->roll)
            {
                if (temp->right == NULL)
                {
                    temp->right = curr;
                    cout << "Record inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->right;
            }
            else if (r < temp->roll)
            {
                if (temp->left == NULL)
                {
                    temp->left = curr;
                    cout << "Record inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->left;
            }
            else
            {
                cout << "Duplicate Roll Number not allowed!\n";
                delete curr;
                break;
            }
        }
    }

    // ii. Traversals
    // Recursive Inorder (Ascending)
    void inorder(node *temp)
    {
        if (temp == NULL)
            return;
        inorder(temp->left);
        cout << "[Roll: " << temp->roll << ", Name: " << temp->name << "] ";
        inorder(temp->right);
    }

    // Recursive Preorder
    void preorder(node *temp)
    {
        if (temp == NULL)
            return;
        cout << "[Roll: " << temp->roll << ", Name: " << temp->name << "] ";
        preorder(temp->left);
        preorder(temp->right);
    }

    // Recursive Postorder
    void postorder(node *temp)
    {
        if (temp == NULL)
            return;
        postorder(temp->left);
        postorder(temp->right);
        cout << "[Roll: " << temp->roll << ", Name: " << temp->name << "] ";
    }

    // Non-Recursive Inorder (using stack)
    void noninorder()
    {
        if (root == NULL)
        {
            cout << "Tree is empty.\n";
            return;
        }

        stack<node *> st;
        node *temp = root;

        while (temp != NULL || !st.empty())
        {
            while (temp != NULL)
            {
                st.push(temp);
                temp = temp->left;
            }

            temp = st.top();
            st.pop();

            cout << "[Roll: " << temp->roll << ", Name: " << temp->name << "] ";
            temp = temp->right;
        }
        cout << endl;
    }

    // iii. Search for a student using roll number
    node *search(int r)
    {
        node *temp = root;
        while (temp != NULL)
        {
            if (r < temp->roll)
                temp = temp->left;
            else if (r > temp->roll)
                temp = temp->right;
            else
                return temp;
        }
        return NULL;
    }

    // iv. Display student records in ascending and descending order
    void ascending(node *temp)
    {
        if (temp == NULL)
            return;
        ascending(temp->left);
        cout << "Roll: " << temp->roll << " | Name: " << temp->name << endl;
        ascending(temp->right);
    }

    void descending(node *temp)
    {
        if (temp == NULL)
            return;
        descending(temp->right);
        cout << "Roll: " << temp->roll << " | Name: " << temp->name << endl;
        descending(temp->left);
    }

    // v. Find height and total number of nodes
    int height(node *temp)
    {
        if (temp == NULL)
            return 0;
        return 1 + max(height(temp->left), height(temp->right));
    }

    int totalNodes(node *temp)
    {
        if (temp == NULL)
            return 0;
        return 1 + totalNodes(temp->left) + totalNodes(temp->right);
    }

    // vi. Delete a student record using roll number
    node *minNode(node *temp)
    {
        while (temp != NULL && temp->left != NULL)
            temp = temp->left;
        return temp;
    }

    node *deleteNode(node *tempRoot, int r)
    {
        if (tempRoot == NULL)
            return NULL;

        if (r < tempRoot->roll)
            tempRoot->left = deleteNode(tempRoot->left, r);
        else if (r > tempRoot->roll)
            tempRoot->right = deleteNode(tempRoot->right, r);
        else
        {
            // Node with 0 or 1 child
            if (tempRoot->left == NULL)
            {
                node *temp = tempRoot->right;
                delete tempRoot;
                return temp;
            }
            else if (tempRoot->right == NULL)
            {
                node *temp = tempRoot->left;
                delete tempRoot;
                return temp;
            }

            // Node with 2 children: get inorder successor
            node *temp = minNode(tempRoot->right);
            tempRoot->roll = temp->roll;
            tempRoot->name = temp->name;
            tempRoot->right = deleteNode(tempRoot->right, temp->roll);
        }
        return tempRoot;
    }
};

int main()
{
    bstree t;
    int ch, roll;
    string name;
    char ans;
    node *res;

    // Create BST initially
    do
    {
        cout << "Enter Student Roll Number: ";
        cin >> roll;
        cout << "Enter Student Name: ";
        cin >> name;

        t.insert(roll, name);

        cout << "Do you want to continue (Y/N): ";
        cin >> ans;
    } while (ans == 'Y' || ans == 'y');

    do
    {
        cout << "\n\n===== STUDENT BST MENU =====\n";
        cout << "1. Insert New Student Record\n";
        cout << "2. Non-Recursive Inorder Traversal\n";
        cout << "3. All Recursive Traversals (Inorder, Preorder, Postorder)\n";
        cout << "4. Search Student by Roll Number\n";
        cout << "5. Display Records in Ascending Order\n";
        cout << "6. Display Records in Descending Order\n";
        cout << "7. Height of BST and Total Number of Nodes\n";
        cout << "8. Delete Student Record\n";
        cout << "9. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Enter Roll Number: ";
            cin >> roll;
            cout << "Enter Name: ";
            cin >> name;
            t.insert(roll, name);
            break;

        case 2:
            cout << "\nNon-Recursive Inorder Traversal:\n";
            t.noninorder();
            break;

        case 3:
            cout << "\nRecursive Inorder: ";
            t.inorder(t.root);
            cout << "\nRecursive Preorder: ";
            t.preorder(t.root);
            cout << "\nRecursive Postorder: ";
            t.postorder(t.root);
            cout << endl;
            break;

        case 4:
            cout << "Enter Roll Number to search: ";
            cin >> roll;
            res = t.search(roll);
            if (res != NULL)
                cout << "Student Found! [Roll: " << res->roll << ", Name: " << res->name << "]\n";
            else
                cout << "Student with Roll Number " << roll << " NOT Found.\n";
            break;

        case 5:
            cout << "\nStudent Records in Ascending Order of Roll Number:\n";
            t.ascending(t.root);
            break;

        case 6:
            cout << "\nStudent Records in Descending Order of Roll Number:\n";
            t.descending(t.root);
            break;

        case 7:
            cout << "\nHeight of BST: " << t.height(t.root) << endl;
            cout << "Total Number of Nodes: " << t.totalNodes(t.root) << endl;
            break;

        case 8:
            cout << "Enter Roll Number to delete: ";
            cin >> roll;
            if (t.search(roll) != NULL)
            {
                t.root = t.deleteNode(t.root, roll);
                cout << "Record deleted successfully.\n";
            }
            else
            {
                cout << "Student Record Not Found.\n";
            }
            break;

        case 9:
            cout << "Exiting Student BST Program. Goodbye!\n";
            break;

        default:
            cout << "Invalid Choice! Please enter 1-9.\n";
        }
    } while (ch != 9);

    return 0;
}

