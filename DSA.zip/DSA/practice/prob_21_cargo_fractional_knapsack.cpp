/*
21. Problem:
A transport company has a cargo plane with a maximum weight capacity W.
There are n cargo items available, each having a weight and a profit value.
Write a C++ program using a greedy algorithm to determine the maximum total profit that can be obtained by loading the plane, allowing fractional parts of cargo if necessary (Fractional Knapsack).
Display:
- Weight and profit of each selected item
- Total weight loaded
- Maximum profit obtained
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class CargoItem
{
public:
    int id;
    double weight;
    double profit;
    double ratio;

    CargoItem(int i = 0, double w = 0, double p = 0)
    {
        id = i;
        weight = w;
        profit = p;
        ratio = (w != 0) ? (p / w) : 0;
    }
};

class CargoPlaneKnapsack
{
    int n;
    double W;
    vector<CargoItem> items;

public:
    void input()
    {
        cout << "Enter number of cargo items: ";
        cin >> n;

        items.resize(n);
        cout << "\nEnter weight and profit of each cargo item:\n";
        for (int i = 0; i < n; i++)
        {
            double w, p;
            cout << "Cargo Item " << i + 1 << " [Weight Profit]: ";
            cin >> w >> p;
            items[i] = CargoItem(i + 1, w, p);
        }

        cout << "\nEnter maximum weight capacity of cargo plane (W): ";
        cin >> W;
    }

    void solve()
    {
        // Sort items in descending order of profit/weight ratio using Greedy method
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (items[i].ratio < items[j].ratio)
                {
                    swap(items[i], items[j]);
                }
            }
        }

        double totalWeightLoaded = 0.0;
        double maxProfit = 0.0;

        cout << "\n================ CARGO LOADING DETAILS ================\n";
        cout << "Selected Items Loaded into Plane:\n";

        for (int i = 0; i < n; i++)
        {
            if (totalWeightLoaded + items[i].weight <= W)
            {
                // Item taken completely
                totalWeightLoaded += items[i].weight;
                maxProfit += items[i].profit;

                cout << "-> Item " << items[i].id
                     << ": FULLY Loaded | Weight Loaded: " << items[i].weight
                     << " | Profit Obtained: " << items[i].profit
                     << " | Ratio: " << items[i].ratio << endl;
            }
            else
            {
                // Fractional item taken
                double remainingCap = W - totalWeightLoaded;
                if (remainingCap > 0)
                {
                    double fraction = remainingCap / items[i].weight;
                    double fractionalProfit = fraction * items[i].profit;

                    totalWeightLoaded += remainingCap;
                    maxProfit += fractionalProfit;

                    cout << "-> Item " << items[i].id
                         << ": FRACTION Loaded (" << fraction * 100.0 << "%)"
                         << " | Weight Loaded: " << remainingCap << " / " << items[i].weight
                         << " | Profit Obtained: " << fractionalProfit
                         << " | Ratio: " << items[i].ratio << endl;
                }
                break; // Plane is completely full
            }
        }

        cout << "\n-------------------------------------------------------";
        cout << "\nTotal Weight Loaded into Cargo Plane = " << totalWeightLoaded << " / " << W;
        cout << "\nMaximum Profit Obtained             = " << maxProfit;
        cout << "\n=======================================================\n";
    }
};

int main()
{
    CargoPlaneKnapsack plane;
    plane.input();
    plane.solve();

    return 0;
}

