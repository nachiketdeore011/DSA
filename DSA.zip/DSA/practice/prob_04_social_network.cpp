/*
Problem Statement:
Each user in a social network is connected to others via "friend" relationships. If user A and user B are friends, an undirected edge exists between them.
Write a menu-driven C++ program to represent this social network using both adjacency matrix and adjacency list.
The program should:
- Check if two users are directly connected
- Display all friends of a given user.
*/

#include <iostream>
#include <string>
using namespace std;

#define MAX 10

class graphNode
{
public:
    string friendName;
    graphNode *next;

    graphNode(string name)
    {
        friendName = name;
        next = NULL;
    }
};

class SocialNetwork
{
public:
    int n;
    string users[MAX];
    int adjMatrix[MAX][MAX];
    graphNode *headNode[MAX];

    SocialNetwork()
    {
        n = 0;
        for (int i = 0; i < MAX; i++)
        {
            headNode[i] = NULL;
            for (int j = 0; j < MAX; j++)
                adjMatrix[i][j] = 0;
        }
    }

    int findUser(string name)
    {
        for (int i = 0; i < n; i++)
        {
            if (users[i] == name)
                return i;
        }
        return -1;
    }

    void createUsers()
    {
        cout << "Enter number of users in social network: ";
        cin >> n;

        cout << "\nEnter user names:\n";
        for (int i = 0; i < n; i++)
        {
            cout << "User " << i + 1 << " : ";
            cin >> users[i];
            headNode[i] = new graphNode(users[i]);
        }
    }

    void addFriendships()
    {
        char choice;
        cout << "\nEnter friendships (undirected connections):\n";

        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                cout << "Are " << users[i] << " and " << users[j] << " friends? (Y/N): ";
                cin >> choice;

                if (choice == 'Y' || choice == 'y')
                {
                    // Undirected connection in Adjacency Matrix
                    adjMatrix[i][j] = 1;
                    adjMatrix[j][i] = 1;

                    // Insert j into i's Adjacency List
                    graphNode *nodeJ = new graphNode(users[j]);
                    graphNode *temp1 = headNode[i];
                    while (temp1->next != NULL)
                        temp1 = temp1->next;
                    temp1->next = nodeJ;

                    // Insert i into j's Adjacency List
                    graphNode *nodeI = new graphNode(users[i]);
                    graphNode *temp2 = headNode[j];
                    while (temp2->next != NULL)
                        temp2 = temp2->next;
                    temp2->next = nodeI;
                }
            }
        }
        cout << "\nFriendships added successfully to both Adjacency Matrix and List!\n";
    }

    void displayMatrix()
    {
        cout << "\n--- Social Network: Adjacency Matrix ---\n\t";
        for (int i = 0; i < n; i++)
            cout << users[i] << "\t";
        cout << endl;

        for (int i = 0; i < n; i++)
        {
            cout << users[i] << "\t";
            for (int j = 0; j < n; j++)
            {
                cout << adjMatrix[i][j] << "\t";
            }
            cout << endl;
        }
    }

    void displayList()
    {
        cout << "\n--- Social Network: Adjacency List ---\n";
        for (int i = 0; i < n; i++)
        {
            graphNode *temp = headNode[i];
            cout << temp->friendName << " -> ";
            temp = temp->next;

            while (temp != NULL)
            {
                cout << "[" << temp->friendName << "] -> ";
                temp = temp->next;
            }
            cout << "NULL" << endl;
        }
    }

    // 1. Check if two users are directly connected
    void checkDirectConnection()
    {
        string u1, u2;
        cout << "Enter first user: ";
        cin >> u1;
        cout << "Enter second user: ";
        cin >> u2;

        int i = findUser(u1);
        int j = findUser(u2);

        if (i == -1 || j == -1)
        {
            cout << "Invalid username(s) entered.\n";
            return;
        }

        if (adjMatrix[i][j] == 1)
        {
            cout << "\n[YES] " << u1 << " and " << u2 << " are directly connected (Friends).\n";
        }
        else
        {
            cout << "\n[NO] " << u1 << " and " << u2 << " are NOT directly connected.\n";
        }
    }

    // 2. Display all friends of a given user
    void displayFriendsOfUser()
    {
        string u;
        cout << "Enter user name to display friend list: ";
        cin >> u;

        int idx = findUser(u);
        if (idx == -1)
        {
            cout << "User not found.\n";
            return;
        }

        cout << "\nFriends of " << u << ":\n";
        graphNode *temp = headNode[idx]->next;
        if (temp == NULL)
        {
            cout << u << " has no friends added yet.\n";
            return;
        }

        int count = 0;
        while (temp != NULL)
        {
            count++;
            cout << count << ". " << temp->friendName << endl;
            temp = temp->next;
        }
        cout << "Total Friends: " << count << endl;
    }
};

int main()
{
    SocialNetwork sn;
    int choice;

    do
    {
        cout << "\n========== SOCIAL NETWORK MENU ==========\n";
        cout << "1. Create Users\n";
        cout << "2. Add Friendships (Edges)\n";
        cout << "3. Display Adjacency Matrix\n";
        cout << "4. Display Adjacency List\n";
        cout << "5. Check if Two Users are Directly Connected\n";
        cout << "6. Display All Friends of a Given User\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            sn.createUsers();
            break;
        case 2:
            sn.addFriendships();
            break;
        case 3:
            sn.displayMatrix();
            break;
        case 4:
            sn.displayList();
            break;
        case 5:
            sn.checkDirectConnection();
            break;
        case 6:
            sn.displayFriendsOfUser();
            break;
        case 7:
            cout << "Exiting social network program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice! Please select 1-7.\n";
        }
    } while (choice != 7);

    return 0;
}

