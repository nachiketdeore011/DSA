/*
Problem Statement:
Implement a menu-driven C++ program to manage a library's book catalog using a Binary Search Tree, where each node represents a Book ID.
After constructing the BST, perform the following:
i. Insert a new book
ii. Delete a book from the catalog
iii. Find the book with the smallest and largest Book ID
iv. Display all books in sorted (inorder) order
v. Count the total number of books and leaf nodes in the tree
*/

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

class node
{
public:
    int book_id;
    string title;
    node *left, *right;

    node(int id, string t)
    {
        book_id = id;
        title = t;
        left = NULL;
        right = NULL;
    }
};

class bstree
{
public:
    node *root;

    bstree()
    {
        root = NULL;
    }

    // i. Insert a new book
    void insert(int id, string title)
    {
        node *curr = new node(id, title);
        node *temp;

        if (root == NULL)
        {
            root = curr;
            cout << "Book catalog initialized with root book.\n";
            return;
        }

        temp = root;
        while (temp != NULL)
        {
            if (id > temp->book_id)
            {
                if (temp->right == NULL)
                {
                    temp->right = curr;
                    cout << "Book inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->right;
            }
            else if (id < temp->book_id)
            {
                if (temp->left == NULL)
                {
                    temp->left = curr;
                    cout << "Book inserted successfully.\n";
                    break;
                }
                else
                    temp = temp->left;
            }
            else
            {
                cout << "Duplicate Book ID not allowed!\n";
                delete curr;
                break;
            }
        }
    }

    // iii. Find the book with smallest Book ID
    node *smallest()
    {
        if (root == NULL)
            return NULL;

        node *temp = root;
        while (temp->left != NULL)
            temp = temp->left;

        return temp;
    }

    // iii. Find the book with largest Book ID
    node *largest()
    {
        if (root == NULL)
            return NULL;

        node *temp = root;
        while (temp->right != NULL)
            temp = temp->right;

        return temp;
    }

    // iv. Display all books in sorted (inorder) order
    void displaySorted(node *temp)
    {
        if (temp == NULL)
            return;

        displaySorted(temp->left);
        cout << "Book ID: " << temp->book_id << " | Title: " << temp->title << endl;
        displaySorted(temp->right);
    }

    // v. Count total number of books
    int countTotal(node *temp)
    {
        if (temp == NULL)
            return 0;
        return 1 + countTotal(temp->left) + countTotal(temp->right);
    }

    // v. Count leaf nodes in the tree
    int countLeaf(node *temp)
    {
        if (temp == NULL)
            return 0;
        if (temp->left == NULL && temp->right == NULL)
            return 1;
        return countLeaf(temp->left) + countLeaf(temp->right);
    }

    // ii. Delete a book from catalog
    node *minNode(node *temp)
    {
        while (temp != NULL && temp->left != NULL)
            temp = temp->left;
        return temp;
    }

    node *deleteBook(node *tempRoot, int id)
    {
        if (tempRoot == NULL)
            return NULL;

        if (id < tempRoot->book_id)
            tempRoot->left = deleteBook(tempRoot->left, id);
        else if (id > tempRoot->book_id)
            tempRoot->right = deleteBook(tempRoot->right, id);
        else
        {
            // Case 1 & 2: 0 or 1 child
            if (tempRoot->left == NULL)
            {
                node *temp = tempRoot->right;
                delete tempRoot;
                return temp;
            }
            else if (tempRoot->right == NULL)
            {
                node *temp = tempRoot->left;
                delete tempRoot;
                return temp;
            }

            // Case 3: 2 children
            node *temp = minNode(tempRoot->right);
            tempRoot->book_id = temp->book_id;
            tempRoot->title = temp->title;
            tempRoot->right = deleteBook(tempRoot->right, temp->book_id);
        }
        return tempRoot;
    }

    node *search(int id)
    {
        node *temp = root;
        while (temp != NULL)
        {
            if (id < temp->book_id)
                temp = temp->left;
            else if (id > temp->book_id)
                temp = temp->right;
            else
                return temp;
        }
        return NULL;
    }
};

int main()
{
    bstree catalog;
    int ch, id;
    string title;
    char ans;
    node *tempNode;

    // Create Initial Book Catalog
    do
    {
        cout << "Enter Book ID: ";
        cin >> id;
        cout << "Enter Book Title: ";
        cin >> title;

        catalog.insert(id, title);

        cout << "Do you want to continue (Y/N): ";
        cin >> ans;
    } while (ans == 'Y' || ans == 'y');

    do
    {
        cout << "\n\n===== LIBRARY CATALOG BST MENU =====\n";
        cout << "1. Insert New Book\n";
        cout << "2. Delete Book from Catalog\n";
        cout << "3. Find Smallest and Largest Book ID\n";
        cout << "4. Display All Books in Sorted Order (Inorder)\n";
        cout << "5. Count Total Books and Leaf Nodes\n";
        cout << "6. Exit\n";
        cout << "Enter Choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Enter Book ID: ";
            cin >> id;
            cout << "Enter Book Title: ";
            cin >> title;
            catalog.insert(id, title);
            break;

        case 2:
            cout << "Enter Book ID to delete: ";
            cin >> id;
            if (catalog.search(id) != NULL)
            {
                catalog.root = catalog.deleteBook(catalog.root, id);
                cout << "Book with ID " << id << " deleted successfully from catalog.\n";
            }
            else
            {
                cout << "Book ID not found in catalog.\n";
            }
            break;

        case 3:
            tempNode = catalog.smallest();
            if (tempNode != NULL)
                cout << "\nSmallest Book ID : " << tempNode->book_id << " (Title: " << tempNode->title << ")\n";
            else
                cout << "\nCatalog is empty.\n";

            tempNode = catalog.largest();
            if (tempNode != NULL)
                cout << "Largest Book ID  : " << tempNode->book_id << " (Title: " << tempNode->title << ")\n";
            break;

        case 4:
            cout << "\n--- Books in Catalog (Sorted Order) ---\n";
            catalog.displaySorted(catalog.root);
            break;

        case 5:
            cout << "\nTotal Books in Catalog: " << catalog.countTotal(catalog.root) << endl;
            cout << "Total Leaf Nodes in Tree: " << catalog.countLeaf(catalog.root) << endl;
            break;

        case 6:
            cout << "Exiting Library Catalog System. Goodbye!\n";
            break;

        default:
            cout << "Invalid Choice! Please enter 1-6.\n";
        }
    } while (ch != 6);

    return 0;
}

