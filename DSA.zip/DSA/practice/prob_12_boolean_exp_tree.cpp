/*
12. Problem:
Write a menu-driven C++ program to construct an Expression Tree for a Boolean expression given in prefix form (e.g., |&AB!C).
Perform the following operations:
- Construct and display the tree.
- Traverse using Inorder, Preorder, and Postorder (recursive & non-recursive).
- Simplify the Boolean expression by applying logical laws.
- Swap left and right subtrees and display new traversals.
*/

#include <iostream>
#include <string>
#include <cctype>
#include <stack>
#include <algorithm>
using namespace std;

class node
{
public:
    char exp;
    node *left, *right;

    node(char val = ' ')
    {
        exp = val;
        left = NULL;
        right = NULL;
    }
};

class BooleanTree
{
public:
    node *root;

    BooleanTree()
    {
        root = NULL;
    }

    bool isOperator(char c)
    {
        return (c == '&' || c == '|' || c == '!');
    }

    // Construct Expression Tree using Prefix Boolean expression
    void insert(string exp)
    {
        stack<node *> st;

        for (int i = (int)exp.size() - 1; i >= 0; i--)
        {
            char ch = exp[i];
            if (ch == ' ')
                continue;

            node *newNode = new node(ch);

            if (ch == '!')
            {
                // Unary NOT operator: single operand
                if (!st.empty())
                {
                    newNode->left = st.top();
                    st.pop();
                    newNode->right = NULL;
                }
                st.push(newNode);
            }
            else if (ch == '&' || ch == '|')
            {
                // Binary AND / OR operators: two operands
                if (!st.empty())
                {
                    newNode->left = st.top();
                    st.pop();
                }
                if (!st.empty())
                {
                    newNode->right = st.top();
                    st.pop();
                }
                st.push(newNode);
            }
            else
            {
                // Operand (A, B, C or 0, 1)
                st.push(newNode);
            }
        }

        if (!st.empty())
        {
            root = st.top();
            cout << "Boolean Expression Tree Created Successfully.\n";
        }
        else
        {
            cout << "Invalid Expression!\n";
        }
    }

    // Traversals
    void inorder(node *temp)
    {
        if (temp == NULL)
            return;
        if (temp->left != NULL)
            cout << "( ";
        inorder(temp->left);
        cout << temp->exp << " ";
        inorder(temp->right);
        if (temp->right != NULL)
            cout << ") ";
    }

    void preorder(node *temp)
    {
        if (temp == NULL)
            return;
        cout << temp->exp << " ";
        preorder(temp->left);
        preorder(temp->right);
    }

    void postorder(node *temp)
    {
        if (temp == NULL)
            return;
        postorder(temp->left);
        postorder(temp->right);
        cout << temp->exp << " ";
    }

    // Non-Recursive Inorder
    void noninorder()
    {
        if (root == NULL)
            return;
        stack<node *> st;
        node *temp = root;

        while (temp != NULL || !st.empty())
        {
            while (temp != NULL)
            {
                st.push(temp);
                temp = temp->left;
            }

            temp = st.top();
            st.pop();
            cout << temp->exp << " ";
            temp = temp->right;
        }
        cout << endl;
    }

    // Non-Recursive Preorder
    void nonpreorder()
    {
        if (root == NULL)
            return;
        stack<node *> st;
        st.push(root);

        while (!st.empty())
        {
            node *temp = st.top();
            st.pop();
            cout << temp->exp << " ";

            if (temp->right != NULL)
                st.push(temp->right);
            if (temp->left != NULL)
                st.push(temp->left);
        }
        cout << endl;
    }

    // Non-Recursive Postorder (using 2 stacks)
    void nonpostorder()
    {
        if (root == NULL)
            return;
        stack<node *> s1, s2;
        s1.push(root);

        while (!s1.empty())
        {
            node *temp = s1.top();
            s1.pop();
            s2.push(temp);

            if (temp->left != NULL)
                s1.push(temp->left);
            if (temp->right != NULL)
                s1.push(temp->right);
        }

        while (!s2.empty())
        {
            cout << s2.top()->exp << " ";
            s2.pop();
        }
        cout << endl;
    }

    // Simplify Boolean Expression by Applying Logical Laws
    // Laws applied:
    // !(!A) -> A (Double Negation)
    // !0 -> 1, !1 -> 0 (Complement)
    // A & 1 -> A, A & 0 -> 0, A & A -> A (Identity, Dominance, Idempotence)
    // A | 1 -> 1, A | 0 -> A, A | A -> A
    node *simplify(node *temp)
    {
        if (temp == NULL)
            return NULL;

        temp->left = simplify(temp->left);
        temp->right = simplify(temp->right);

        // Double negation: !(!A) -> A
        if (temp->exp == '!' && temp->left != NULL && temp->left->exp == '!')
        {
            node *res = temp->left->left;
            delete temp->left;
            delete temp;
            return res;
        }

        // Constant NOT: !0 -> 1, !1 -> 0
        if (temp->exp == '!' && temp->left != NULL)
        {
            if (temp->left->exp == '0' || temp->left->exp == 'F')
            {
                delete temp->left;
                temp->exp = '1';
                temp->left = NULL;
            }
            else if (temp->left->exp == '1' || temp->left->exp == 'T')
            {
                delete temp->left;
                temp->exp = '0';
                temp->left = NULL;
            }
        }

        // AND laws (&)
        if (temp->exp == '&' && temp->left != NULL && temp->right != NULL)
        {
            // A & A -> A
            if (temp->left->exp == temp->right->exp)
            {
                node *res = temp->left;
                delete temp->right;
                delete temp;
                return res;
            }
            // A & 0 -> 0 or 0 & A -> 0
            if (temp->left->exp == '0' || temp->right->exp == '0')
            {
                temp->exp = '0';
                temp->left = temp->right = NULL;
            }
            // A & 1 -> A
            else if (temp->right->exp == '1')
            {
                node *res = temp->left;
                delete temp->right;
                delete temp;
                return res;
            }
            // 1 & A -> A
            else if (temp->left->exp == '1')
            {
                node *res = temp->right;
                delete temp->left;
                delete temp;
                return res;
            }
        }

        // OR laws (|)
        if (temp->exp == '|' && temp->left != NULL && temp->right != NULL)
        {
            // A | A -> A
            if (temp->left->exp == temp->right->exp)
            {
                node *res = temp->left;
                delete temp->right;
                delete temp;
                return res;
            }
            // A | 1 -> 1 or 1 | A -> 1
            if (temp->left->exp == '1' || temp->right->exp == '1')
            {
                temp->exp = '1';
                temp->left = temp->right = NULL;
            }
            // A | 0 -> A
            else if (temp->right->exp == '0')
            {
                node *res = temp->left;
                delete temp->right;
                delete temp;
                return res;
            }
            // 0 | A -> A
            else if (temp->left->exp == '0')
            {
                node *res = temp->right;
                delete temp->left;
                delete temp;
                return res;
            }
        }

        return temp;
    }

    // Swap left and right subtrees (mirroring)
    void swapTree(node *temp)
    {
        if (temp == NULL)
            return;

        swap(temp->left, temp->right);
        swapTree(temp->left);
        swapTree(temp->right);
    }
};

int main()
{
    BooleanTree t;
    string exp;
    int ch;

    cout << "Enter Boolean Prefix Expression (e.g., |&AB!C or &|A01): ";
    cin >> exp;

    t.insert(exp);

    do
    {
        cout << "\n\n----- BOOLEAN EXPRESSION TREE MENU -----";
        cout << "\n1. Recursive Inorder Traversal";
        cout << "\n2. Recursive Preorder Traversal";
        cout << "\n3. Recursive Postorder Traversal";
        cout << "\n4. Non-Recursive Inorder Traversal";
        cout << "\n5. Non-Recursive Preorder Traversal";
        cout << "\n6. Non-Recursive Postorder Traversal";
        cout << "\n7. Simplify Boolean Expression (Apply Logical Laws)";
        cout << "\n8. Swap Left and Right Subtrees";
        cout << "\n9. Exit";
        cout << "\nEnter your choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "Recursive Inorder: ";
            t.inorder(t.root);
            cout << endl;
            break;
        case 2:
            cout << "Recursive Preorder: ";
            t.preorder(t.root);
            cout << endl;
            break;
        case 3:
            cout << "Recursive Postorder: ";
            t.postorder(t.root);
            cout << endl;
            break;
        case 4:
            cout << "Non-Recursive Inorder: ";
            t.noninorder();
            break;
        case 5:
            cout << "Non-Recursive Preorder: ";
            t.nonpreorder();
            break;
        case 6:
            cout << "Non-Recursive Postorder: ";
            t.nonpostorder();
            break;
        case 7:
            t.root = t.simplify(t.root);
            cout << "Simplified Expression Tree Successfully!\nNew Inorder: ";
            t.inorder(t.root);
            cout << endl;
            break;
        case 8:
            t.swapTree(t.root);
            cout << "Subtrees Swapped Successfully (Mirror Tree Created).\nNew Inorder: ";
            t.inorder(t.root);
            cout << endl;
            break;
        case 9:
            cout << "Exiting Boolean Tree Program. Goodbye!\n";
            break;
        default:
            cout << "Invalid Choice! Please enter 1-9.\n";
        }
    } while (ch != 9);

    return 0;
}

