/*Assignment 2:- Binary search tree: Write a menu driven C++ program to construct a binary search
tree by inserting the values in the order give, considering at the beginning with an empty
binary search tree, after constructing a binary tree perform the following operations:
i. Insert new node, ii. Find number of nodes in longest path from root, iii. Minimum data
value found in the tree iv. Search a value v. Print values in ascending and descending
order
*/

#include <iostream>
using namespace std;

struct node
{
    int data;
    node *left, *right;
};

node* insert(node* root, int x)
{
    if(root == NULL)
    {
        node* temp = new node;
        temp->data = x;
        temp->left = NULL;
        temp->right = NULL;
        return temp;
    }

    if(x < root->data)
        root->left = insert(root->left, x);
    else if(x > root->data)
        root->right = insert(root->right, x);

    return root;
}

int height(node* root)
{
    if(root == NULL)
        return 0;

    int l = height(root->left);
    int r = height(root->right);

    if(l > r)
        return l + 1;
    else
        return r + 1;
}

void minimum(node* root)
{
    if(root == NULL)
    {
        cout << "Tree is empty";
        return;
    }

    while(root->left != NULL)
        root = root->left;

    cout << "Minimum value = " << root->data << endl;
}

void search(node* root, int x)
{
    if(root == NULL)
        cout << "Value not found" << endl;

    else if(root->data == x)
        cout << "Value found" << endl;

    else if(x < root->data)
        search(root->left, x);

    else
        search(root->right, x);
}

void ascending(node* root)
{
    if(root != NULL)
    {
        ascending(root->left);
        cout << root->data << " ";
        ascending(root->right);
    }
}

void descending(node* root)
{
    if(root != NULL)
    {
        descending(root->right);
        cout << root->data << " ";
        descending(root->left);
    }
}

int main()
{
    node* root = NULL;
    int n, x, ch;

    cout << "Enter number of nodes = ";
    cin >> n;

    cout << "Enter values = ";

    for(int i = 0; i < n; i++)
    {
        cin >> x;
        root = insert(root, x);
    }

    do
    {
        cout << "\n===== BST MENU =====" << endl;
        cout << "1.Insert new node" << endl;
        cout << "2.Longest path from root" << endl;
        cout << "3.Minimum value" << endl;
        cout << "4.Search value" << endl;
        cout << "5.Ascending order" << endl;
        cout << "6.Descending order" << endl;
        cout << "7.Exit" << endl;

        cout << "Enter choice = ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                cout << "Enter value = ";
                cin >> x;
                root = insert(root, x);
                cout << "Node inserted" << endl;
                break;

            case 2:
                cout << "Longest path = " << height(root) << endl;
                break;

            case 3:
                minimum(root);
                break;

            case 4:
                cout << "Enter value = ";
                cin >> x;
                search(root, x);
                break;

            case 5:
                cout << "Ascending = ";
                ascending(root);
                cout << endl;
                break;

            case 6:
                cout << "Descending = ";
                descending(root);
                cout << endl;
                break;

            case 7:
                cout << "Exiting...";
                break;

            default:
                cout << "Invalid choice";
        }

    } while(ch != 7);

    return 0;
}

/*Output :-
Enter number of nodes = 7
Enter values = 50 30 70 20 40 60 80

===== BST MENU =====
1.Insert new node
2.Longest path from root
3.Minimum value
4.Search value
5.Ascending order
6.Descending order
7.Exit

Enter choice = 1
Enter value = 90
Node inserted

Enter choice = 2
Longest path = 4

Enter choice = 3
Minimum value = 20

Enter choice = 4
Enter value = 60
Value found

Enter choice = 5
Ascending = 20 30 40 50 60 70 80 90

Enter choice = 6
Descending = 90 80 70 60 50 40 30 20

Enter choice = 7
Exiting...
*/

