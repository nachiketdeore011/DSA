/*Assignment 6 :- Write a program to solve a 0-1 Knapsack problem using dynamic programming or branch
and bound strategy. */

// dynamic programming

#include <iostream>
using namespace std;

int main()
{
    int n,m;
    cout<<"Enter number of item = ";
    cin>>n;

    int w[n],p[n];

    cout<<"Enter weight and profit of each item = "<<endl;
    for(int i = 0;i<n;i++)
    {
        cout<<"Item "<<i+1<<" : ";
        cin>>w[i]>>p[i];
    }

    cout<<"Enter capacity of knapsack = ";
    cin>>m;
    int dp[n+1][m+1];

    for(int i =1;i <= n;i++)
    {
        for(int j = 1;j <= m;j++)
        {
            if(w[i-1] <= j)
            {
                dp[i][j] = max(p[i-1]+dp[i-1][j-w[i-1]], dp[i-1][j]);
            }
            else
            {
                dp[i][j] = dp[i-1][j];
            }
        }
    }
    cout<<"Maximum profit = "<<dp[n][m]<<endl;
    return 0;
}

/*Output :- 

Enter number of item = 4

Enter weight and profit of each item =
Item 1 : 1 15
Item 2 : 3 20
Item 3 : 4 30
Item 4 : 5 40

Enter capacity of knapsack = 8

Maximum profit = 60

Enter number of item = 3

Enter weight and profit of each item =
Item 1 : 2 10
Item 2 : 3 15
Item 3 : 4 20

Enter capacity of knapsack = 5
Maximum profit = 25
*/
