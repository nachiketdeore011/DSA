#include <iostream>
#include <algorithm>
using namespace std;

int A[100], n = 0;

void MaxHeapify(int i)
{
    int largest = i;
    int l = 2*i, r = 2*i+1;

    if(l <= n && A[l] > A[largest])
        largest = l;

    if(r <= n && A[r] > A[largest])
        largest = r;

    if(largest != i)
    {
        swap(A[i], A[largest]);
        MaxHeapify(largest);
    }
}

void MinHeapify(int i)
{
    int smallest = i;
    int l = 2*i, r = 2*i+1;

    if(l <= n && A[l] < A[smallest])
        smallest = l;

    if(r <= n && A[r] < A[smallest])
        smallest = r;

    if(smallest != i)
    {
        swap(A[i], A[smallest]);
        MinHeapify(smallest);
    }
}

void BuildHeap()
{
    for(int i = n/2; i >= 1; i--)
        MaxHeapify(i);
}

void BuildMinHeap()
{
    for(int i = n/2; i >= 1; i--)
        MinHeapify(i);
}

void Insert(int x)
{
    if(n == 99)
    {
        cout << "Heap Full\n";
        return;
    }

    A[++n] = x;
    BuildHeap();
}

void DeleteMax()
{
    if(n == 0)
    {
        cout << "Heap Empty\n";
        return;
    }

    cout << "Deleted Maximum: " << A[1] << endl;

    swap(A[1], A[n]);
    n--;
    MaxHeapify(1);
}

void HeapSort()
{
    int size = n;
    BuildHeap();

    for(int i = size; i >= 2; i--)
    {
        swap(A[1], A[i]);
        n = i-1;
        MaxHeapify(1);
    }

    n = size;
}

int main()
{
    int ch, x;

    cout << "Enter number of stock prices: ";
    cin >> n;

    if(n < 0 || n > 99)
    {
        cout << "Invalid size";
        return 0;
    }

    cout << "Enter stock prices:\n";

    for(int i = 1; i <= n; i++)
        cin >> A[i];

    BuildHeap();

    do
    {
        cout << "\n1. Insert Price";
        cout << "\n2. Maximum Price";
        cout << "\n3. Minimum Price";
        cout << "\n4. Delete Maximum";
        cout << "\n5. Display Ascending & Descending";
        cout << "\n6. Exit";
        cout << "\nEnter choice: ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                cout << "Enter price: ";
                cin >> x;
                Insert(x);
                break;

            case 2:
                if(n)
                {
                    BuildHeap();
                    cout << "Maximum: " << A[1] << endl;
                }
                else
                    cout << "Heap Empty\n";
                break;

            case 3:
                if(n)
                {
                    BuildMinHeap();
                    cout << "Minimum: " << A[1] << endl;
                    BuildHeap();
                }
                else
                    cout << "Heap Empty\n";
                break;

            case 4:
                DeleteMax();
                break;

            case 5:
                if(n == 0)
                {
                    cout << "Heap Empty\n";
                    break;
                }

                HeapSort();

                cout << "Ascending: ";
                for(int i = 1; i <= n; i++)
                    cout << A[i] << " ";

                cout << "\nDescending: ";
                for(int i = n; i >= 1; i--)
                    cout << A[i] << " ";

                cout << endl;
                ch = 6;
                break;
        }

    } while(ch != 6);

    return 0;
}


/*Enter number of stock prices: 6
Enter stock prices:
45 20 80 10 60 30


1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 2
Maximum: 80

1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 3
Minimum: 10

1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 1
Enter price: 90

1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 2
Maximum: 90

1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 4
Deleted Maximum: 90

1. Insert Price
2. Maximum Price
3. Minimum Price
4. Delete Maximum
5. Display Ascending & Descending
6. Exit
Enter choice: 5
Ascending: 10 20 30 45 60 80
Descending: 80 60 45 30 20 10

*/