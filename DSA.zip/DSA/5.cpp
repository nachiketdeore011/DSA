/*Assignment 5 :- Write a program to solve a fractional Knapsack problem using a greedy method*/

#include <iostream>
using namespace std;

struct Item
{
    int p,w;
    float ratio;
};

int main()
{
    int n,m;
    cout<<"Enter number of items = ";
    cin>>n;
    Item item[n];

    cout<<"Enter profit and weight of each item = "<<endl;
    for(int i = 0;i<n;i++)
    {
        cout<<"Item "<<i+1<<" : ";
        cin>>item[i].p>>item[i].w;
        item[i].ratio = (float)item[i].p/item[i].w;
    }

    cout<<"Enter capacity of kanpsack = ";
    cin>>m;

    //sorting items in decreasing order of profit/weight ratio
    for(int i =0 ;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(item[i].ratio < item[j].ratio)
            {
                Item temp = item[i];
                item[i] = item[j];
                item[j] = temp;
            }
        }
    }

    //greedy method
    float Profit = 0;
    for(int i = 0;i < n;i++)
    {
        if(item[i].w <= m)
        {
            m -= item[i].w;
            Profit += item[i].p;
        }
        else
        {
            Profit += item[i].ratio * m;
            break;
        }
    }
    cout<<"Maximum profit = "<<Profit<<endl;

    return 0;
}

/*Output :- 

Enter number of items = 3

Enter profit and weight of each item =
Item 1 : 60 10
Item 2 : 100 20
Item 3 : 120 30

Enter capacity of knapsack = 50

Maximum profit = 240

Enter number of items = 3

Enter profit and weight of each item =
Item 1 : 40 10
Item 2 : 60 20
Item 3 : 100 30

Enter capacity of knapsack = 70

Maximum profit = 200

*/
