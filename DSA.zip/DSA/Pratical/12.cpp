
/*
============================================================
                    PROBLEM STATEMENT
============================================================

12. Problem:

Write a menu-driven C++ program to construct an Expression
Tree for a Boolean expression given in Prefix form
(e.g. | ! & A B C).

Perform the following operations:

1. Construct and display the tree.

2. Traverse using Inorder, Preorder, and Postorder
   (recursive and non-recursive).

3. Simplify the Boolean expression by applying logical laws.

4. Swap left and right subtrees and display new traversals.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <stack>
#include <vector>
#include <string>
#include <sstream>
using namespace std;

// Node Structure
struct Node
{
    char data;
    Node *left, *right;

    Node(char value)
    {
        data = value;
        left = right = NULL;
    }
};

// Check whether character is an operator
bool isOperator(char ch)
{
    return ch == '!' || ch == '&' || ch == '|';
}

// Create Expression Tree from Prefix Expression
Node* createTree(vector<char>& tokens, int& index)
{
    if(index >= tokens.size())
        return NULL;

    char ch = tokens[index++];

    Node* root = new Node(ch);

    if(ch == '!')
    {
        root->left = createTree(tokens, index);
    }
    else if(ch == '&' || ch == '|')
    {
        root->left = createTree(tokens, index);
        root->right = createTree(tokens, index);
    }

    return root;
}

// Recursive Inorder Traversal
void inorder(Node* root)
{
    if(root == NULL)
        return;

    if(isOperator(root->data))
        cout << "(";

    inorder(root->left);

    cout << root->data;

    inorder(root->right);

    if(isOperator(root->data))
        cout << ")";
}

// Recursive Preorder Traversal
void preorder(Node* root)
{
    if(root == NULL)
        return;

    cout << root->data << " ";

    preorder(root->left);
    preorder(root->right);
}

// Recursive Postorder Traversal
void postorder(Node* root)
{
    if(root == NULL)
        return;

    postorder(root->left);
    postorder(root->right);

    cout << root->data << " ";
}

// Non-Recursive Inorder Traversal
void inorderNR(Node* root)
{
    stack<Node*> s;

    Node* current = root;

    while(current != NULL || !s.empty())
    {
        while(current != NULL)
        {
            s.push(current);
            current = current->left;
        }

        current = s.top();
        s.pop();

        cout << current->data << " ";

        current = current->right;
    }
}

// Non-Recursive Preorder Traversal
void preorderNR(Node* root)
{
    if(root == NULL)
        return;

    stack<Node*> s;

    s.push(root);

    while(!s.empty())
    {
        Node* current = s.top();
        s.pop();

        cout << current->data << " ";

        if(current->right != NULL)
            s.push(current->right);

        if(current->left != NULL)
            s.push(current->left);
    }
}

// Non-Recursive Postorder Traversal
void postorderNR(Node* root)
{
    if(root == NULL)
        return;

    stack<Node*> s1, s2;

    s1.push(root);

    while(!s1.empty())
    {
        Node* current = s1.top();
        s1.pop();

        s2.push(current);

        if(current->left != NULL)
            s1.push(current->left);

        if(current->right != NULL)
            s1.push(current->right);
    }

    while(!s2.empty())
    {
        cout << s2.top()->data << " ";
        s2.pop();
    }
}

// Compare two expression trees
bool isSame(Node* a, Node* b)
{
    if(a == NULL && b == NULL)
        return true;

    if(a == NULL || b == NULL)
        return false;

    return a->data == b->data &&
           isSame(a->left, b->left) &&
           isSame(a->right, b->right);
}

// Check complement expressions A and !A
bool isComplement(Node* a, Node* b)
{
    if(a == NULL || b == NULL)
        return false;

    if(a->data == '!' && isSame(a->left, b))
        return true;

    if(b->data == '!' && isSame(b->left, a))
        return true;

    return false;
}

// Delete an entire tree
void deleteTree(Node* root)
{
    if(root == NULL)
        return;

    deleteTree(root->left);
    deleteTree(root->right);

    delete root;
}

// Boolean Expression Simplification
Node* simplify(Node* root)
{
    if(root == NULL)
        return NULL;

    root->left = simplify(root->left);
    root->right = simplify(root->right);

    // NOT operation
    if(root->data == '!')
    {
        Node* child = root->left;

        // NOT 0 = 1
        if(child->data == '0')
        {
            delete root;
            delete child;
            return new Node('1');
        }

        // NOT 1 = 0
        if(child->data == '1')
        {
            delete root;
            delete child;
            return new Node('0');
        }

        // Double Negation: !!A = A
        if(child->data == '!')
        {
            Node* result = child->left;
            child->left = NULL;

            delete child;
            delete root;

            return result;
        }

        return root;
    }

    // AND and OR operations
    if(root->data == '&' || root->data == '|')
    {
        Node* a = root->left;
        Node* b = root->right;

        // A AND A = A
        // A OR A = A
        if(isSame(a, b))
        {
            deleteTree(b);
            delete root);

            return a;
        }

        // A AND !A = 0
        // A OR !A = 1
        if(isComplement(a, b))
        {
            char result = (root->data == '&') ? '0' : '1';

            deleteTree(root);

            return new Node(result);
        }

        // AND operation
        if(root->data == '&')
        {
            // A AND 0 = 0
            if(a->data == '0' || b->data == '0')
            {
                deleteTree(root);
                return new Node('0');
            }

            // A AND 1 = A
            if(a->data == '1')
            {
                root->left = NULL;
                deleteTree(root);
                return b;
            }

            if(b->data == '1')
            {
                root->right = NULL;
                deleteTree(root);
                return a;
            }
        }

        // OR operation
        if(root->data == '|')
        {
            // A OR 1 = 1
            if(a->data == '1' || b->data == '1')
            {
                deleteTree(root);
                return new Node('1');
            }

            // A OR 0 = A
            if(a->data == '0')
            {
                root->left = NULL;
                deleteTree(root);
                return b;
            }

            if(b->data == '0')
            {
                root->right = NULL;
                deleteTree(root);
                return a;
            }
        }
    }

    return root;
}

// Swap Left and Right Subtrees (Mirror Tree)
void swapSubtrees(Node* root)
{
    if(root == NULL)
        return;

    // Swap only binary operator children
    if(root->data == '&' || root->data == '|')
    {
        swap(root->left, root->right);
    }

    swapSubtrees(root->left);
    swapSubtrees(root->right);
}

// Display Tree
void displayTree(Node* root, int space = 0)
{
    if(root == NULL)
        return;

    space += 5;

    displayTree(root->right, space);

    cout << endl;

    for(int i = 5; i < space; i++)
        cout << " ";

    cout << root->data << endl;

    displayTree(root->left, space);
}

// Display All Traversals
void displayTraversals(Node* root)
{
    cout << "\nRecursive Inorder: ";
    inorder(root);

    cout << "\nRecursive Preorder: ";
    preorder(root);

    cout << "\nRecursive Postorder: ";
    postorder(root);

    cout << "\n\nNon-Recursive Inorder: ";
    inorderNR(root);

    cout << "\nNon-Recursive Preorder: ";
    preorderNR(root);

    cout << "\nNon-Recursive Postorder: ";
    postorderNR(root);

    cout << endl;
}

// Main Function
int main()
{
    Node* root = NULL;

    string expression;

    int choice;

    cout << "Enter Boolean Prefix Expression: ";
    getline(cin, expression);

    // Convert prefix expression into tokens
    vector<char> tokens;

    for(char ch : expression)
    {
        if(ch != ' ' && ch != '\t')
            tokens.push_back(ch);
    }

    // Build Expression Tree
    int index = 0;

    root = createTree(tokens, index);

    if(root == NULL || index != tokens.size())
    {
        cout << "Invalid Prefix Expression!\n";

        deleteTree(root);
        return 0;
    }

    do
    {
        cout << "\n========== EXPRESSION TREE MENU ==========\n";

        cout << "1. Display Expression Tree\n";
        cout << "2. Display Recursive Traversals\n";
        cout << "3. Display Non-Recursive Traversals\n";
        cout << "4. Simplify Boolean Expression\n";
        cout << "5. Swap Left and Right Subtrees\n";
        cout << "6. Display All Traversals\n";
        cout << "7. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "\nExpression Tree:\n";
                displayTree(root);
                break;

            case 2:
                cout << "\nInorder: ";
                inorder(root);

                cout << "\nPreorder: ";
                preorder(root);

                cout << "\nPostorder: ";
                postorder(root);

                cout << endl;
                break;

            case 3:
                cout << "\nNon-Recursive Inorder: ";
                inorderNR(root);

                cout << "\nNon-Recursive Preorder: ";
                preorderNR(root);

                cout << "\nNon-Recursive Postorder: ";
                postorderNR(root);

                cout << endl;
                break;

            case 4:
                root = simplify(root);

                cout << "\nSimplified Expression: ";
                inorder(root);

                cout << "\n";
                break;

            case 5:
                swapSubtrees(root);

                cout << "\nTree after swapping:\n";
                displayTree(root);

                cout << "\nNew Traversals:\n";
                displayTraversals(root);
                break;

            case 6:
                displayTraversals(root);
                break;

            case 7:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while(choice != 7);

    deleteTree(root);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

An Expression Tree is a binary tree used to represent
mathematical and Boolean expressions.

In this program:

- Leaf nodes represent operands (A, B, C).
- Internal nodes represent operators (!, &, |).

2. BOOLEAN OPERATORS

NOT (!):
Performs logical negation.

AND (&):
Returns 1 only when both operands are 1.

OR (|):
Returns 1 when at least one operand is 1.

3. PREFIX EXPRESSION

In Prefix notation, the operator is written before
its operands.

Example:

| ! & A B C

Expression:

(!(A & B) | C)

4. CONSTRUCTION OF EXPRESSION TREE

Steps:

1. Read the prefix expression.
2. Identify the operator.
3. Create a new node.
4. If operator is NOT, create one child.
5. If operator is AND or OR, create two children.
6. If operand is encountered, create a leaf node.
7. Repeat until the expression is completely parsed.

5. TREE TRAVERSALS

A. INORDER

Order:
Left -> Root -> Right

Displays the expression in infix form.

B. PREORDER

Order:
Root -> Left -> Right

Displays the expression in prefix form.

C. POSTORDER

Order:
Left -> Right -> Root

Displays the expression in postfix form.

6. RECURSIVE TRAVERSAL

Recursive traversal uses function calls to visit
left and right subtrees.

It is simple and easy to implement.

7. NON-RECURSIVE TRAVERSAL

Non-recursive traversal uses a Stack instead
of recursive function calls.

Three methods are implemented:

- Inorder using one stack.
- Preorder using one stack.
- Postorder using two stacks.

8. BOOLEAN EXPRESSION SIMPLIFICATION

The program uses the following logical laws:

Identity Laws:

A & 1 = A
A | 0 = A

Domination Laws:

A & 0 = 0
A | 1 = 1

Idempotent Laws:

A & A = A
A | A = A

Complement Laws:

A & !A = 0
A | !A = 1

Double Negation Law:

!!A = A

9. SWAPPING LEFT AND RIGHT SUBTREES

Swapping exchanges the left and right children
of binary operator nodes.

This operation produces the mirror image
of the expression tree.

The program then displays the new traversals.

10. TIME COMPLEXITY

Let n = Number of nodes.

Tree Construction:
O(n)

Inorder Traversal:
O(n)

Preorder Traversal:
O(n)

Postorder Traversal:
O(n)

Non-Recursive Traversals:
O(n)

Simplification:
O(n^2) worst case due to structural comparison.

Swapping Subtrees:
O(n)

11. SPACE COMPLEXITY

Expression Tree:
O(n)

Traversal Stack:
O(n)

Recursive Stack:
O(h)

Where h = Height of the tree.

12. APPLICATIONS

1. Boolean expression evaluation.
2. Compiler design.
3. Logical circuit design.
4. Expression conversion.
5. Mathematical expression processing.
6. Syntax tree construction.

13. ADVANTAGES

1. Represents expressions in tree form.
2. Supports different traversal methods.
3. Simplifies Boolean expressions.
4. Makes expression processing easier.
5. Supports swapping of subtrees.

14. CONCLUSION

The Boolean Expression Tree is successfully implemented
using a Binary Tree.

The program supports tree construction, recursive and
non-recursive traversals, Boolean expression
simplification and swapping of left and right subtrees.

============================================================
                    END OF PROGRAM
============================================================
*/
