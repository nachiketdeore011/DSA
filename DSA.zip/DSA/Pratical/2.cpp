
/*
============================================================
                    PROBLEM STATEMENT
============================================================

2. Problem Statement:

There are railway routes between major cities. If there
is a train route between city A and city B, then there
is an edge between the cities.

The cost of the edge can represent the distance (in km)
or ticket fare between the cities.

Write a menu-driven C++ program to represent this as a
graph using adjacency list.

Each node represents a railway station.

The program should:

1. Check whether two cities are directly connected
   by a train route.

2. Display all possible connections from a given city.

3. Display whether two stations are connected directly
   by one train or more.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

// Structure for storing railway connection
struct Edge
{
    int destination;
    int cost;
};

// Railway Network Class
class RailwayNetwork
{
    int n;

    vector<string> cities;

    // Adjacency List
    vector<vector<Edge>> adj;

public:

    // Constructor
    RailwayNetwork(int size)
    {
        n = size;

        cities.resize(n);
        adj.resize(n);

        for(int i = 0; i < n; i++)
        {
            cout << "Enter city " << i + 1 << ": ";
            getline(cin >> ws, cities[i]);
        }
    }

    // Find city index
    int getCityIndex(string name)
    {
        for(int i = 0; i < n; i++)
        {
            if(cities[i] == name)
                return i;
        }

        return -1;
    }

    // Add railway route
    void addRoute(string city1, string city2, int cost)
    {
        int u = getCityIndex(city1);
        int v = getCityIndex(city2);

        if(u == -1 || v == -1 || u == v || cost < 0)
        {
            cout << "Invalid city or route!\n";
            return;
        }

        // Check duplicate route
        for(auto edge : adj[u])
        {
            if(edge.destination == v)
            {
                cout << "Route already exists!\n";
                return;
            }
        }

        // Undirected graph
        adj[u].push_back({v, cost});
        adj[v].push_back({u, cost});

        cout << "Railway route added successfully!\n";
    }

    // 1. Check direct railway connection
    void checkDirectConnection(string city1, string city2)
    {
        int u = getCityIndex(city1);
        int v = getCityIndex(city2);

        if(u == -1 || v == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        for(auto edge : adj[u])
        {
            if(edge.destination == v)
            {
                cout << "\nDirect railway connection exists!\n";

                cout << "From: " << cities[u] << endl;
                cout << "To: " << cities[v] << endl;
                cout << "Distance / Cost: " << edge.cost << endl;

                return;
            }
        }

        cout << "\nNo direct railway connection exists.\n";
    }

    // 2. Display all connections from a city
    void displayConnections(string city)
    {
        int u = getCityIndex(city);

        if(u == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        cout << "\nConnections from " << cities[u] << ":\n";

        if(adj[u].empty())
        {
            cout << "No railway connections available!\n";
            return;
        }

        for(auto edge : adj[u])
        {
            cout << cities[u] << " -> "
                 << cities[edge.destination]
                 << " | Cost: " << edge.cost << endl;
        }
    }

    // 3. Check connection using BFS
    void checkConnectivity(string city1, string city2)
    {
        int source = getCityIndex(city1);
        int destination = getCityIndex(city2);

        if(source == -1 || destination == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        vector<bool> visited(n, false);

        vector<int> parent(n, -1);

        queue<int> q;

        visited[source] = true;
        q.push(source);

        // BFS Traversal
        while(!q.empty())
        {
            int u = q.front();
            q.pop();

            if(u == destination)
                break;

            for(auto edge : adj[u])
            {
                int v = edge.destination;

                if(!visited[v])
                {
                    visited[v] = true;

                    parent[v] = u;

                    q.push(v);
                }
            }
        }

        // Check connectivity
        if(!visited[destination])
        {
            cout << "\nNo railway connection exists between "
                 << city1 << " and " << city2 << ".\n";

            return;
        }

        // Display connected path
        vector<int> path;

        int current = destination;

        while(current != -1)
        {
            path.push_back(current);

            current = parent[current];
        }

        reverse(path.begin(), path.end());

        cout << "\nRailway connection exists!\n";

        cout << "Connected Path: ";

        for(int i = 0; i < path.size(); i++)
        {
            cout << cities[path[i]];

            if(i != path.size() - 1)
                cout << " -> ";
        }

        cout << "\n";

        if(path.size() == 2)
            cout << "Connection Type: Direct train route.\n";
        else
            cout << "Connection Type: Multiple train routes.\n";
    }
};


// Main Function
int main()
{
    int n, routes;

    cout << "Enter number of cities: ";
    cin >> n;

    if(n <= 0)
    {
        cout << "Invalid number of cities!\n";
        return 0;
    }

    RailwayNetwork railway(n);

    cout << "\nEnter number of railway routes: ";
    cin >> routes;

    if(routes < 0)
    {
        cout << "Invalid number of routes!\n";
        return 0;
    }

    // Input railway routes
    for(int i = 0; i < routes; i++)
    {
        string city1, city2;
        int cost;

        cout << "\nEnter first city: ";
        getline(cin >> ws, city1);

        cout << "Enter second city: ";
        getline(cin >> ws, city2);

        cout << "Enter distance / ticket fare: ";
        cin >> cost;

        railway.addRoute(city1, city2, cost);
    }

    int choice;

    do
    {
        cout << "\n========== RAILWAY NETWORK MENU ==========\n";

        cout << "1. Check Direct Connection\n";
        cout << "2. Display All Connections from a City\n";
        cout << "3. Check Connectivity Between Two Cities\n";
        cout << "4. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        string city1, city2;

        switch(choice)
        {
            case 1:
                cout << "Enter first city: ";
                getline(cin >> ws, city1);

                cout << "Enter second city: ";
                getline(cin >> ws, city2);

                railway.checkDirectConnection(city1, city2);
                break;

            case 2:
                cout << "Enter city name: ";
                getline(cin >> ws, city1);

                railway.displayConnections(city1);
                break;

            case 3:
                cout << "Enter source city: ";
                getline(cin >> ws, city1);

                cout << "Enter destination city: ";
                getline(cin >> ws, city2);

                railway.checkConnectivity(city1, city2);
                break;

            case 4:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice! Try Again.\n";
        }

    } while(choice != 4);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Railway Network is represented using a Graph data
structure.

In this graph:

- Cities represent Vertices (Nodes).
- Railway routes represent Edges.
- Distance or ticket fare represents Edge Weight.

This program uses an Undirected Weighted Graph.

2. ADJACENCY LIST

An Adjacency List is a graph representation in which
each vertex maintains a list of its adjacent vertices.

Each connection stores:
- Destination city
- Distance or ticket fare

Example:

Mumbai -> Pune (150)
Mumbai -> Nashik (180)
Pune -> Nagpur (700)

3. UNDIRECTED WEIGHTED GRAPH

Undirected Graph:

A graph in which edges work in both directions.

If a railway route exists between City A and City B,
then the connection also exists between City B and City A.

Weighted Graph:

A graph in which every edge has a weight such as
distance or ticket fare.

4. BREADTH FIRST SEARCH (BFS)

BFS is a graph traversal algorithm that visits vertices
level by level.

It uses a Queue data structure.

Steps:

1. Start from the source city.
2. Mark the source city as visited.
3. Insert it into the queue.
4. Remove a city from the queue.
5. Visit all its unvisited connected cities.
6. Repeat until the queue becomes empty or the
   destination is found.

5. OPERATIONS PERFORMED

A. Check Direct Connection:

Checks whether a direct railway route exists between
two given cities.

B. Display All Connections:

Displays all directly connected cities from a
given source city with their corresponding costs.

C. Check Connectivity:

Uses BFS to determine whether two cities are connected
directly or through multiple railway routes.

It also displays the connected path.

6. WORKING OF THE PROGRAM

Step 1:
Accept the number of cities.

Step 2:
Enter the names of all cities.

Step 3:
Accept the number of railway routes.

Step 4:
Enter source city, destination city and route cost.

Step 5:
Store connections in the adjacency list.

Step 6:
Display the menu.

Step 7:
Perform the selected operation.

Step 8:
Use BFS to check connectivity when required.

Step 9:
Display the result.

Step 10:
Repeat until the user selects Exit.

7. TIME COMPLEXITY

Let:

V = Number of cities
E = Number of railway routes

Adding a Route:
O(V + Degree of source city)

Checking Direct Connection:
O(V + Degree of source city)

Displaying All Connections:
O(V + Degree of source city)

BFS Traversal:
O(V + E)

8. SPACE COMPLEXITY

Adjacency List:
O(V + E)

Visited Array:
O(V)

Queue:
O(V)

Parent Array:
O(V)

Overall Space Complexity:
O(V + E)

9. APPLICATIONS

1. Railway reservation systems.
2. Railway route planning.
3. Transportation networks.
4. City connectivity management.
5. Finding alternative train routes.
6. Network connectivity analysis.

10. ADVANTAGES

1. Efficient representation of railway networks.
2. Stores distance or ticket fare.
3. Easily checks direct connections.
4. Finds connected routes using BFS.
5. Adjacency List saves memory for sparse graphs.

11. CONCLUSION

The Railway Network is successfully represented
using an Adjacency List.

The program checks direct railway connections,
displays all connected cities and determines whether
two stations are connected through one or more
train routes using BFS.

============================================================
                    END OF PROGRAM
============================================================
*/
