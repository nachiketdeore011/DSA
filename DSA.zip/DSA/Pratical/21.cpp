
/*
============================================================
                    PROBLEM STATEMENT
============================================================

21. Problem:

A transport company has a cargo plane with a maximum
weight capacity W.

There are n cargo items available, each having a weight
and a profit value.

Write a C++ program using a Greedy Algorithm to determine
the maximum total profit that can be obtained by loading
the plane, allowing fractional parts of cargo if necessary
(Fractional Knapsack).

Display:

1. Weight and profit of each selected item.
2. Total weight loaded.
3. Maximum profit obtained.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <algorithm>
#include <iomanip>
using namespace std;

// Structure for storing item details
struct Item
{
    int id;
    double weight;
    double profit;
    double ratio;
};

// Compare items according to profit/weight ratio
bool compare(Item a, Item b)
{
    return a.ratio > b.ratio;
}

int main()
{
    int n;
    double W;

    cout << "Enter number of items: ";
    cin >> n;

    cout << "Enter maximum capacity of cargo plane: ";
    cin >> W;

    if(n <= 0 || W < 0)
    {
        cout << "Invalid input!\n";
        return 0;
    }

    Item items[n];

    // Input item details
    cout << "\nEnter weight and profit of each item:\n";

    for(int i = 0; i < n; i++)
    {
        items[i].id = i + 1;

        cout << "\nItem " << i + 1 << ":\n";

        cout << "Weight: ";
        cin >> items[i].weight;

        cout << "Profit: ";
        cin >> items[i].profit;

        if(items[i].weight <= 0 || items[i].profit < 0)
        {
            cout << "Invalid weight or profit!\n";
            return 0;
        }

        // Calculate profit-to-weight ratio
        items[i].ratio =
            items[i].profit / items[i].weight;
    }

    // Sort items in descending order of ratio
    sort(items, items + n, compare);

    double totalWeight = 0;
    double totalProfit = 0;
    double remaining = W;

    cout << "\n========== SELECTED ITEMS ==========\n";

    cout << fixed << setprecision(2);

    // Greedy selection
    for(int i = 0; i < n; i++)
    {
        if(remaining <= 0)
            break;

        double selectedWeight;
        double selectedProfit;

        if(items[i].weight <= remaining)
        {
            // Take complete item
            selectedWeight = items[i].weight;
            selectedProfit = items[i].profit;
        }
        else
        {
            // Take fractional part of item
            selectedWeight = remaining;

            selectedProfit =
                items[i].ratio * selectedWeight;
        }

        totalWeight += selectedWeight;
        totalProfit += selectedProfit;

        remaining -= selectedWeight;

        cout << "\nItem ID: " << items[i].id;

        cout << "\nWeight Loaded: "
             << selectedWeight;

        cout << "\nProfit Obtained: "
             << selectedProfit;

        cout << "\nFraction Taken: "
             << selectedWeight / items[i].weight;

        cout << "\n";
    }

    // Display final result
    cout << "\n========== FINAL RESULT ==========\n";

    cout << "Total Weight Loaded: "
         << totalWeight << endl;

    cout << "Maximum Profit Obtained: "
         << totalProfit << endl;

    cout << "Remaining Capacity: "
         << remaining << endl;

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

The Fractional Knapsack Problem is an optimization
problem solved using the Greedy Algorithm.

In this problem, a cargo plane has limited weight capacity.
Each item has a specific weight and profit.

The objective is to maximize total profit without
exceeding the maximum capacity.

Unlike 0/1 Knapsack, fractional items are allowed.

2. WHAT IS GREEDY ALGORITHM?

A Greedy Algorithm is an algorithmic technique that
makes the best possible choice at each step.

It selects the locally optimal choice with the aim
of obtaining a globally optimal solution.

In Fractional Knapsack, items are selected according
to their profit-to-weight ratio.

3. PROFIT-TO-WEIGHT RATIO

The ratio is calculated using:

Ratio = Profit / Weight

The item having the highest ratio is selected first.

Example:

Item 1:
Weight = 10
Profit = 60
Ratio = 60 / 10 = 6

Item 2:
Weight = 20
Profit = 100
Ratio = 100 / 20 = 5

Item 3:
Weight = 30
Profit = 120
Ratio = 120 / 30 = 4

Selection order:

Item 1 -> Item 2 -> Item 3

4. WORKING OF THE PROGRAM

Step 1:
Accept the number of items and maximum capacity.

Step 2:
Accept weight and profit of each item.

Step 3:
Calculate profit-to-weight ratio.

Step 4:
Sort all items in descending order of ratio.

Step 5:
Select the item having the highest ratio.

Step 6:
If the complete item fits, load it completely.

Step 7:
Otherwise, load only the required fractional part.

Step 8:
Calculate total weight and total profit.

Step 9:
Display selected items and maximum profit.

5. ALGORITHM

1. Start.
2. Read number of items n.
3. Read maximum capacity W.
4. Read weight and profit of each item.
5. Calculate profit/weight ratio.
6. Sort items in descending order of ratio.
7. Initialize total weight and total profit to zero.
8. Select items according to their ratio.
9. If the complete item fits, select it.
10. Otherwise, select the required fraction.
11. Update total weight and profit.
12. Display selected items and maximum profit.
13. Stop.

6. MATHEMATICAL FORMULA

Profit-to-weight ratio:

Ratio = Profit / Weight

Fraction selected:

Fraction = Remaining Capacity / Item Weight

Profit obtained from fractional item:

Fractional Profit = Fraction * Item Profit

Total Profit:

Maximum Profit = Sum of profits of selected items.

7. TIME COMPLEXITY

Let n = Number of items.

Calculating ratios:
O(n)

Sorting items:
O(n log n)

Selecting items:
O(n)

Overall Time Complexity:

O(n log n)

8. SPACE COMPLEXITY

Storing item details:
O(n)

Overall Auxiliary Space:
O(log n) for the sorting stack in typical
introsort implementation.

Total Space Complexity:
O(n), including item storage.

9. APPLICATIONS

1. Cargo loading systems.
2. Transportation management.
3. Resource allocation.
4. Investment planning.
5. Budget optimization.
6. Supply chain management.

10. ADVANTAGES

1. Simple and easy to implement.
2. Provides maximum profit.
3. Allows fractional selection of items.
4. Efficient sorting-based solution.
5. Avoids unnecessary calculations.

11. DIFFERENCE BETWEEN 0/1 AND FRACTIONAL KNAPSACK

0/1 Knapsack:
- Complete item is selected or rejected.
- Fractional selection is not allowed.
- Commonly solved using Dynamic Programming.

Fractional Knapsack:
- Fractional items are allowed.
- Items are selected using profit/weight ratio.
- Solved optimally using Greedy Algorithm.

12. CONCLUSION

The Fractional Knapsack Problem is successfully
solved using the Greedy Algorithm.

The program calculates profit-to-weight ratios,
sorts items in descending order and selects complete
or fractional items to maximize total profit without
exceeding the cargo plane's capacity.

============================================================
                    END OF PROGRAM
============================================================
*/
