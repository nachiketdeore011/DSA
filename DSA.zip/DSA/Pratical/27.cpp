
/*
============================================================
                    PROBLEM STATEMENT
============================================================

27. Problem:

A logistics company has a truck with a maximum weight
capacity W.

There are n cargo boxes, each having a weight and value
(profit).

Each box can either be fully loaded or not loaded at all
(no fractions allowed).

Using Dynamic Programming or Branch and Bound, write a
C++ program to find the combination of boxes that
maximizes total profit while keeping total weight <= W.

Output the selected boxes, total weight used, and
total profit.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int n, W;

    cout << "Enter number of boxes: ";
    cin >> n;

    cout << "Enter maximum truck capacity: ";
    cin >> W;

    int weight[n], profit[n];

    cout << "\nEnter weight and profit of each box:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "Box " << i + 1 << ":\n";

        cout << "Weight: ";
        cin >> weight[i];

        cout << "Profit: ";
        cin >> profit[i];
    }

    // Create DP table
    vector<vector<int>> dp(n + 1,
                           vector<int>(W + 1, 0));

    // Dynamic Programming
    for(int i = 1; i <= n; i++)
    {
        for(int w = 0; w <= W; w++)
        {
            // If current box weight is within capacity
            if(weight[i - 1] <= w)
            {
                dp[i][w] = max(
                    dp[i - 1][w],
                    profit[i - 1] +
                    dp[i - 1][w - weight[i - 1]]
                );
            }
            else
            {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    // Maximum profit
    int maxProfit = dp[n][W];

    // Find selected boxes
    vector<int> selected;

    int w = W;

    for(int i = n; i > 0; i--)
    {
        if(dp[i][w] != dp[i - 1][w])
        {
            selected.push_back(i);

            w = w - weight[i - 1];
        }
    }

    // Display result
    int totalWeight = 0;

    cout << "\n========== RESULT ==========\n";

    cout << "Selected Boxes:\n";

    for(int i = selected.size() - 1; i >= 0; i--)
    {
        int box = selected[i];

        cout << "Box " << box
             << " | Weight: " << weight[box - 1]
             << " | Profit: " << profit[box - 1]
             << endl;

        totalWeight += weight[box - 1];
    }

    cout << "\nTotal Weight Used: "
         << totalWeight << endl;

    cout << "Maximum Total Profit: "
         << maxProfit << endl;

    cout << "Remaining Capacity: "
         << W - totalWeight << endl;

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

The 0/1 Knapsack Problem is a classic optimization problem
in computer science.

In this problem, we have a bag or truck with limited
capacity. Each item has a specific weight and profit.

Our objective is to select items in such a way that
maximum profit is obtained without exceeding the
maximum capacity.

2. WHAT IS 0/1 KNAPSACK?

0/1 means:

0 = Do not select the item.
1 = Select the complete item.

Each box can be selected only once.

Fractions of boxes are not allowed.

3. DYNAMIC PROGRAMMING

Dynamic Programming is an algorithmic technique that
solves a complex problem by dividing it into smaller
overlapping subproblems.

It stores previously calculated results to avoid
repeated calculations.

4. FORMULA

Let:

n = Number of boxes
W = Maximum capacity
weight[i] = Weight of box i
profit[i] = Profit of box i
dp[i][w] = Maximum profit using first i boxes with
           capacity w.

The recurrence relation is:

If weight[i-1] <= w:

dp[i][w] = max(
    dp[i-1][w],

    profit[i-1] + dp[i-1][w-weight[i-1]]
)

Otherwise:

dp[i][w] = dp[i-1][w]

5. WORKING OF THE PROGRAM

Step 1:
Accept the number of boxes and truck capacity.

Step 2:
Accept the weight and profit of each box.

Step 3:
Create a DP table of size (n+1) x (W+1).

Step 4:
Calculate the maximum profit by either selecting
or rejecting each box.

Step 5:
Find the maximum profit from dp[n][W].

Step 6:
Trace back through the DP table to identify
the selected boxes.

Step 7:
Display selected boxes, total weight and maximum profit.

6. ALGORITHM

1. Start.
2. Read number of boxes n.
3. Read maximum capacity W.
4. Read weight and profit of all boxes.
5. Initialize the DP table with zero.
6. Apply the 0/1 Knapsack recurrence relation.
7. Calculate maximum profit.
8. Trace back to find selected boxes.
9. Calculate total weight.
10. Display selected boxes, total weight and profit.
11. Stop.

7. TIME COMPLEXITY

The DP table contains (n+1) x (W+1) elements.

Time Complexity = O(n x W)

8. SPACE COMPLEXITY

The DP table requires (n+1) x (W+1) memory.

Space Complexity = O(n x W)

9. APPLICATIONS

1. Cargo loading in trucks and ships.
2. Budget allocation.
3. Resource management.
4. Investment selection.
5. Project selection.
6. Warehouse management.

10. ADVANTAGES

1. Finds the optimal solution.
2. Avoids repeated calculations.
3. Handles limited capacity efficiently.
4. Guarantees maximum profit for the given inputs.

11. CONCLUSION

The 0/1 Knapsack Problem is successfully solved using
Dynamic Programming.

The program selects the combination of boxes that
provides maximum profit without exceeding the truck's
maximum weight capacity.

============================================================
                    END OF PROGRAM
============================================================
*/
