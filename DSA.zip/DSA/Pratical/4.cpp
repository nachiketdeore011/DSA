
/*
============================================================
                    PROBLEM STATEMENT
============================================================

4. Problem Statement:

Each user in a social network is connected to others via
"friend" relationships.

If User A and User B are friends, an undirected edge
exists between them.

Write a menu-driven C++ program to represent this social
network using both adjacency matrix and adjacency list.

The program should:

1. Check if two users are directly connected.
2. Display all friends of a given user.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

class SocialNetwork
{
    int n;

    vector<string> users;

    // Adjacency Matrix
    vector<vector<int>> matrix;

    // Adjacency List
    vector<vector<int>> adj;

public:

    // Constructor
    SocialNetwork(int size)
    {
        n = size;

        users.resize(n);

        matrix.resize(n, vector<int>(n, 0));

        adj.resize(n);

        for(int i = 0; i < n; i++)
        {
            cout << "Enter User " << i + 1 << " name: ";
            getline(cin >> ws, users[i]);
        }
    }

    // Find user index
    int getUserIndex(string name)
    {
        for(int i = 0; i < n; i++)
        {
            if(users[i] == name)
                return i;
        }

        return -1;
    }

    // Add friendship
    void addFriendship(string user1, string user2)
    {
        int u = getUserIndex(user1);
        int v = getUserIndex(user2);

        if(u == -1 || v == -1 || u == v)
        {
            cout << "Invalid user or friendship!\n";
            return;
        }

        if(matrix[u][v] == 1)
        {
            cout << "Friendship already exists!\n";
            return;
        }

        // Undirected Graph
        matrix[u][v] = 1;
        matrix[v][u] = 1;

        adj[u].push_back(v);
        adj[v].push_back(u);

        cout << "Friendship added successfully!\n";
    }

    // 1. Check direct friendship
    void checkFriendship(string user1, string user2)
    {
        int u = getUserIndex(user1);
        int v = getUserIndex(user2);

        if(u == -1 || v == -1)
        {
            cout << "Invalid user name!\n";
            return;
        }

        if(matrix[u][v] == 1)
        {
            cout << "\n" << users[u]
                 << " and " << users[v]
                 << " are directly connected as friends.\n";
        }
        else
        {
            cout << "\n" << users[u]
                 << " and " << users[v]
                 << " are not directly connected.\n";
        }
    }

    // 2. Display all friends of a user
    void displayFriends(string name)
    {
        int u = getUserIndex(name);

        if(u == -1)
        {
            cout << "Invalid user name!\n";
            return;
        }

        cout << "\nFriends of " << users[u] << ":\n";

        if(adj[u].empty())
        {
            cout << "No friends found!\n";
            return;
        }

        for(int v : adj[u])
        {
            cout << users[v] << endl;
        }
    }

    // Display Adjacency Matrix
    void displayMatrix()
    {
        cout << "\n========== ADJACENCY MATRIX ==========\n";

        cout << "\t";

        for(int i = 0; i < n; i++)
        {
            cout << users[i] << "\t";
        }

        cout << endl;

        for(int i = 0; i < n; i++)
        {
            cout << users[i] << "\t";

            for(int j = 0; j < n; j++)
            {
                cout << matrix[i][j] << "\t";
            }

            cout << endl;
        }
    }

    // Display Adjacency List
    void displayList()
    {
        cout << "\n========== ADJACENCY LIST ==========\n";

        for(int i = 0; i < n; i++)
        {
            cout << users[i] << " -> ";

            for(int v : adj[i])
            {
                cout << users[v] << " ";
            }

            cout << endl;
        }
    }
};


// Main Function
int main()
{
    int n, m;

    cout << "Enter number of users: ";
    cin >> n;

    if(n <= 0)
    {
        cout << "Invalid number of users!\n";
        return 0;
    }

    SocialNetwork network(n);

    cout << "\nEnter number of friendships: ";
    cin >> m;

    if(m < 0)
    {
        cout << "Invalid number of friendships!\n";
        return 0;
    }

    // Input initial friendships
    for(int i = 0; i < m; i++)
    {
        string user1, user2;

        cout << "\nEnter first user: ";
        getline(cin >> ws, user1);

        cout << "Enter second user: ";
        getline(cin >> ws, user2);

        network.addFriendship(user1, user2);
    }

    int choice;

    do
    {
        cout << "\n========== SOCIAL NETWORK MENU ==========\n";

        cout << "1. Add New Friendship\n";
        cout << "2. Check Direct Friendship\n";
        cout << "3. Display All Friends of a User\n";
        cout << "4. Display Adjacency Matrix\n";
        cout << "5. Display Adjacency List\n";
        cout << "6. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        string user1, user2;

        switch(choice)
        {
            case 1:
                cout << "Enter first user: ";
                getline(cin >> ws, user1);

                cout << "Enter second user: ";
                getline(cin >> ws, user2);

                network.addFriendship(user1, user2);
                break;

            case 2:
                cout << "Enter first user: ";
                getline(cin >> ws, user1);

                cout << "Enter second user: ";
                getline(cin >> ws, user2);

                network.checkFriendship(user1, user2);
                break;

            case 3:
                cout << "Enter user name: ";
                getline(cin >> ws, user1);

                network.displayFriends(user1);
                break;

            case 4:
                network.displayMatrix();
                break;

            case 5:
                network.displayList();
                break;

            case 6:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice! Try Again.\n";
        }

    } while(choice != 6);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Social Network is represented using a Graph data
structure.

In this graph:

- Users represent Vertices (Nodes).
- Friend relationships represent Edges.

This program uses an Undirected Graph because friendship
exists in both directions.

2. ADJACENCY MATRIX

An Adjacency Matrix is a two-dimensional array used to
represent connections between vertices.

If two users are friends:

matrix[i][j] = 1

If two users are not friends:

matrix[i][j] = 0

Example:

       A    B    C
A      0    1    1
B      1    0    0
C      1    0    0

Here:
- A is friends with B.
- A is friends with C.
- B and C are not directly friends.

3. ADJACENCY LIST

An Adjacency List stores all connected users for
each vertex.

Example:

A -> B, C
B -> A
C -> A

It stores the friends of each user.

4. UNDIRECTED GRAPH

An Undirected Graph is a graph in which edges work
in both directions.

If User A is connected to User B, then User B is
also connected to User A.

Therefore:

matrix[u][v] = 1
matrix[v][u] = 1

5. OPERATIONS PERFORMED

A. Add New Friendship:

Creates a friendship between two users and updates
both adjacency matrix and adjacency list.

B. Check Direct Friendship:

Checks whether two users are directly connected
using the adjacency matrix.

C. Display All Friends:

Displays all friends of a given user using
the adjacency list.

D. Display Adjacency Matrix:

Displays all user connections in matrix format.

E. Display Adjacency List:

Displays the friends of every user.

6. WORKING OF THE PROGRAM

Step 1:
Accept the number of users.

Step 2:
Enter the names of all users.

Step 3:
Accept the number of friendships.

Step 4:
Enter the names of two users for each friendship.

Step 5:
Store connections in adjacency matrix and adjacency list.

Step 6:
Display the menu.

Step 7:
Perform the selected operation.

Step 8:
Display the result.

Step 9:
Repeat until the user selects Exit.

7. TIME COMPLEXITY

Let:

V = Number of users
E = Number of friendships

Adding Friendship:
O(V + Degree of user)

Checking Direct Friendship:
O(V) for name lookup and O(1) for matrix checking.

Displaying All Friends:
O(V + Degree of user)

Displaying Adjacency Matrix:
O(V^2)

Displaying Adjacency List:
O(V + E)

8. SPACE COMPLEXITY

Adjacency Matrix:
O(V^2)

Adjacency List:
O(V + E)

Overall Space Complexity:
O(V^2 + E)

9. APPLICATIONS

1. Facebook friendship networks.
2. Instagram social connections.
3. LinkedIn professional networks.
4. Community detection.
5. Social network analysis.
6. Friend recommendation systems.

10. ADVANTAGES

1. Represents friendships clearly.
2. Checks direct friendship quickly.
3. Displays all friends of a user.
4. Supports adding new friendships.
5. Uses two different graph representations.

11. CONCLUSION

The Social Network is successfully represented using
an Adjacency Matrix and Adjacency List.

The program performs friendship insertion, direct
friendship checking and displays all friends of
a given user.

============================================================
                    END OF PROGRAM
============================================================
*/
