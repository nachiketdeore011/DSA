
/*
============================================================
                    PROBLEM STATEMENT
============================================================

38. Representation of Flight Routes between Cities using
    Adjacency List

There are several cities connected by direct flights. If a
flight exists between city A and city B, there is an edge
between the corresponding nodes in the graph. The weight
of the edge represents the time taken (in hours) or cost
(in currency units) of the flight. Represent this flight
network using an Adjacency List and perform the following
operations.

1. Check if a Direct Flight Exists between city A and city B
   with time or cost.

2. Display All Available Flights with their corresponding
   time and cost.

3. Count Total Flights from a City.

4. Find All Reachable Cities from a Source City using
   matrix traversal.

5. If direct flight is not available display all connected
   flights path.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
#include <queue>
#include <string>
using namespace std;

struct Flight
{
    int destination;
    float time;
    float cost;
};

class FlightNetwork
{
    int n;

    vector<string> cities;

    // Adjacency List
    vector<vector<Flight>> adj;

    // Adjacency Matrix
    vector<vector<int>> matrix;

public:

    FlightNetwork(int size)
    {
        n = size;

        cities.resize(n);
        adj.resize(n);
        matrix.resize(n, vector<int>(n, 0));

        for(int i = 0; i < n; i++)
        {
            cout << "Enter city " << i + 1 << ": ";
            cin >> cities[i];
        }
    }

    // Find city index
    int getCityIndex(string name)
    {
        for(int i = 0; i < n; i++)
        {
            if(cities[i] == name)
                return i;
        }

        return -1;
    }

    // Add a direct flight
    void addFlight(string source, string destination,
                   float time, float cost)
    {
        int u = getCityIndex(source);
        int v = getCityIndex(destination);

        if(u == -1 || v == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        adj[u].push_back({v, time, cost});

        matrix[u][v] = 1;

        cout << "Flight added successfully!\n";
    }

    // 1. Check direct flight
    void checkDirectFlight(string source, string destination)
    {
        int u = getCityIndex(source);
        int v = getCityIndex(destination);

        if(u == -1 || v == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        for(auto f : adj[u])
        {
            if(f.destination == v)
            {
                cout << "\nDirect flight is available!\n";
                cout << "Time: " << f.time << " hours\n";
                cout << "Cost: " << f.cost << " currency units\n";
                return;
            }
        }

        cout << "\nDirect flight is not available.\n";

        cout << "Searching for connected flight path...\n";

        findFlightPath(u, v);
    }

    // 2. Display all available flights
    void displayFlights()
    {
        cout << "\n========== AVAILABLE FLIGHTS ==========\n";

        for(int i = 0; i < n; i++)
        {
            for(auto f : adj[i])
            {
                cout << cities[i] << " -> "
                     << cities[f.destination];

                cout << " | Time: " << f.time << " hours";
                cout << " | Cost: " << f.cost << endl;
            }
        }
    }

    // 3. Count total flights from a city
    void countFlights(string source)
    {
        int u = getCityIndex(source);

        if(u == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        cout << "Total flights from " << cities[u]
             << " = " << adj[u].size() << endl;
    }

    // 4. Find all reachable cities using matrix BFS
    void reachableCities(string source)
    {
        int s = getCityIndex(source);

        if(s == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        vector<bool> visited(n, false);

        queue<int> q;

        visited[s] = true;
        q.push(s);

        cout << "\nReachable cities from "
             << cities[s] << ":\n";

        cout << cities[s] << endl;

        while(!q.empty())
        {
            int u = q.front();
            q.pop();

            for(int v = 0; v < n; v++)
            {
                if(matrix[u][v] == 1 && !visited[v])
                {
                    visited[v] = true;
                    q.push(v);

                    cout << cities[v] << endl;
                }
            }
        }
    }

    // 5. Find connected flight path using BFS
    void findFlightPath(int source, int destination)
    {
        vector<bool> visited(n, false);

        vector<int> parent(n, -1);

        queue<int> q;

        visited[source] = true;
        q.push(source);

        bool found = false;

        while(!q.empty())
        {
            int u = q.front();
            q.pop();

            if(u == destination)
            {
                found = true;
                break;
            }

            for(int v = 0; v < n; v++)
            {
                if(matrix[u][v] == 1 && !visited[v])
                {
                    visited[v] = true;
                    parent[v] = u;

                    q.push(v);
                }
            }
        }

        if(!found)
        {
            cout << "No connected flight path available!\n";
            return;
        }

        vector<int> path;

        int current = destination;

        while(current != -1)
        {
            path.push_back(current);
            current = parent[current];
        }

        cout << "\nConnected flight path:\n";

        for(int i = path.size() - 1; i >= 0; i--)
        {
            cout << cities[path[i]];

            if(i != 0)
                cout << " -> ";
        }

        cout << endl;
    }
};

// Main Function
int main()
{
    int n, m;

    cout << "Enter number of cities: ";
    cin >> n;

    FlightNetwork network(n);

    cout << "\nEnter number of direct flights: ";
    cin >> m;

    for(int i = 0; i < m; i++)
    {
        string source, destination;
        float time, cost;

        cout << "\nEnter source city: ";
        cin >> source;

        cout << "Enter destination city: ";
        cin >> destination;

        cout << "Enter flight time (hours): ";
        cin >> time;

        cout << "Enter flight cost: ";
        cin >> cost;

        network.addFlight(source, destination, time, cost);
    }

    int choice;

    do
    {
        cout << "\n========== FLIGHT NETWORK MENU ==========\n";

        cout << "1. Check Direct Flight\n";
        cout << "2. Display All Available Flights\n";
        cout << "3. Count Total Flights from a City\n";
        cout << "4. Find All Reachable Cities\n";
        cout << "5. Find Connected Flight Path\n";
        cout << "6. Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        string source, destination;

        switch(choice)
        {
            case 1:
                cout << "Enter source city: ";
                cin >> source;

                cout << "Enter destination city: ";
                cin >> destination;

                network.checkDirectFlight(source, destination);
                break;

            case 2:
                network.displayFlights();
                break;

            case 3:
                cout << "Enter source city: ";
                cin >> source;

                network.countFlights(source);
                break;

            case 4:
                cout << "Enter source city: ";
                cin >> source;

                network.reachableCities(source);
                break;

            case 5:
                cout << "Enter source city: ";
                cin >> source;

                cout << "Enter destination city: ";
                cin >> destination;

                {
                    // Use the direct-flight check to validate cities
                    // and search for an alternative path.
                    network.checkDirectFlight(source, destination);
                }
                break;

            case 6:
                cout << "Exiting program...\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }

    } while(choice != 6);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Flight Network is represented using a Graph data structure.

In this graph:
- Cities represent Vertices (Nodes).
- Direct flights represent Edges.
- Flight time and cost represent Edge Weights.

An Adjacency List is used to store the connections between
different cities.

2. ADJACENCY LIST

An Adjacency List is a graph representation in which every
vertex maintains a list of its adjacent vertices.

In this program, each city stores:
- Destination city
- Flight time
- Flight cost

Example:

Mumbai -> Pune (Time: 1 hour, Cost: 2000)
Mumbai -> Delhi (Time: 2 hours, Cost: 5000)
Pune -> Nashik (Time: 1 hour, Cost: 1000)

3. ADJACENCY MATRIX

An Adjacency Matrix is a two-dimensional array used to
represent connections between vertices.

If a direct flight exists:

matrix[i][j] = 1

If a direct flight does not exist:

matrix[i][j] = 0

The matrix is used in this program for BFS traversal.

4. BREADTH FIRST SEARCH (BFS)

BFS is a graph traversal algorithm that visits vertices
level by level.

It uses a Queue data structure.

Steps:
1. Start from the source city.
2. Mark the source city as visited.
3. Insert it into the queue.
4. Remove a city from the queue.
5. Visit all its unvisited connected cities.
6. Repeat until the queue becomes empty.

BFS is used to find reachable cities and an alternative
flight path.

5. OPERATIONS PERFORMED

A. Check Direct Flight:
Checks whether a direct flight exists between two cities
and displays its time and cost.

B. Display All Available Flights:
Displays all direct flight connections with their
corresponding time and cost.

C. Count Total Flights:
Counts the number of outgoing direct flights from a
particular city.

D. Find Reachable Cities:
Uses BFS traversal on the adjacency matrix to display
all cities reachable from the source city.

E. Find Connected Flight Path:
If a direct flight is unavailable, BFS searches for an
alternative connected route between the two cities.

6. TIME COMPLEXITY

Let:
V = Number of cities (vertices)
E = Number of direct flights (edges)

1. Add Flight:
   O(1) for insertion, excluding city-name lookup.

2. Check Direct Flight:
   O(V + degree of source city)

3. Display All Flights:
   O(V + E)

4. Count Total Flights:
   O(1) after city lookup.

5. Find Reachable Cities using Matrix BFS:
   O(V^2)

6. Find Connected Flight Path using Matrix BFS:
   O(V^2)

Note: City-name lookup takes O(V).

7. SPACE COMPLEXITY

Adjacency List: O(V + E)

Adjacency Matrix: O(V^2)

BFS Visited Array and Queue: O(V)

Overall Graph Storage: O(V^2 + E)

8. APPLICATIONS

1. Airline reservation systems.
2. Flight route planning.
3. Railway route management.
4. Road transportation networks.
5. Network connectivity analysis.
6. Finding alternative travel routes.

9. ADVANTAGES

1. Efficient representation of sparse graphs.
2. Easy to add and display flight connections.
3. Helps find reachable cities.
4. Supports alternative route searching.
5. Stores flight time and cost information.

10. CONCLUSION

The Flight Network is successfully represented using
an Adjacency List and Adjacency Matrix.

The program performs direct flight checking, displays
available flights, counts outgoing flights, finds
reachable cities and searches for alternative flight
paths using BFS.

============================================================
                    END OF PROGRAM
============================================================
*/
