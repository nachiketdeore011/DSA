
/*
============================================================
                    PROBLEM STATEMENT
============================================================

9. Problem Statement:

Create a menu-driven C++ program to store and manage
employee data using a Binary Search Tree.

Each node stores Employee ID and Salary.

After constructing the BST, perform:

i.   Insert new employee data.

ii.  Search for an employee by ID.

iii. Find the employee with minimum and maximum salary.

iv.  Display all employee IDs in ascending and descending
     order.

v.   Display the height of the BST and count leaf nodes.

vi.  Write all traversal functions (write preorder –
     non-recursive function).

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <stack>
using namespace std;

// Node structure
struct Node
{
    int id;
    float salary;

    Node *left, *right;
};

// Create new employee node
Node* createNode(int id, float salary)
{
    Node* newNode = new Node;

    newNode->id = id;
    newNode->salary = salary;

    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

// Insert employee into BST
Node* insert(Node* root, int id, float salary)
{
    if(root == NULL)
        return createNode(id, salary);

    if(id < root->id)
        root->left = insert(root->left, id, salary);

    else if(id > root->id)
        root->right = insert(root->right, id, salary);

    else
        cout << "Employee ID already exists!\n";

    return root;
}

// Search employee by ID
Node* search(Node* root, int id)
{
    if(root == NULL || root->id == id)
        return root;

    if(id < root->id)
        return search(root->left, id);

    return search(root->right, id);
}

// Find minimum and maximum salary
void findMinMaxSalary(Node* root)
{
    if(root == NULL)
    {
        cout << "No employee records available!\n";
        return;
    }

    Node* minEmp = root;
    Node* maxEmp = root;

    // Traverse entire tree
    stack<Node*> s;

    Node* current = root;

    while(current != NULL || !s.empty())
    {
        while(current != NULL)
        {
            s.push(current);
            current = current->left;
        }

        current = s.top();
        s.pop();

        if(current->salary < minEmp->salary)
            minEmp = current;

        if(current->salary > maxEmp->salary)
            maxEmp = current;

        current = current->right;
    }

    cout << "\nEmployee with Minimum Salary:\n";

    cout << "Employee ID: " << minEmp->id << endl;
    cout << "Salary: " << minEmp->salary << endl;

    cout << "\nEmployee with Maximum Salary:\n";

    cout << "Employee ID: " << maxEmp->id << endl;
    cout << "Salary: " << maxEmp->salary << endl;
}

// Inorder Traversal (Ascending Order)
void inorder(Node* root)
{
    if(root == NULL)
        return;

    inorder(root->left);

    cout << root->id << " ";

    inorder(root->right);
}

// Reverse Inorder Traversal (Descending Order)
void descending(Node* root)
{
    if(root == NULL)
        return;

    descending(root->right);

    cout << root->id << " ";

    descending(root->left);
}

// Preorder Traversal (Non-Recursive)
void preorder(Node* root)
{
    if(root == NULL)
        return;

    stack<Node*> s;

    s.push(root);

    while(!s.empty())
    {
        Node* current = s.top();
        s.pop();

        cout << current->id << " ";

        if(current->right != NULL)
            s.push(current->right);

        if(current->left != NULL)
            s.push(current->left);
    }
}

// Postorder Traversal
void postorder(Node* root)
{
    if(root == NULL)
        return;

    postorder(root->left);

    postorder(root->right);

    cout << root->id << " ";
}

// Calculate height of BST
int height(Node* root)
{
    if(root == NULL)
        return 0;

    int leftHeight = height(root->left);

    int rightHeight = height(root->right);

    return 1 + max(leftHeight, rightHeight);
}

// Count leaf nodes
int countLeafNodes(Node* root)
{
    if(root == NULL)
        return 0;

    if(root->left == NULL && root->right == NULL)
        return 1;

    return countLeafNodes(root->left) +
           countLeafNodes(root->right);
}

// Display all traversals
void displayTraversals(Node* root)
{
    if(root == NULL)
    {
        cout << "Tree is empty!\n";
        return;
    }

    cout << "\nInorder Traversal: ";
    inorder(root);

    cout << "\nPreorder Traversal (Non-Recursive): ";
    preorder(root);

    cout << "\nPostorder Traversal: ";
    postorder(root);

    cout << endl;
}

// Main Function
int main()
{
    Node* root = NULL;

    int choice, id;
    float salary;

    do
    {
        cout << "\n\n========== EMPLOYEE BST MENU ==========\n";

        cout << "1. Insert Employee Data\n";
        cout << "2. Search Employee by ID\n";
        cout << "3. Find Minimum and Maximum Salary\n";
        cout << "4. Display Employee IDs in Ascending Order\n";
        cout << "5. Display Employee IDs in Descending Order\n";
        cout << "6. Display Height and Leaf Nodes\n";
        cout << "7. Display All Tree Traversals\n";
        cout << "8. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter Employee ID: ";
                cin >> id;

                cout << "Enter Salary: ";
                cin >> salary;

                if(salary < 0)
                {
                    cout << "Invalid salary!\n";
                    break;
                }

                {
                    bool duplicate = false;
                    Node* temp = search(root, id);

                    if(temp != NULL)
                        duplicate = true;

                    if(duplicate)
                        cout << "Employee ID already exists!\n";
                    else
                    {
                        root = insert(root, id, salary);
                        cout << "Employee inserted successfully!\n";
                    }
                }
                break;

            case 2:
                cout << "Enter Employee ID to search: ";
                cin >> id;

                {
                    Node* result = search(root, id);

                    if(result != NULL)
                    {
                        cout << "\nEmployee Found!\n";
                        cout << "Employee ID: " << result->id << endl;
                        cout << "Salary: " << result->salary << endl;
                    }
                    else
                    {
                        cout << "Employee not found!\n";
                    }
                }
                break;

            case 3:
                findMinMaxSalary(root);
                break;

            case 4:
                cout << "Employee IDs in Ascending Order: ";
                inorder(root);
                cout << endl;
                break;

            case 5:
                cout << "Employee IDs in Descending Order: ";
                descending(root);
                cout << endl;
                break;

            case 6:
                cout << "Height of BST: " << height(root) << endl;

                cout << "Number of Leaf Nodes: "
                     << countLeafNodes(root) << endl;
                break;

            case 7:
                displayTraversals(root);
                break;

            case 8:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice! Try Again.\n";
        }

    } while(choice != 8);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Binary Search Tree (BST) is a non-linear data structure
used to store and manage data in sorted order.

Each node contains:
- Employee ID
- Employee Salary
- Left pointer
- Right pointer

In this program, Employee ID is used as the key for
insertion and searching.

2. BINARY SEARCH TREE PROPERTY

A BST follows three rules:

1. All values in the left subtree are smaller than
   the root node.

2. All values in the right subtree are greater than
   the root node.

3. Both left and right subtrees are also BSTs.

Duplicate Employee IDs are not allowed.

3. INSERTION

Insertion is the process of adding a new employee
record into the BST.

Steps:

1. If the tree is empty, create a new node.
2. Compare the Employee ID with the root ID.
3. If smaller, move to the left subtree.
4. If greater, move to the right subtree.
5. Insert the node at the empty position.

4. SEARCHING

Searching is used to find an employee using Employee ID.

Steps:

1. Compare the given ID with the root ID.
2. If both are equal, employee is found.
3. If smaller, search the left subtree.
4. If greater, search the right subtree.
5. Repeat until found or the tree becomes empty.

5. MINIMUM AND MAXIMUM SALARY

The program traverses the entire BST and compares
the salary of every employee.

Minimum Salary:
The employee having the lowest salary.

Maximum Salary:
The employee having the highest salary.

Note: Salary is not the BST sorting key, so the entire
tree must be checked.

6. ASCENDING AND DESCENDING ORDER

Ascending Order:
Inorder Traversal (Left, Root, Right).

It displays Employee IDs from smallest to largest.

Descending Order:
Reverse Inorder Traversal (Right, Root, Left).

It displays Employee IDs from largest to smallest.

7. TREE TRAVERSALS

A. INORDER TRAVERSAL

Order:
Left -> Root -> Right

Displays employee IDs in ascending order.

B. PREORDER TRAVERSAL

Order:
Root -> Left -> Right

This program implements preorder without recursion
using a Stack.

Steps:

1. Push the root into the stack.
2. Pop the top node and display it.
3. Push the right child into the stack.
4. Push the left child into the stack.
5. Repeat until the stack becomes empty.

C. POSTORDER TRAVERSAL

Order:
Left -> Right -> Root

It visits both subtrees before displaying the root.

8. HEIGHT OF BST

Height is the maximum number of nodes on a path
from the root to a leaf.

Formula:

Height = 1 + max(Left Height, Right Height)

Base Condition:

If root == NULL, height = 0.

9. LEAF NODES

A leaf node is a node that has no left child
and no right child.

Condition:

left == NULL && right == NULL

The program counts all leaf nodes using recursion.

10. TIME COMPLEXITY

Let n = Number of employees.

Insertion:
Average: O(log n)
Worst: O(n)

Searching:
Average: O(log n)
Worst: O(n)

Finding Minimum and Maximum Salary:
O(n)

Ascending Order:
O(n)

Descending Order:
O(n)

Preorder Traversal:
O(n)

Postorder Traversal:
O(n)

Height Calculation:
O(n)

Counting Leaf Nodes:
O(n)

11. SPACE COMPLEXITY

BST Storage:
O(n)

Preorder Stack:
O(h)

Recursive Traversals:
O(h)

Where h = Height of the BST.

12. APPLICATIONS

1. Employee record management.
2. Student information systems.
3. Database indexing.
4. Searching and sorting.
5. Salary management systems.
6. Inventory management.

13. ADVANTAGES

1. Efficient searching in a balanced BST.
2. Maintains employee IDs in sorted order.
3. Supports insertion of new employee records.
4. Provides different tree traversal methods.
5. Helps analyze tree height and leaf nodes.

14. CONCLUSION

The Employee Management System is successfully
implemented using a Binary Search Tree.

The program performs employee insertion, searching,
minimum and maximum salary calculation, ascending
and descending order display, height calculation,
leaf node counting and tree traversals.

Preorder traversal is implemented using a
non-recursive stack method.

============================================================
                    END OF PROGRAM
============================================================
*/
