
/*
============================================================
                    PROBLEM STATEMENT
============================================================

3. Problem Statement:

A group of servers in a network are connected by data
cables.

If a direct cable exists between Server A and Server B,
there is an edge between them.

The weight of the edge denotes data transfer speed
(Mbps) or latency (ms).

Write a C++ program to represent this network using
adjacency matrix and adjacency list.

The program should:

1. Display the connectivity between servers.
2. Determine if all servers are reachable from a given node.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
using namespace std;

class ServerNetwork
{
    int n;

    // Adjacency Matrix
    vector<vector<int>> matrix;

    // Adjacency List
    vector<vector<pair<int, int>>> adj;

public:

    ServerNetwork(int size)
    {
        n = size;

        matrix.resize(n, vector<int>(n, 0));
        adj.resize(n);
    }

    // Add connection between two servers
    void addConnection(int u, int v, int weight)
    {
        if(u < 0 || u >= n || v < 0 || v >= n || u == v)
        {
            cout << "Invalid server connection!\n";
            return;
        }

        // Undirected graph
        matrix[u][v] = weight;
        matrix[v][u] = weight;

        adj[u].push_back({v, weight});
        adj[v].push_back({u, weight});
    }

    // Display Adjacency Matrix
    void displayMatrix()
    {
        cout << "\n========== ADJACENCY MATRIX ==========\n";

        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
            {
                cout << matrix[i][j] << "\t";
            }

            cout << endl;
        }
    }

    // Display Adjacency List
    void displayList()
    {
        cout << "\n========== ADJACENCY LIST ==========\n";

        for(int i = 0; i < n; i++)
        {
            cout << "Server " << i << " -> ";

            for(auto edge : adj[i])
            {
                cout << "(" << edge.first
                     << ", Weight: " << edge.second << ") ";
            }

            cout << endl;
        }
    }

    // DFS Traversal
    void DFS(int node, vector<bool>& visited)
    {
        visited[node] = true;

        cout << node << " ";

        for(auto edge : adj[node])
        {
            int next = edge.first;

            if(!visited[next])
            {
                DFS(next, visited);
            }
        }
    }

    // Check whether all servers are reachable
    void checkConnectivity(int start)
    {
        if(start < 0 || start >= n)
        {
            cout << "Invalid starting server!\n";
            return;
        }

        vector<bool> visited(n, false);

        cout << "\n========== DFS TRAVERSAL ==========\n";

        cout << "Reachable servers: ";

        DFS(start, visited);

        bool allReachable = true;

        for(int i = 0; i < n; i++)
        {
            if(!visited[i])
            {
                allReachable = false;
                break;
            }
        }

        cout << "\n\nConnectivity Result:\n";

        if(allReachable)
        {
            cout << "All servers are reachable from Server "
                 << start << ".\n";
        }
        else
        {
            cout << "All servers are NOT reachable from Server "
                 << start << ".\n";

            cout << "Unreachable servers: ";

            for(int i = 0; i < n; i++)
            {
                if(!visited[i])
                {
                    cout << i << " ";
                }
            }

            cout << endl;
        }
    }
};

// Main Function
int main()
{
    int n, e;

    cout << "Enter number of servers: ";
    cin >> n;

    if(n <= 0)
    {
        cout << "Invalid number of servers!\n";
        return 0;
    }

    ServerNetwork network(n);

    cout << "Enter number of connections: ";
    cin >> e;

    if(e < 0)
    {
        cout << "Invalid number of connections!\n";
        return 0;
    }

    // Input connections
    for(int i = 0; i < e; i++)
    {
        int u, v, weight;

        cout << "\nEnter source server: ";
        cin >> u;

        cout << "Enter destination server: ";
        cin >> v;

        cout << "Enter connection weight: ";
        cin >> weight;

        network.addConnection(u, v, weight);
    }

    int choice;

    do
    {
        cout << "\n========== SERVER NETWORK MENU ==========\n";

        cout << "1. Display Adjacency Matrix\n";
        cout << "2. Display Adjacency List\n";
        cout << "3. Check Server Connectivity\n";
        cout << "4. Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                network.displayMatrix();
                break;

            case 2:
                network.displayList();
                break;

            case 3:
            {
                int start;

                cout << "Enter starting server: ";
                cin >> start;

                network.checkConnectivity(start);
                break;
            }

            case 4:
                cout << "Exiting program...\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }

    } while(choice != 4);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A server network is represented using a Graph data
structure.

In this graph:

- Servers represent Vertices (Nodes).
- Data cables represent Edges.
- Connection weight represents data transfer speed
  (Mbps) or latency (ms).

This program uses an undirected weighted graph.

2. ADJACENCY MATRIX

An Adjacency Matrix is a two-dimensional array used to
represent connections between vertices.

If a connection exists between two servers, the matrix
stores its weight.

If no connection exists, it stores 0.

Example:

    0   5   0
    5   0   8
    0   8   0

Here:
- Server 0 is connected to Server 1 with weight 5.
- Server 1 is connected to Server 2 with weight 8.
- Server 0 is not directly connected to Server 2.

3. ADJACENCY LIST

An Adjacency List stores a list of connected vertices
for every vertex.

Example:

Server 0 -> (1, 5)
Server 1 -> (0, 5), (2, 8)
Server 2 -> (1, 8)

It stores both the destination server and edge weight.

4. DEPTH FIRST SEARCH (DFS)

DFS is a graph traversal algorithm that explores as far
as possible along one path before backtracking.

It uses recursion or a stack.

Steps:

1. Start from the given server.
2. Mark the server as visited.
3. Display the server.
4. Visit an unvisited connected server.
5. Repeat until all reachable servers are visited.
6. Check whether all servers have been visited.

5. WORKING OF THE PROGRAM

Step 1:
Accept the number of servers.

Step 2:
Accept the number of data cable connections.

Step 3:
Accept source server, destination server and weight.

Step 4:
Store connections in the adjacency matrix and
adjacency list.

Step 5:
Display the adjacency matrix.

Step 6:
Display the adjacency list.

Step 7:
Accept the starting server.

Step 8:
Apply DFS traversal.

Step 9:
Check whether all servers are reachable.

Step 10:
Display the connectivity result.

6. ALGORITHM

1. Start.
2. Read the number of servers n.
3. Read the number of connections e.
4. Initialize adjacency matrix and adjacency list.
5. Insert all connections with their weights.
6. Display adjacency matrix and adjacency list.
7. Read the starting server.
8. Perform DFS traversal.
9. Mark each visited server.
10. Check whether all servers are visited.
11. Display the result.
12. Stop.

7. TIME COMPLEXITY

Let:
V = Number of servers
E = Number of connections

Adjacency Matrix Creation:
O(V^2)

Adding a Connection:
O(1)

Displaying Adjacency Matrix:
O(V^2)

Displaying Adjacency List:
O(V + E)

DFS Traversal using Adjacency List:
O(V + E)

8. SPACE COMPLEXITY

Adjacency Matrix:
O(V^2)

Adjacency List:
O(V + E)

DFS Visited Array:
O(V)

Overall Space Complexity:
O(V^2 + E)

9. APPLICATIONS

1. Computer network connectivity.
2. Data center network management.
3. Internet routing.
4. Server communication.
5. Network troubleshooting.
6. Distributed systems.

10. ADVANTAGES

1. Represents server connections efficiently.
2. Stores connection weights.
3. Helps identify unreachable servers.
4. Supports graph traversal.
5. Provides two different graph representations.

11. CONCLUSION

The server network is successfully represented using
an Adjacency Matrix and Adjacency List.

DFS is used to traverse the network and determine
whether all servers are reachable from a given server.

============================================================
                    END OF PROGRAM
============================================================
*/
