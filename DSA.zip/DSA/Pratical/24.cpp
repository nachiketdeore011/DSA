
/*
============================================================
                    PROBLEM STATEMENT
============================================================

24. Problem:

A relief organization needs to distribute food packages
to flood-affected areas using a limited-capacity truck.

Each package type has a weight and a benefit score
(importance).

Write a C++ program to select the combination of packages
that maximizes total benefit using the Fractional Knapsack
Greedy Method.

Display:

1. Each package selected and its fraction.
2. Total benefit obtained.
3. Total truck weight used.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <algorithm>
#include <iomanip>
#include <vector>
using namespace std;

// Structure to store package details
struct Package
{
    int id;
    double weight;
    double benefit;
    double ratio;
};

// Compare packages by benefit/weight ratio
bool compare(Package a, Package b)
{
    return a.ratio > b.ratio;
}

int main()
{
    int n;
    double capacity;

    cout << "Enter number of food packages: ";
    cin >> n;

    cout << "Enter truck capacity: ";
    cin >> capacity;

    if(n <= 0 || capacity < 0)
    {
        cout << "Invalid input!\n";
        return 0;
    }

    vector<Package> p(n);

    // Input package details
    cout << "\nEnter package weight and benefit:\n";

    for(int i = 0; i < n; i++)
    {
        p[i].id = i + 1;

        cout << "\nPackage " << i + 1 << ":\n";

        cout << "Weight: ";
        cin >> p[i].weight;

        cout << "Benefit: ";
        cin >> p[i].benefit;

        if(p[i].weight <= 0 || p[i].benefit < 0)
        {
            cout << "Invalid weight or benefit!\n";
            return 0;
        }

        // Calculate benefit-to-weight ratio
        p[i].ratio = p[i].benefit / p[i].weight;
    }

    // Sort packages by highest ratio
    sort(p.begin(), p.end(), compare);

    double totalWeight = 0;
    double totalBenefit = 0;
    double remaining = capacity;

    cout << fixed << setprecision(2);

    cout << "\n========== SELECTED PACKAGES ==========\n";

    // Greedy selection
    for(int i = 0; i < n; i++)
    {
        if(remaining <= 0)
            break;

        double selectedWeight;
        double selectedBenefit;
        double fraction;

        if(p[i].weight <= remaining)
        {
            // Select complete package
            selectedWeight = p[i].weight;
            selectedBenefit = p[i].benefit;
            fraction = 1.0;
        }
        else
        {
            // Select fractional package
            selectedWeight = remaining;

            fraction = selectedWeight / p[i].weight;

            selectedBenefit = p[i].benefit * fraction;
        }

        totalWeight += selectedWeight;
        totalBenefit += selectedBenefit;

        remaining -= selectedWeight;

        cout << "\nPackage ID: " << p[i].id;

        cout << "\nWeight Loaded: "
             << selectedWeight;

        cout << "\nBenefit Obtained: "
             << selectedBenefit;

        cout << "\nFraction Selected: "
             << fraction * 100 << "%\n";
    }

    // Display final result
    cout << "\n========== FINAL RESULT ==========\n";

    cout << "Total Truck Weight Used: "
         << totalWeight << endl;

    cout << "Total Benefit Obtained: "
         << totalBenefit << endl;

    cout << "Remaining Truck Capacity: "
         << remaining << endl;

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

Fractional Knapsack is an optimization problem solved
using the Greedy Algorithm.

In this problem, a truck has limited weight capacity
and different food packages have different weights
and benefit scores.

The objective is to maximize the total benefit without
exceeding the truck's capacity.

Fractional packages are allowed.

2. GREEDY ALGORITHM

A Greedy Algorithm selects the best possible option
at each step.

In this problem, the package having the highest
benefit-to-weight ratio is selected first.

3. BENEFIT-TO-WEIGHT RATIO

Formula:

Ratio = Benefit / Weight

The package with the highest ratio is selected first.

Example:

Package 1:
Weight = 10
Benefit = 60
Ratio = 60 / 10 = 6

Package 2:
Weight = 20
Benefit = 100
Ratio = 100 / 20 = 5

Package 3:
Weight = 30
Benefit = 120
Ratio = 120 / 30 = 4

Selection Order:

Package 1 -> Package 2 -> Package 3

4. FRACTIONAL SELECTION

If a complete package cannot fit in the remaining
truck capacity, a fraction of that package is selected.

Formula:

Fraction = Remaining Capacity / Package Weight

Benefit Obtained:

Selected Benefit = Package Benefit * Fraction

5. WORKING OF THE PROGRAM

Step 1:
Accept the number of packages.

Step 2:
Accept the maximum truck capacity.

Step 3:
Enter weight and benefit of each package.

Step 4:
Calculate benefit-to-weight ratio.

Step 5:
Sort packages in descending order of ratio.

Step 6:
Select the package with the highest ratio.

Step 7:
If the complete package fits, select it.

Step 8:
Otherwise, select the required fraction.

Step 9:
Calculate total weight and total benefit.

Step 10:
Display selected packages and final result.

6. ALGORITHM

1. Start.
2. Read number of packages n.
3. Read truck capacity W.
4. Read weight and benefit of each package.
5. Calculate benefit/weight ratio.
6. Sort packages in descending order of ratio.
7. Initialize total weight and benefit to zero.
8. Select packages according to their ratio.
9. If the complete package fits, select it.
10. Otherwise, select a fractional package.
11. Update total weight and benefit.
12. Display the selected packages.
13. Stop.

7. TIME COMPLEXITY

Let n = Number of packages.

Calculating Ratios:
O(n)

Sorting Packages:
O(n log n)

Selecting Packages:
O(n)

Overall Time Complexity:

O(n log n)

8. SPACE COMPLEXITY

Storing Packages:
O(n)

Auxiliary Space:
O(log n) for typical sorting implementation.

Overall Space Complexity:
O(n)

9. APPLICATIONS

1. Emergency food distribution.
2. Flood relief operations.
3. Disaster management.
4. Resource allocation.
5. Transportation management.
6. Supply chain optimization.

10. ADVANTAGES

1. Maximizes total benefit.
2. Efficient package selection.
3. Allows fractional packages.
4. Simple and easy to implement.
5. Uses an efficient sorting technique.

11. CONCLUSION

The Emergency Food Package Distribution Problem is
successfully solved using the Fractional Knapsack
Greedy Algorithm.

The program calculates benefit-to-weight ratios,
sorts packages in descending order and selects
complete or fractional packages to maximize total
benefit without exceeding the truck capacity.

============================================================
                    END OF PROGRAM
============================================================
*/
