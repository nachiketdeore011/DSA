
/*
============================================================
                    PROBLEM STATEMENT
============================================================

13. Problem:

Construct an Expression Tree from a prefix arithmetic
expression (e.g., +*AB*C/D-EF).

Perform the following operations:

1. Display Inorder, Preorder, and Postorder traversals.

2. Simplify the expression tree by reducing constant
   sub-expressions (e.g., *23 -> 6).

3. Find total number of leaf nodes and internal nodes.

4. Display the mirror image of the expression tree.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <stack>
#include <vector>
#include <string>
#include <sstream>
using namespace std;

// Node Structure
struct Node
{
    string data;
    Node *left, *right;

    Node(string value)
    {
        data = value;
        left = right = NULL;
    }
};

// Check Arithmetic Operator
bool isOperator(string s)
{
    return s == "+" || s == "-" ||
           s == "*" || s == "/";
}

// Check Whether Node Contains a Number
bool isNumber(string s)
{
    if(s.empty())
        return false;

    for(char c : s)
    {
        if(c < '0' || c > '9')
            return false;
    }

    return true;
}

// Tokenize Prefix Expression
vector<string> tokenize(string expression)
{
    vector<string> tokens;

    stringstream ss(expression);
    string token;

    if(expression.find(' ') != string::npos)
    {
        while(ss >> token)
            tokens.push_back(token);
    }
    else
    {
        for(char c : expression)
        {
            tokens.push_back(string(1, c));
        }
    }

    return tokens;
}

// Construct Expression Tree
Node* createTree(vector<string> tokens)
{
    stack<Node*> s;

    // Read Prefix Expression from Right to Left
    for(int i = tokens.size() - 1; i >= 0; i--)
    {
        string value = tokens[i];

        Node* newNode = new Node(value);

        if(isOperator(value))
        {
            if(s.size() < 2)
            {
                delete newNode;

                while(!s.empty())
                {
                    delete s.top();
                    s.pop();
                }

                return NULL;
            }

            newNode->left = s.top();
            s.pop();

            newNode->right = s.top();
            s.pop();
        }

        s.push(newNode);
    }

    if(s.size() != 1)
    {
        while(!s.empty())
        {
            delete s.top();
            s.pop();
        }

        return NULL;
    }

    return s.top();
}

// Inorder Traversal
void inorder(Node* root)
{
    if(root == NULL)
        return;

    if(isOperator(root->data))
        cout << "(";

    inorder(root->left);

    cout << root->data;

    inorder(root->right);

    if(isOperator(root->data))
        cout << ")";
}

// Preorder Traversal
void preorder(Node* root)
{
    if(root == NULL)
        return;

    cout << root->data << " ";

    preorder(root->left);
    preorder(root->right);
}

// Postorder Traversal
void postorder(Node* root)
{
    if(root == NULL)
        return;

    postorder(root->left);
    postorder(root->right);

    cout << root->data << " ";
}

// Count Leaf Nodes
int countLeaf(Node* root)
{
    if(root == NULL)
        return 0;

    if(root->left == NULL && root->right == NULL)
        return 1;

    return countLeaf(root->left) +
           countLeaf(root->right);
}

// Count Internal Nodes
int countInternal(Node* root)
{
    if(root == NULL)
        return 0;

    if(root->left == NULL && root->right == NULL)
        return 0;

    return 1 + countInternal(root->left) +
               countInternal(root->right);
}

// Delete Tree
void deleteTree(Node* root)
{
    if(root == NULL)
        return;

    deleteTree(root->left);
    deleteTree(root->right);

    delete root;
}

// Clone Expression Tree
Node* cloneTree(Node* root)
{
    if(root == NULL)
        return NULL;

    Node* newNode = new Node(root->data);

    newNode->left = cloneTree(root->left);
    newNode->right = cloneTree(root->right);

    return newNode;
}

// Simplify Constant Sub-Expressions
Node* simplify(Node* root)
{
    if(root == NULL)
        return NULL;

    root->left = simplify(root->left);
    root->right = simplify(root->right);

    // Check whether both children are numbers
    if(isOperator(root->data) &&
       root->left != NULL &&
       root->right != NULL &&
       isNumber(root->left->data) &&
       isNumber(root->right->data))
    {
        long long a = stoll(root->left->data);
        long long b = stoll(root->right->data);

        long long result = 0;

        if(root->data == "+")
            result = a + b;

        else if(root->data == "-")
            result = a - b;

        else if(root->data == "*")
            result = a * b;

        else if(root->data == "/")
        {
            if(b == 0)
            {
                cout << "Cannot simplify division by zero!\n";
                return root;
            }

            result = a / b;
        }

        // Replace operator node with result
        Node* newNode = new Node(to_string(result));

        deleteTree(root);

        return newNode;
    }

    return root;
}

// Swap Left and Right Subtrees
void mirror(Node* root)
{
    if(root == NULL)
        return;

    swap(root->left, root->right);

    mirror(root->left);
    mirror(root->right);
}

// Display Expression Tree
void displayTree(Node* root, int space = 0)
{
    if(root == NULL)
        return;

    space += 5;

    displayTree(root->right, space);

    cout << endl;

    for(int i = 5; i < space; i++)
        cout << " ";

    cout << root->data << endl;

    displayTree(root->left, space);
}

// Main Function
int main()
{
    Node* root = NULL;

    Node* mirrorRoot = NULL;

    string expression;

    int choice;

    cout << "Enter Prefix Expression: ";
    getline(cin, expression);

    // Convert expression into tokens
    vector<string> tokens = tokenize(expression);

    // Construct Expression Tree
    root = createTree(tokens);

    if(root == NULL)
    {
        cout << "Invalid Prefix Expression!\n";
        return 0;
    }

    do
    {
        cout << "\n========== EXPRESSION TREE MENU ==========\n";

        cout << "1. Display Expression Tree\n";
        cout << "2. Inorder Traversal\n";
        cout << "3. Preorder Traversal\n";
        cout << "4. Postorder Traversal\n";
        cout << "5. Simplify Expression Tree\n";
        cout << "6. Count Leaf and Internal Nodes\n";
        cout << "7. Display Mirror Image\n";
        cout << "8. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "\nExpression Tree:\n";
                displayTree(root);
                break;

            case 2:
                cout << "\nInorder Traversal: ";
                inorder(root);
                cout << endl;
                break;

            case 3:
                cout << "\nPreorder Traversal: ";
                preorder(root);
                cout << endl;
                break;

            case 4:
                cout << "\nPostorder Traversal: ";
                postorder(root);
                cout << endl;
                break;

            case 5:
                root = simplify(root);

                cout << "\nSimplified Expression: ";
                inorder(root);
                cout << endl;
                break;

            case 6:
                cout << "\nTotal Leaf Nodes: "
                     << countLeaf(root) << endl;

                cout << "Total Internal Nodes: "
                     << countInternal(root) << endl;
                break;

            case 7:
                mirrorRoot = cloneTree(root);

                mirror(mirrorRoot);

                cout << "\nMirror Image of Expression Tree:\n";

                displayTree(mirrorRoot);

                cout << "\nMirror Inorder: ";
                inorder(mirrorRoot);

                cout << "\nMirror Preorder: ";
                preorder(mirrorRoot);

                cout << "\nMirror Postorder: ";
                postorder(mirrorRoot);

                cout << endl;

                deleteTree(mirrorRoot);
                mirrorRoot = NULL;

                break;

            case 8:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while(choice != 8);

    deleteTree(root);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

An Expression Tree is a binary tree used to represent
arithmetic expressions.

In this tree:

- Leaf nodes represent operands.
- Internal nodes represent operators.

Example:

+ * A B C

Expression:

(A * B) + C

2. PREFIX EXPRESSION

Prefix notation is a notation in which the operator
comes before its operands.

Example:

+ * A B C

Here:
+ is the root operator.
* is the left child.
A and B are operands.
C is the right child.

3. CONSTRUCTION OF EXPRESSION TREE

Steps:

1. Read the prefix expression from right to left.
2. If an operand is found, create a new node and push it.
3. If an operator is found, pop two nodes.
4. Make the first popped node the right child.
5. Make the second popped node the left child.
6. Push the new operator node.
7. Repeat until all tokens are processed.
8. The remaining node is the root.

4. TREE TRAVERSALS

A. INORDER

Order:

Left -> Root -> Right

Displays the expression in infix form.

B. PREORDER

Order:

Root -> Left -> Right

Displays the expression in prefix form.

C. POSTORDER

Order:

Left -> Right -> Root

Displays the expression in postfix form.

5. EXPRESSION SIMPLIFICATION

Simplification reduces constant sub-expressions.

Example:

* 2 3 = 6

+ 4 5 = 9

- 8 3 = 5

/ 8 2 = 4

The program evaluates an operator when both its
children contain numeric constants.

6. LEAF NODES

A leaf node is a node that does not have any children.

Condition:

Left == NULL AND Right == NULL

7. INTERNAL NODES

An internal node is a node that has at least
one child.

In an expression tree, operators are internal nodes.

8. MIRROR IMAGE

A mirror image is obtained by swapping the left
and right subtrees of every node.

Steps:

1. Start from the root.
2. Swap the left and right children.
3. Repeat for the left subtree.
4. Repeat for the right subtree.

9. TIME COMPLEXITY

Let n = Number of nodes.

Tree Construction:
O(n)

Inorder Traversal:
O(n)

Preorder Traversal:
O(n)

Postorder Traversal:
O(n)

Simplification:
O(n)

Counting Leaf Nodes:
O(n)

Counting Internal Nodes:
O(n)

Mirror Image:
O(n)

10. SPACE COMPLEXITY

Expression Tree:
O(n)

Recursion Stack:
O(h)

Construction Stack:
O(n)

Where h = Height of the tree.

11. APPLICATIONS

1. Compiler design.
2. Calculator applications.
3. Expression evaluation.
4. Mathematical expression processing.
5. Syntax tree construction.
6. Arithmetic expression conversion.

12. ADVANTAGES

1. Represents arithmetic expressions clearly.
2. Supports different traversal methods.
3. Simplifies constant expressions.
4. Counts leaf and internal nodes.
5. Generates mirror images of trees.

13. CONCLUSION

The Arithmetic Expression Tree is successfully
implemented using a Binary Tree.

The program constructs an expression tree from
prefix notation and performs inorder, preorder
and postorder traversals.

It also simplifies constant sub-expressions,
counts leaf and internal nodes and displays
the mirror image of the expression tree.

============================================================
                    END OF PROGRAM
============================================================
*/
