
/*
============================================================
                    PROBLEM STATEMENT
============================================================

32. Problem:

A stock analyst records the daily stock prices of a company.
They want to quickly find the highest and lowest prices
during a given period.

Write a C++ program using Heap data structures to perform
the following:

1. Insert daily stock prices.

2. Display the maximum and minimum stock price.

3. Delete the topmost (maximum) price.

4. Display all prices in ascending or descending order.

Perform algorithmic analysis for insertion and deletion
operations.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
using namespace std;

// MAX HEAP
class MaxHeap
{
    vector<int> heap;

public:

    // Insert price into Max Heap
    void insert(int value)
    {
        heap.push_back(value);

        int i = heap.size() - 1;

        while(i > 0 && heap[(i - 1) / 2] < heap[i])
        {
            swap(heap[i], heap[(i - 1) / 2]);

            i = (i - 1) / 2;
        }
    }

    // Get maximum price
    int getMax()
    {
        return heap[0];
    }

    // Delete maximum price
    int deleteMax()
    {
        int maximum = heap[0];

        heap[0] = heap.back();
        heap.pop_back();

        int i = 0;
        int n = heap.size();

        while(true)
        {
            int largest = i;

            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if(left < n && heap[left] > heap[largest])
                largest = left;

            if(right < n && heap[right] > heap[largest])
                largest = right;

            if(largest == i)
                break;

            swap(heap[i], heap[largest]);

            i = largest;
        }

        return maximum;
    }

    // Check whether heap is empty
    bool isEmpty()
    {
        return heap.empty();
    }

    // Display prices in descending order
    void displayDescending()
    {
        if(isEmpty())
        {
            cout << "No stock prices available!\n";
            return;
        }

        MaxHeap temp = *this;

        cout << "Prices in Descending Order: ";

        while(!temp.isEmpty())
        {
            cout << temp.deleteMax() << " ";
        }

        cout << endl;
    }
};


// MIN HEAP
class MinHeap
{
    vector<int> heap;

    // Heapify Down
    void heapifyDown(int i)
    {
        int n = heap.size();

        while(true)
        {
            int smallest = i;

            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if(left < n && heap[left] < heap[smallest])
                smallest = left;

            if(right < n && heap[right] < heap[smallest])
                smallest = right;

            if(smallest == i)
                break;

            swap(heap[i], heap[smallest]);

            i = smallest;
        }
    }

public:

    // Insert price into Min Heap
    void insert(int value)
    {
        heap.push_back(value);

        int i = heap.size() - 1;

        while(i > 0 && heap[(i - 1) / 2] > heap[i])
        {
            swap(heap[i], heap[(i - 1) / 2]);

            i = (i - 1) / 2;
        }
    }

    // Get minimum price
    int getMin()
    {
        return heap[0];
    }

    // Delete one occurrence of a given price
    void deleteValue(int value)
    {
        int n = heap.size();

        int i;

        for(i = 0; i < n; i++)
        {
            if(heap[i] == value)
                break;
        }

        if(i == n)
            return;

        heap[i] = heap.back();
        heap.pop_back();

        if(i < heap.size())
        {
            // Check whether Heapify Up is needed
            if(i > 0 && heap[i] < heap[(i - 1) / 2])
            {
                while(i > 0 && heap[i] < heap[(i - 1) / 2])
                {
                    swap(heap[i], heap[(i - 1) / 2]);

                    i = (i - 1) / 2;
                }
            }
            else
            {
                heapifyDown(i);
            }
        }
    }

    // Check whether heap is empty
    bool isEmpty()
    {
        return heap.empty();
    }

    // Display prices in ascending order
    void displayAscending()
    {
        if(isEmpty())
        {
            cout << "No stock prices available!\n";
            return;
        }

        MinHeap temp = *this;

        cout << "Prices in Ascending Order: ";

        while(!temp.isEmpty())
        {
            int minimum = temp.getMin();

            cout << minimum << " ";

            temp.deleteValue(minimum);
        }

        cout << endl;
    }
};


// Main Function
int main()
{
    MaxHeap maxHeap;
    MinHeap minHeap;

    int choice, price;

    do
    {
        cout << "\n========== STOCK PRICE MANAGEMENT ==========\n";

        cout << "1. Insert Daily Stock Price\n";
        cout << "2. Display Maximum and Minimum Price\n";
        cout << "3. Delete Maximum Stock Price\n";
        cout << "4. Display Prices in Ascending Order\n";
        cout << "5. Display Prices in Descending Order\n";
        cout << "6. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter Stock Price: ";
                cin >> price;

                if(price < 0)
                {
                    cout << "Invalid stock price!\n";
                    break;
                }

                maxHeap.insert(price);
                minHeap.insert(price);

                cout << "Stock price inserted successfully!\n";
                break;

            case 2:
                if(maxHeap.isEmpty())
                {
                    cout << "No stock prices available!\n";
                }
                else
                {
                    cout << "\nMaximum Stock Price: "
                         << maxHeap.getMax() << endl;

                    cout << "Minimum Stock Price: "
                         << minHeap.getMin() << endl;
                }
                break;

            case 3:
                if(maxHeap.isEmpty())
                {
                    cout << "No stock prices to delete!\n";
                }
                else
                {
                    price = maxHeap.deleteMax();

                    minHeap.deleteValue(price);

                    cout << "Deleted Maximum Stock Price: "
                         << price << endl;
                }
                break;

            case 4:
                minHeap.displayAscending();
                break;

            case 5:
                maxHeap.displayDescending();
                break;

            case 6:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice! Try Again.\n";
        }

    } while(choice != 6);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Heap is a special type of Complete Binary Tree that
satisfies the Heap Property.

It is commonly used to find maximum and minimum elements
efficiently.

In this program, two types of heaps are used:

1. Max Heap
2. Min Heap

2. MAX HEAP

A Max Heap is a Complete Binary Tree in which every parent
node is greater than or equal to its child nodes.

The maximum element is always present at the root node.

Example:

             90
           /    \
         70      60
        /  \
       40   50

Maximum Price = 90

3. MIN HEAP

A Min Heap is a Complete Binary Tree in which every parent
node is smaller than or equal to its child nodes.

The minimum element is always present at the root node.

Example:

             10
           /    \
         20      30
        /  \
       40   50

Minimum Price = 10

4. HEAP REPRESENTATION

A Heap is generally represented using an array.

For a node at index i:

Parent Index = (i - 1) / 2

Left Child = 2 * i + 1

Right Child = 2 * i + 2

5. INSERTION OPERATION

Insertion adds a new stock price into the Heap.

Steps:

1. Insert the new element at the end.
2. Compare it with its parent.
3. If the Heap property is violated, swap them.
4. Repeat until the correct position is found.

This process is called Heapify Up.

Time Complexity = O(log n)

6. MAXIMUM AND MINIMUM PRICE

Maximum Price:

The root element of Max Heap gives the maximum stock price.

Minimum Price:

The root element of Min Heap gives the minimum stock price.

Time Complexity = O(1)

7. DELETION OPERATION

Deletion removes the root element from the Heap.

Steps:

1. Store the root element.
2. Replace the root with the last element.
3. Remove the last element.
4. Compare the root with its children.
5. Swap with the appropriate child.
6. Repeat until Heap property is restored.

This process is called Heapify Down.

Time Complexity for Max Heap Deletion = O(log n)

In this program, the corresponding value is also removed
from the Min Heap. Finding that value takes O(n), so the
complete synchronized deletion takes O(n) time.

8. ASCENDING ORDER

To display stock prices in ascending order:

1. Create a temporary copy of Min Heap.
2. Find the minimum element.
3. Display the minimum element.
4. Delete that element from the temporary Heap.
5. Repeat until the Heap becomes empty.

Time Complexity = O(n log n)

9. DESCENDING ORDER

To display stock prices in descending order:

1. Create a temporary copy of Max Heap.
2. Find the maximum element.
3. Display the maximum element.
4. Delete that element from the temporary Heap.
5. Repeat until the Heap becomes empty.

Time Complexity = O(n log n)

10. ALGORITHM

1. Start.
2. Create Max Heap and Min Heap.
3. Display the menu.
4. Accept the user's choice.

5. If choice is 1:
   Insert the price into both heaps.

6. If choice is 2:
   Display maximum and minimum prices.

7. If choice is 3:
   Delete the maximum price from Max Heap.
   Remove the same price from Min Heap.

8. If choice is 4:
   Display prices in ascending order.

9. If choice is 5:
   Display prices in descending order.

10. Repeat until the user selects Exit.
11. Stop.

11. TIME COMPLEXITY

Let n = Number of stock prices.

Insertion:
O(log n) in each Heap.

Finding Maximum:
O(1)

Finding Minimum:
O(1)

Max Heap Deletion:
O(log n)

Min Heap synchronization during deletion:
O(n) including searching for the value.

Ascending Order Display:
O(n log n)

Descending Order Display:
O(n log n)

12. SPACE COMPLEXITY

Max Heap:
O(n)

Min Heap:
O(n)

Temporary Heap for Display:
O(n)

Overall Space Complexity:
O(n)

13. APPLICATIONS

1. Stock market price analysis.
2. Priority scheduling.
3. Finding highest and lowest values.
4. Hospital emergency management.
5. CPU task scheduling.
6. Priority queue implementation.

14. ADVANTAGES

1. Quickly finds maximum and minimum prices.
2. Efficient insertion operations.
3. Efficient root deletion.
4. Maintains data using Heap properties.
5. Supports ascending and descending display.

15. CONCLUSION

The Stock Price Management System is successfully
implemented using Max Heap and Min Heap.

The program performs insertion, maximum and minimum
price searching, deletion of maximum price and
displaying stock prices in ascending and descending
order.

Heap data structures provide efficient insertion
and retrieval of extreme values.

============================================================
                    END OF PROGRAM
============================================================
*/
