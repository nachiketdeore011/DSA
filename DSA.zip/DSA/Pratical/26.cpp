
/*
============================================================
                    PROBLEM STATEMENT
============================================================

26. Problem:

A company has n projects to choose from.

Each project requires a certain investment cost and yields
an expected profit.

The company can invest up to a maximum budget B.

Write a C++ program using Dynamic Programming or Branch
and Bound to select the set of projects that maximizes
total profit without exceeding the budget.

Display the selected projects, total cost, and total profit.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    int n, B;

    cout << "Enter number of projects: ";
    cin >> n;

    cout << "Enter maximum budget: ";
    cin >> B;

    int cost[n], profit[n];

    cout << "\nEnter investment cost and profit of each project:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "\nProject " << i + 1 << ":\n";

        cout << "Investment Cost: ";
        cin >> cost[i];

        cout << "Expected Profit: ";
        cin >> profit[i];
    }

    // Create DP table
    vector<vector<int>> dp(n + 1,
                           vector<int>(B + 1, 0));

    // Dynamic Programming
    for(int i = 1; i <= n; i++)
    {
        for(int b = 0; b <= B; b++)
        {
            // Check if project can be selected
            if(cost[i - 1] <= b)
            {
                dp[i][b] = max(
                    dp[i - 1][b],
                    profit[i - 1] +
                    dp[i - 1][b - cost[i - 1]]
                );
            }
            else
            {
                dp[i][b] = dp[i - 1][b];
            }
        }
    }

    // Maximum profit
    int maxProfit = dp[n][B];

    // Find selected projects
    vector<int> selected;

    int b = B;

    for(int i = n; i > 0; i--)
    {
        if(dp[i][b] != dp[i - 1][b])
        {
            selected.push_back(i);

            b = b - cost[i - 1];
        }
    }

    // Display result
    int totalCost = 0;

    cout << "\n========== PROJECT SELECTION RESULT ==========\n";

    cout << "\nSelected Projects:\n";

    if(selected.empty())
    {
        cout << "No projects selected.\n";
    }

    for(int i = selected.size() - 1; i >= 0; i--)
    {
        int p = selected[i];

        cout << "Project " << p
             << " | Cost: " << cost[p - 1]
             << " | Profit: " << profit[p - 1]
             << endl;

        totalCost += cost[p - 1];
    }

    cout << "\nTotal Investment Cost: " << totalCost;

    cout << "\nMaximum Total Profit: " << maxProfit;

    cout << "\nRemaining Budget: " << B - totalCost;

    cout << "\n";

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

The Project Selection Problem is an optimization problem
in which a company has multiple projects with different
investment costs and expected profits.

The objective is to select projects that maximize total
profit without exceeding the available budget.

2. WHAT IS 0/1 KNAPSACK?

This problem is based on the 0/1 Knapsack algorithm.

Each project has two choices:

0 = Do not select the project.
1 = Select the complete project.

A project cannot be selected more than once.

3. DYNAMIC PROGRAMMING

Dynamic Programming is an algorithmic technique that
divides a complex problem into smaller subproblems.

It stores previously calculated results to avoid
recalculating the same subproblems.

4. FORMULA

Let:

n = Number of projects
B = Maximum budget
cost[i] = Investment cost of project i
profit[i] = Expected profit of project i

dp[i][b] = Maximum profit using the first i projects
           with budget b.

If cost[i-1] <= b:

dp[i][b] = max(
    dp[i-1][b],

    profit[i-1] + dp[i-1][b-cost[i-1]]
)

Otherwise:

dp[i][b] = dp[i-1][b]

5. WORKING OF THE PROGRAM

Step 1:
Accept the number of projects and maximum budget.

Step 2:
Accept investment cost and expected profit of each project.

Step 3:
Create a DP table of size (n+1) x (B+1).

Step 4:
Check whether each project should be selected or rejected.

Step 5:
Calculate maximum profit using the DP formula.

Step 6:
Trace back through the DP table to identify selected
projects.

Step 7:
Calculate total investment cost.

Step 8:
Display selected projects, total cost and maximum profit.

6. ALGORITHM

1. Start.
2. Read the number of projects n.
3. Read maximum budget B.
4. Read cost and profit of all projects.
5. Initialize the DP table with zero.
6. Apply the 0/1 Knapsack recurrence relation.
7. Calculate maximum profit.
8. Trace back to find selected projects.
9. Calculate total investment cost.
10. Display selected projects, total cost and profit.
11. Stop.

7. TIME COMPLEXITY

The DP table contains (n+1) x (B+1) elements.

Time Complexity = O(n x B)

8. SPACE COMPLEXITY

The DP table requires (n+1) x (B+1) memory.

Space Complexity = O(n x B)

9. APPLICATIONS

1. Business investment planning.
2. Project selection.
3. Budget allocation.
4. Financial planning.
5. Resource optimization.
6. Portfolio management.

10. ADVANTAGES

1. Finds the optimal combination of projects.
2. Maximizes total expected profit.
3. Ensures the budget limit is not exceeded.
4. Avoids repeated calculations.
5. Provides an efficient solution for moderate
   integer budget values.

11. CONCLUSION

The Project Selection Problem is successfully solved
using Dynamic Programming.

The program selects the combination of projects that
provides maximum total profit without exceeding the
company's maximum investment budget.

============================================================
                    END OF PROGRAM
============================================================
*/
