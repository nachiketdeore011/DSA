
/*
============================================================
                    PROBLEM STATEMENT
============================================================

1. Problem Statement:

There are railway routes between major cities. If there
is a train route between city A and city B, then there
is an edge between the cities.

The cost of the edge can represent the distance (in km)
or ticket fare between the cities.

Write a menu-driven C++ program to represent this as a
graph using adjacency matrix and adjacency list.

Each node represents a railway station.

The program should:

1. Check whether two cities are directly connected
   by a train route.

2. Display all possible connections from a given city.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

class RailwayNetwork
{
    int n;

    vector<string> cities;

    // Adjacency Matrix
    vector<vector<int>> matrix;

    // Adjacency List
    vector<vector<pair<int, int>>> adj;

public:

    RailwayNetwork(int size)
    {
        n = size;

        cities.resize(n);
        matrix.resize(n, vector<int>(n, -1));
        adj.resize(n);

        for(int i = 0; i < n; i++)
        {
            cout << "Enter city " << i + 1 << ": ";
            cin >> cities[i];
        }
    }

    // Find city index
    int getCityIndex(string name)
    {
        for(int i = 0; i < n; i++)
        {
            if(cities[i] == name)
                return i;
        }

        return -1;
    }

    // Add railway route
    void addRoute(string city1, string city2, int cost)
    {
        int u = getCityIndex(city1);
        int v = getCityIndex(city2);

        if(u == -1 || v == -1 || u == v || cost < 0)
        {
            cout << "Invalid city or route!\n";
            return;
        }

        // Update existing route if present
        for(auto &edge : adj[u])
        {
            if(edge.first == v)
            {
                edge.second = cost;

                for(auto &e : adj[v])
                {
                    if(e.first == u)
                        e.second = cost;
                }

                matrix[u][v] = cost;
                matrix[v][u] = cost;

                cout << "Route updated successfully!\n";
                return;
            }
        }

        // Undirected graph
        matrix[u][v] = cost;
        matrix[v][u] = cost;

        adj[u].push_back({v, cost});
        adj[v].push_back({u, cost});

        cout << "Railway route added successfully!\n";
    }

    // Display adjacency matrix
    void displayMatrix()
    {
        cout << "\n========== ADJACENCY MATRIX ==========\n";

        cout << "\t";

        for(int i = 0; i < n; i++)
            cout << cities[i] << "\t";

        cout << endl;

        for(int i = 0; i < n; i++)
        {
            cout << cities[i] << "\t";

            for(int j = 0; j < n; j++)
            {
                if(matrix[i][j] == -1)
                    cout << "-\t";
                else
                    cout << matrix[i][j] << "\t";
            }

            cout << endl;
        }
    }

    // Display adjacency list
    void displayList()
    {
        cout << "\n========== ADJACENCY LIST ==========\n";

        for(int i = 0; i < n; i++)
        {
            cout << cities[i] << " -> ";

            for(auto edge : adj[i])
            {
                cout << cities[edge.first]
                     << " (Cost: " << edge.second << ") ";
            }

            cout << endl;
        }
    }

    // Check direct railway connection
    void checkConnection(string city1, string city2)
    {
        int u = getCityIndex(city1);
        int v = getCityIndex(city2);

        if(u == -1 || v == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        if(matrix[u][v] != -1)
        {
            cout << "\nDirect railway route exists!\n";

            cout << "From: " << cities[u] << endl;
            cout << "To: " << cities[v] << endl;
            cout << "Cost: " << matrix[u][v] << endl;
        }
        else
        {
            cout << "\nNo direct railway route exists between "
                 << cities[u] << " and " << cities[v] << ".\n";
        }
    }

    // Display all connections from a given city
    void displayConnections(string city)
    {
        int u = getCityIndex(city);

        if(u == -1)
        {
            cout << "Invalid city name!\n";
            return;
        }

        cout << "\nDirect connections from "
             << cities[u] << ":\n";

        if(adj[u].empty())
        {
            cout << "No railway connections available.\n";
            return;
        }

        for(auto edge : adj[u])
        {
            cout << cities[u] << " -> "
                 << cities[edge.first]
                 << " | Cost: " << edge.second << endl;
        }
    }
};

// Main Function
int main()
{
    int n, routes;

    cout << "Enter number of cities: ";
    cin >> n;

    if(n <= 0)
    {
        cout << "Invalid number of cities!\n";
        return 0;
    }

    RailwayNetwork railway(n);

    cout << "\nEnter number of railway routes: ";
    cin >> routes;

    if(routes < 0)
    {
        cout << "Invalid number of routes!\n";
        return 0;
    }

    // Input railway routes
    for(int i = 0; i < routes; i++)
    {
        string city1, city2;
        int cost;

        cout << "\nEnter first city: ";
        cin >> city1;

        cout << "Enter second city: ";
        cin >> city2;

        cout << "Enter distance or ticket fare: ";
        cin >> cost;

        railway.addRoute(city1, city2, cost);
    }

    int choice;

    do
    {
        cout << "\n========== RAILWAY NETWORK MENU ==========\n";

        cout << "1. Display Adjacency Matrix\n";
        cout << "2. Display Adjacency List\n";
        cout << "3. Check Direct Railway Connection\n";
        cout << "4. Display All Connections from a City\n";
        cout << "5. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        string city1, city2;

        switch(choice)
        {
            case 1:
                railway.displayMatrix();
                break;

            case 2:
                railway.displayList();
                break;

            case 3:
                cout << "Enter first city: ";
                cin >> city1;

                cout << "Enter second city: ";
                cin >> city2;

                railway.checkConnection(city1, city2);
                break;

            case 4:
                cout << "Enter city name: ";
                cin >> city1;

                railway.displayConnections(city1);
                break;

            case 5:
                cout << "Exiting program...\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }

    } while(choice != 5);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Railway Network is represented using a Graph data
structure.

In this graph:

- Cities represent Vertices (Nodes).
- Railway routes represent Edges.
- Distance or ticket fare represents Edge Weight.

This program uses an Undirected Weighted Graph.

2. ADJACENCY MATRIX

An Adjacency Matrix is a two-dimensional array used to
represent connections between vertices.

If a railway route exists between two cities, the matrix
stores its cost.

If no route exists, it stores -1.

Example:

       A    B    C
A      -    50   30
B      50   -    -
C      30   -    -

Here:
- A is connected to B with cost 50.
- A is connected to C with cost 30.
- B and C have no direct connection.

3. ADJACENCY LIST

An Adjacency List stores all adjacent vertices of each
vertex along with their corresponding edge weights.

Example:

A -> B (50), C (30)
B -> A (50)
C -> A (30)

It is useful for representing graphs with fewer edges.

4. UNDIRECTED WEIGHTED GRAPH

An undirected graph is a graph in which edges work in
both directions.

If a railway route exists from City A to City B,
then the connection also exists from City B to City A.

A weighted graph stores additional information such
as distance or ticket fare on each edge.

5. OPERATIONS PERFORMED

A. Add Railway Route:

Creates a connection between two cities and stores
its cost in the adjacency matrix and adjacency list.

B. Check Direct Connection:

Checks whether a direct railway route exists between
two given cities.

C. Display Adjacency Matrix:

Displays all city connections in a two-dimensional
matrix format.

D. Display Adjacency List:

Displays all connected cities with their respective
route costs.

E. Display All Connections:

Displays all directly connected cities from a given
source city along with their costs.

6. WORKING OF THE PROGRAM

Step 1:
Accept the number of cities.

Step 2:
Enter the names of all cities.

Step 3:
Accept the number of railway routes.

Step 4:
Enter source city, destination city and route cost.

Step 5:
Store connections in adjacency matrix and adjacency list.

Step 6:
Display the menu.

Step 7:
Perform the selected operation.

Step 8:
Display the result.

Step 9:
Repeat until the user selects Exit.

7. TIME COMPLEXITY

Let:

V = Number of cities
E = Number of railway routes

1. Add Route:
   O(V + Degree of source city)

2. Check Direct Connection:
   O(V)

3. Display Adjacency Matrix:
   O(V^2)

4. Display Adjacency List:
   O(V + E)

5. Display Connections from a City:
   O(V + Degree of source city)

8. SPACE COMPLEXITY

Adjacency Matrix:
O(V^2)

Adjacency List:
O(V + E)

Overall Graph Storage:
O(V^2 + E)

9. APPLICATIONS

1. Railway reservation systems.
2. Railway route planning.
3. Transportation networks.
4. Ticket fare management.
5. Distance calculation between stations.
6. Network connectivity management.

10. ADVANTAGES

1. Represents railway connections clearly.
2. Stores distance or ticket fare.
3. Makes direct connection checking easy.
4. Supports multiple railway routes.
5. Adjacency List saves space for sparse graphs.

11. CONCLUSION

The Railway Network is successfully represented using
an Adjacency Matrix and Adjacency List.

The program checks direct railway connections and
displays all possible direct connections from a
given city along with their corresponding costs.

============================================================
                    END OF PROGRAM
============================================================
*/
