
/*
============================================================
                    PROBLEM STATEMENT
============================================================

7. Problem Statement:

Implement a menu-driven C++ program to manage a library's
book catalog using a Binary Search Tree, where each node
represents a Book ID.

After constructing the BST, perform the following:

i.   Insert a new book.
ii.  Delete a book from the catalog.
iii. Find the book with the smallest and largest Book ID.
iv.  Display all books in sorted (inorder) order.
v.   Count the total number of books and leaf nodes
     in the tree.

============================================================
                    C++ PROGRAM
============================================================
*/

#include <iostream>
using namespace std;

// Node Structure
struct Node
{
    int bookID;

    Node* left;
    Node* right;

    Node(int id)
    {
        bookID = id;
        left = right = NULL;
    }
};

// Binary Search Tree Class
class Library
{
    Node* root;

    // Insert Book
    Node* insert(Node* root, int id)
    {
        if(root == NULL)
            return new Node(id);

        if(id < root->bookID)
            root->left = insert(root->left, id);

        else if(id > root->bookID)
            root->right = insert(root->right, id);

        else
            cout << "Book ID already exists!\n";

        return root;
    }

    // Find Minimum Book ID
    Node* findMin(Node* root)
    {
        while(root != NULL && root->left != NULL)
            root = root->left;

        return root;
    }

    // Find Maximum Book ID
    Node* findMax(Node* root)
    {
        while(root != NULL && root->right != NULL)
            root = root->right;

        return root;
    }

    // Delete Book
    Node* deleteBook(Node* root, int id)
    {
        if(root == NULL)
            return NULL;

        if(id < root->bookID)
        {
            root->left = deleteBook(root->left, id);
        }
        else if(id > root->bookID)
        {
            root->right = deleteBook(root->right, id);
        }
        else
        {
            // Case 1: No child
            if(root->left == NULL &&
               root->right == NULL)
            {
                delete root;
                return NULL;
            }

            // Case 2: Only right child
            else if(root->left == NULL)
            {
                Node* temp = root->right;

                delete root;

                return temp;
            }

            // Case 2: Only left child
            else if(root->right == NULL)
            {
                Node* temp = root->left;

                delete root;

                return temp;
            }

            // Case 3: Two children
            Node* temp = findMin(root->right);

            root->bookID = temp->bookID;

            root->right = deleteBook(
                root->right, temp->bookID
            );
        }

        return root;
    }

    // Inorder Traversal
    void inorder(Node* root)
    {
        if(root == NULL)
            return;

        inorder(root->left);

        cout << root->bookID << " ";

        inorder(root->right);
    }

    // Count Total Books
    int countBooks(Node* root)
    {
        if(root == NULL)
            return 0;

        return 1 +
               countBooks(root->left) +
               countBooks(root->right);
    }

    // Count Leaf Nodes
    int countLeaf(Node* root)
    {
        if(root == NULL)
            return 0;

        if(root->left == NULL &&
           root->right == NULL)
            return 1;

        return countLeaf(root->left) +
               countLeaf(root->right);
    }

    // Search Book
    bool search(Node* root, int id)
    {
        if(root == NULL)
            return false;

        if(root->bookID == id)
            return true;

        if(id < root->bookID)
            return search(root->left, id);

        return search(root->right, id);
    }

    // Free Memory
    void destroy(Node* root)
    {
        if(root == NULL)
            return;

        destroy(root->left);
        destroy(root->right);

        delete root;
    }

public:

    // Constructor
    Library()
    {
        root = NULL;
    }

    // Insert New Book
    void insertBook(int id)
    {
        if(search(root, id))
        {
            cout << "Book ID already exists!\n";
            return;
        }

        root = insert(root, id);

        cout << "Book inserted successfully!\n";
    }

    // Delete Book
    void removeBook(int id)
    {
        if(!search(root, id))
        {
            cout << "Book not found!\n";
            return;
        }

        root = deleteBook(root, id);

        cout << "Book deleted successfully!\n";
    }

    // Display Minimum and Maximum
    void displayMinMax()
    {
        if(root == NULL)
        {
            cout << "Library catalog is empty!\n";
            return;
        }

        Node* minimum = findMin(root);
        Node* maximum = findMax(root);

        cout << "\nSmallest Book ID: "
             << minimum->bookID << endl;

        cout << "Largest Book ID: "
             << maximum->bookID << endl;
    }

    // Display Sorted Books
    void displayBooks()
    {
        if(root == NULL)
        {
            cout << "No books available!\n";
            return;
        }

        cout << "\nBooks in Sorted Order: ";

        inorder(root);

        cout << endl;
    }

    // Display Total Books
    void displayTotalBooks()
    {
        cout << "\nTotal Number of Books: "
             << countBooks(root) << endl;
    }

    // Display Leaf Nodes
    void displayLeafNodes()
    {
        cout << "Total Leaf Nodes: "
             << countLeaf(root) << endl;
    }

    // Destructor
    ~Library()
    {
        destroy(root);
    }
};


// Main Function
int main()
{
    Library lib;

    int n, id, choice;

    cout << "Enter number of existing books: ";
    cin >> n;

    if(n < 0)
    {
        cout << "Invalid number of books!\n";
        return 0;
    }

    // Construct Initial BST
    cout << "\nEnter Book IDs:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "Book " << i + 1 << ": ";
        cin >> id;

        lib.insertBook(id);
    }

    // Menu Driven Program
    do
    {
        cout << "\n========== LIBRARY MENU ==========\n";

        cout << "1. Insert New Book\n";
        cout << "2. Delete Book\n";
        cout << "3. Find Smallest and Largest Book ID\n";
        cout << "4. Display Books in Sorted Order\n";
        cout << "5. Count Total Books\n";
        cout << "6. Count Leaf Nodes\n";
        cout << "7. Display Both Counts\n";
        cout << "8. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter Book ID: ";
                cin >> id;

                lib.insertBook(id);
                break;

            case 2:
                cout << "Enter Book ID to delete: ";
                cin >> id;

                lib.removeBook(id);
                break;

            case 3:
                lib.displayMinMax();
                break;

            case 4:
                lib.displayBooks();
                break;

            case 5:
                lib.displayTotalBooks();
                break;

            case 6:
                lib.displayLeafNodes();
                break;

            case 7:
                lib.displayTotalBooks();
                lib.displayLeafNodes();
                break;

            case 8:
                cout << "Exiting Library System...\n";
                break;

            default:
                cout << "Invalid Choice! Try Again.\n";
        }

    } while(choice != 8);

    return 0;
}


/*
============================================================
                        THEORY
============================================================

1. INTRODUCTION

A Binary Search Tree (BST) is a non-linear data structure
used to store and search data efficiently.

In this program, each node represents a Book ID.

2. BST PROPERTY

A Binary Search Tree follows these rules:

- Left subtree contains smaller values.
- Right subtree contains greater values.
- Duplicate values are not allowed.

3. NODE STRUCTURE

Each node contains:

1. Book ID
2. Pointer to left child
3. Pointer to right child

4. OPERATIONS PERFORMED

A. INSERTION

Insert a new Book ID into the BST.

If the ID is smaller than the root, move left.

If the ID is greater than the root, move right.

Continue until an empty position is found.

B. DELETION

There are three cases:

Case 1: Leaf Node

Delete the node directly.

Case 2: One Child

Replace the node with its child.

Case 3: Two Children

Replace the node with its inorder successor
(smallest value in the right subtree).

Then delete the successor from its original position.

C. FIND SMALLEST BOOK ID

Move continuously towards the left child.

The leftmost node contains the smallest Book ID.

D. FIND LARGEST BOOK ID

Move continuously towards the right child.

The rightmost node contains the largest Book ID.

E. INORDER TRAVERSAL

Order:

Left -> Root -> Right

It displays all Book IDs in ascending order.

F. COUNT TOTAL BOOKS

Formula:

Total Books = 1 + Left Subtree + Right Subtree

G. COUNT LEAF NODES

A leaf node is a node that has no children.

Condition:

Left == NULL && Right == NULL

5. WORKING OF THE PROGRAM

Step 1:
Accept the number of existing books.

Step 2:
Enter Book IDs.

Step 3:
Construct the Binary Search Tree.

Step 4:
Display the menu.

Step 5:
Perform the selected operation.

Step 6:
Display the result.

Step 7:
Repeat until the user selects Exit.

6. TIME COMPLEXITY

Let n = Number of books.

Insertion:
Average: O(log n)
Worst: O(n)

Deletion:
Average: O(log n)
Worst: O(n)

Search:
Average: O(log n)
Worst: O(n)

Find Minimum:
Average: O(log n)
Worst: O(n)

Find Maximum:
Average: O(log n)
Worst: O(n)

Inorder Traversal:
O(n)

Count Total Books:
O(n)

Count Leaf Nodes:
O(n)

7. SPACE COMPLEXITY

BST Storage:
O(n)

Recursive Stack:
O(h)

Where h = Height of the BST.

Worst-case height = n.

8. APPLICATIONS

1. Library management systems.
2. Student record management.
3. Employee databases.
4. Searching and sorting.
5. Database indexing.

9. ADVANTAGES

1. Efficient searching.
2. Easy insertion and deletion.
3. Maintains sorted data.
4. Finds minimum and maximum values.
5. Supports dynamic data storage.

10. CONCLUSION

The Library Book Catalog Management System is
successfully implemented using a Binary Search Tree.

The program supports insertion, deletion, finding
minimum and maximum Book IDs, displaying books in
sorted order and counting total books and leaf nodes.

============================================================
                    END OF PROGRAM
============================================================
*/
