/* Assignment 3:- Expression tree: Write a menu driven C++ program to construct an expression tree
from the given prefix expression e.g. +--a*bc /def and perform following operations:
1.Traverse it using Inorder, Preorder and Post order traversal (recursive and nonrecursive)
2.Change a tree so that the roles of the left and right pointers are swapped at every node*/



#include <iostream>
#include <stack>
#include <string>
using namespace std;

struct node
{
    char data;
    node *left, *right;
};

// Create expression tree
node* create(string s)
{
    stack<node*> st;

    for(int i = s.length()-1; i >= 0; i--)
    {
        node* temp = new node;
        temp->data = s[i];
        temp->left = NULL;
        temp->right = NULL;

        if(s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
        {
            temp->left = st.top();
            st.pop();

            temp->right = st.top();
            st.pop();
        }

        st.push(temp);
    }

    return st.top();
}

// Inorder
void inorder(node* root)
{
    if(root != NULL)
    {
        inorder(root->left);
        cout << root->data;
        inorder(root->right);
    }
}

// Preorder
void preorder(node* root)
{
    if(root != NULL)
    {
        cout << root->data;
        preorder(root->left);
        preorder(root->right);
    }
}

// Postorder
void postorder(node* root)
{
    if(root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        cout << root->data;
    }
}

// Non-recursive inorder
void inorderNR(node* root)
{
    stack<node*> st;

    while(root != NULL || !st.empty())
    {
        while(root != NULL)
        {
            st.push(root);
            root = root->left;
        }

        root = st.top();
        st.pop();
        cout << root->data;
        root = root->right;
    }
}

// Non-recursive preorder
void preorderNR(node* root)
{
    if(root == NULL) return;

    stack<node*> st;
    st.push(root);

    while(!st.empty())
    {
        node* temp = st.top();
        st.pop();

        cout << temp->data;

        if(temp->right != NULL)
            st.push(temp->right);

        if(temp->left != NULL)
            st.push(temp->left);
    }
}

// Non-recursive postorder
void postorderNR(node* root)
{
    stack<node*> s1, s2;
    s1.push(root);

    while(!s1.empty())
    {
        node* temp = s1.top();
        s1.pop();

        s2.push(temp);

        if(temp->left != NULL)
            s1.push(temp->left);

        if(temp->right != NULL)
            s1.push(temp->right);
    }

    while(!s2.empty())
    {
        cout << s2.top()->data;
        s2.pop();
    }
}

// Swap left and right
void swapTree(node* root)
{
    if(root != NULL)
    {
        node* temp = root->left;
        root->left = root->right;
        root->right = temp;

        swapTree(root->left);
        swapTree(root->right);
    }
}

int main()
{
    node* root;
    string s;
    int ch;

    cout << "Enter prefix expression = ";
    cin >> s;

    root = create(s);

    do
    {
        cout << "\n======= MENU =======" << endl;
        cout << "1. Inorder Recursive" << endl;
        cout << "2. Preorder Recursive" << endl;
        cout << "3. Postorder Recursive" << endl;
        cout << "4. Inorder Non-Recursive" << endl;
        cout << "5. Preorder Non-Recursive" << endl;
        cout << "6. Postorder Non-Recursive" << endl;
        cout << "7. Swap left and right" << endl;
        cout << "8. Exit" << endl;

        cout << "Enter choice = ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                inorder(root);
                cout << endl;
                break;

            case 2:
                preorder(root);
                cout << endl;
                break;

            case 3:
                postorder(root);
                cout << endl;
                break;

            case 4:
                inorderNR(root);
                cout << endl;
                break;

            case 5:
                preorderNR(root);
                cout << endl;
                break;

            case 6:
                postorderNR(root);
                cout << endl;
                break;

            case 7:
                swapTree(root);
                cout << "Tree swapped successfully" << endl;
                break;

            case 8:
                cout << "Exiting..." << endl;
                break;

            default:
                cout << "Invalid choice" << endl;
        }

    } while(ch != 8);

    return 0;
}

/*Output :-
Enter prefix expression = +--a*bc/def

======= MENU =======
1. Inorder Recursive
2. Preorder Recursive
3. Postorder Recursive
4. Inorder Non-Recursive
5. Preorder Non-Recursive
6. Postorder Non-Recursive
7. Swap left and right
8. Exit

Enter choice = 1
a-b*c-d/e+f

Enter choice = 2
+--a*bc/def

Enter choice = 3
abc*-de/-f+

Enter choice = 4
a-b*c-d/e+f

Enter choice = 5
+--a*bc/def

Enter choice = 6
abc*-de/-f+

Enter choice = 7
Tree swapped successfully

Enter choice = 1
f+e/d-c*b-a

Enter choice = 8
Exiting...
*/
