/*Assignment 4:- A Dictionary using AVL: A Dictionary stores key and value pairs
Data: Set of (key, value) pairs, Keys are mapped to values, Keys must be comparable,
Keys must be unique.
Standard Operations: Insert (key, value), Find(key), Delete(key)
Write a menu driven C++ program to provide above standard operations on dictionaries
and provide a facility to display whole data sorted in ascending/ Descending order. Also
find how many maximum comparisons may require for finding any keyword.
Use Height balanced tree(AVL) and find the complexity for finding a keyword*/


#include <iostream>
#include <string>
using namespace std;

struct node
{
    string key, value;
    int h;
    node *left, *right;
};

int height(node* root)
{
    if(root == NULL)
        return 0;
    return root->h;
}

int max(int a, int b)
{
    return (a > b) ? a : b;
}

int balance(node* root)
{
    if(root == NULL)
        return 0;

    return height(root->left) - height(root->right);
}

// Right rotation
node* rightRotate(node* y)
{
    node* x = y->left;
    node* t = x->right;

    x->right = y;
    y->left = t;

    y->h = 1 + max(height(y->left), height(y->right));
    x->h = 1 + max(height(x->left), height(x->right));

    return x;
}

// Left rotation
node* leftRotate(node* x)
{
    node* y = x->right;
    node* t = y->left;

    y->left = x;
    x->right = t;

    x->h = 1 + max(height(x->left), height(x->right));
    y->h = 1 + max(height(y->left), height(y->right));

    return y;
}

// Insert
node* insert(node* root, string k, string v)
{
    if(root == NULL)
    {
        node* temp = new node;
        temp->key = k;
        temp->value = v;
        temp->h = 1;
        temp->left = temp->right = NULL;
        return temp;
    }

    if(k < root->key)
        root->left = insert(root->left, k, v);
    else if(k > root->key)
        root->right = insert(root->right, k, v);
    else
    {
        cout << "Duplicate keyword" << endl;
        return root;
    }

    root->h = 1 + max(height(root->left), height(root->right));

    int b = balance(root);

    if(b > 1 && k < root->left->key)
        return rightRotate(root);

    if(b < -1 && k > root->right->key)
        return leftRotate(root);

    if(b > 1 && k > root->left->key)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if(b < -1 && k < root->right->key)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// Search
node* search(node* root, string k)
{
    if(root == NULL || root->key == k)
        return root;

    if(k < root->key)
        return search(root->left, k);

    return search(root->right, k);
}

// Find minimum node
node* minimum(node* root)
{
    while(root->left != NULL)
        root = root->left;

    return root;
}

// Delete
node* del(node* root, string k)
{
    if(root == NULL)
        return root;

    if(k < root->key)
        root->left = del(root->left, k);

    else if(k > root->key)
        root->right = del(root->right, k);

    else
    {
        if(root->left == NULL || root->right == NULL)
        {
            node* temp = root->left ? root->left : root->right;

            if(temp == NULL)
            {
                delete root;
                return NULL;
            }

            *root = *temp;
            delete temp;
        }
        else
        {
            node* temp = minimum(root->right);

            root->key = temp->key;
            root->value = temp->value;

            root->right = del(root->right, temp->key);
        }
    }

    root->h = 1 + max(height(root->left), height(root->right));

    int b = balance(root);

    if(b > 1 && balance(root->left) >= 0)
        return rightRotate(root);

    if(b > 1 && balance(root->left) < 0)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if(b < -1 && balance(root->right) <= 0)
        return leftRotate(root);

    if(b < -1 && balance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// Ascending
void ascending(node* root)
{
    if(root != NULL)
    {
        ascending(root->left);
        cout << root->key << " : " << root->value << endl;
        ascending(root->right);
    }
}

// Descending
void descending(node* root)
{
    if(root != NULL)
    {
        descending(root->right);
        cout << root->key << " : " << root->value << endl;
        descending(root->left);
    }
}

int main()
{
    node* root = NULL;
    int ch;
    string k, v;

    do
    {
        cout << "\n===== DICTIONARY MENU =====" << endl;
        cout << "1. Insert" << endl;
        cout << "2. Search" << endl;
        cout << "3. Delete" << endl;
        cout << "4. Ascending order" << endl;
        cout << "5. Descending order" << endl;
        cout << "6. Maximum comparisons" << endl;
        cout << "7. Exit" << endl;

        cout << "Enter choice = ";
        cin >> ch;

        switch(ch)
        {
            case 1:
                cout << "Enter keyword = ";
                cin >> k;
                cout << "Enter value = ";
                cin >> v;
                root = insert(root, k, v);
                break;

            case 2:
                cout << "Enter keyword = ";
                cin >> k;

                if(search(root, k) != NULL)
                    cout << "value = " << search(root, k)->value << endl;
                else
                    cout << "Keyword not found" << endl;
                break;

            case 3:
                cout << "Enter keyword = ";
                cin >> k;

                if(search(root, k) == NULL)
                    cout << "Keyword not found" << endl;
                else
                {
                    root = del(root, k);
                    cout << "Keyword deleted" << endl;
                }
                break;

            case 4:
                ascending(root);
                break;

            case 5:
                descending(root);
                break;

            case 6:
                cout << "Maximum comparisons = " << height(root) << endl;
                cout << "Time complexity = O(log n)" << endl;
                break;

            case 7:
                cout << "Exiting..." << endl;
                break;

            default:
                cout << "Invalid choice" << endl;
        }

    } while(ch != 7);

    return 0;
}

/*Output:-
Enter choice = 1
Enter keyword = mango
Enter value = fruit

Enter choice = 1
Enter keyword = apple
Enter value = red

Enter choice = 1
Enter keyword = orange
Enter value = citrus

Enter choice = 1
Enter keyword = banana
Enter value = yellow

Enter choice = 1
Enter keyword = grapes
Enter value = small

Enter choice = 2
Enter keyword = apple
Meaning = red

Enter choice = 4

apple : red
banana : yellow
grapes : small
mango : fruit
orange : citrus

Enter choice = 5

orange : citrus
mango : fruit
grapes : small
banana : yellow
apple : red

Enter choice = 3
Enter keyword = apple
Keyword deleted

Enter choice = 4

banana : yellow
grapes : small
mango : fruit
orange : citrus

Enter choice = 6
Maximum comparisons = 3
Time complexity = O(log n)

Enter choice = 7
Exiting...

*/
