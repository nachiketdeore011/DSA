/* Assignment 1  :- Flight management: There are flight paths between cities. If there is a flight between
city A and city B, then there is an edge between the cities. The cost of the edge can be
the time that flight takes to reach city B from A, or the amount of fuel used for the
journey.
Write a menu driven C++ program to represent this as a graph using adjacency matrix
and adjacency list. The node can be represented by the airport name or name of the city.
Check whether cities are connected through flight or not. Compare the storage
representation.*/


#include <iostream>
#include <string>
using namespace std;

int main()
{
    int n;
    cout << "Enter a number of cities = ";
    cin >> n;

    string city[n];
    int a[n][n];
    int i, j;
    int ch;

    cout << "\nEnter city names = " << endl;

    for(i = 0; i < n; i++)
    {
        cout << "city " << i + 1 << " = ";
        cin >> city[i];
    }

    cout << "\nEnter the flight cost between the cities = " << endl;

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(i == j)
            {
                a[i][j] = 0;
            }
            else
            {
                cout << "cost between " << city[i]
                     << " -> " << city[j] << " = ";
                cin >> a[i][j];
            }
        }
    }

    do
    {
        cout << "\n==============MENU==================" << endl;
        cout << "1.Display Adjacency Matrix " << endl;
        cout << "2.Display Adjacency List" << endl;
        cout << "3.check direct flight" << endl;
        cout << "4.compare storage" << endl;
        cout << "5.exit" << endl;

        cout << "\nEnter your choice = ";
        cin >> ch;

        switch(ch)
        {
            case 1:
            {
                cout << "\n\t";

                for(i = 0; i < n; i++)
                {
                    cout << city[i] << "\t";
                }

                cout << endl;

                for(i = 0; i < n; i++)
                {
                    cout << city[i] << "\t";

                    for(j = 0; j < n; j++)
                    {
                        cout << a[i][j] << "\t";
                    }

                    cout << endl;
                }

                break;
            }

            case 2:
            {
                cout << "\nAdjacency List" << endl;

                for(i = 0; i < n; i++)
                {
                    cout << city[i] << " -> ";

                    for(j = 0; j < n; j++)
                    {
                        if(a[i][j] != 0)
                        {
                            cout << city[j] << "(" << a[i][j] << ") -> ";
                        }
                    }

                    cout << "NULL" << endl;
                }

                break;
            }

            case 3:
            {
                string src, des;
                int s = -1, d = -1;

                cout << "\nEnter source city = ";
                cin >> src;

                cout << "Enter destination city = ";
                cin >> des;

                for(i = 0; i < n; i++)
                {
                    if(city[i] == src)
                        s = i;

                    if(city[i] == des)
                        d = i;
                }

                if(s == -1 || d == -1)
                {
                    cout << "city not found" << endl;
                }
                else if(a[s][d] != 0)
                {
                    cout << "\ndirect flight available from "
                         << src << " to " << des
                         << " with cost = " << a[s][d] << endl;
                }
                else
                {
                    cout << "\ndirect flight not available from "
                         << src << " to " << des << endl;
                }

                break;
            }

            case 4:
            {
                int edge = 0;

                for(i = 0; i < n; i++)
                {
                    for(j = 0; j < n; j++)
                    {
                        if(a[i][j] != 0)
                        {
                            edge++;
                        }
                    }
                }

                cout << "\nNumber of cities = " << n << endl;
                cout << "Number of flights = " << edge << endl;
                cout << "Adjacency Matrix storage = " << n * n << endl;
                cout << "Adjacency List storage = " << n + edge << endl;

                if(edge < n * n)
                {
                    cout << "list uses less storage for sparse graph" << endl;
                }

                break;
            }

            case 5:
            {
                cout << "Exiting...." << endl;
                break;
            }

            default:
            {
                cout << "Invalid choice" << endl;
                break;
            }
        }

    } while(ch != 5);

    return 0;
}


/*Output :-

Enter a number of cities = 4

Enter city names =
city 1 = Nashik
city 2 = Mumbai
city 3 = Pune
city 4 = Delhi

Enter the flight cost between the cities =
cost between Nashik -> Mumbai = 2
cost between Nashik -> Pune = 0
cost between Nashik -> Delhi = 5

cost between Mumbai -> Nashik = 2
cost between Mumbai -> Pune = 3
cost between Mumbai -> Delhi = 0

cost between Pune -> Nashik = 0
cost between Pune -> Mumbai = 3
cost between Pune -> Delhi = 4

cost between Delhi -> Nashik = 5
cost between Delhi -> Mumbai = 0
cost between Delhi -> Pune = 4

==============MENU==================
1.Display Adjacency Matrix
2.Display Adjacency List
3.check direct flight
4.compare storage
5.exit

Enter your choice = 1

        Nashik  Mumbai  Pune    Delhi
Nashik    0       2       0       5
Mumbai    2       0       3       0
Pune      0       3       0       4
Delhi     5       0       4       0

Enter your choice = 2

Adjacency List

Nashik -> Mumbai(2) -> Delhi(5) -> NULL
Mumbai -> Nashik(2) -> Pune(3) -> NULL
Pune -> Mumbai(3) -> Delhi(4) -> NULL
Delhi -> Nashik(5) -> Pune(4) -> NULL

Enter your choice = 3

Enter source city = Nashik
Enter destination city = Mumbai

direct flight available from Nashik to Mumbai with cost = 2

Enter your choice = 3

Enter source city = Nashik
Enter destination city = Pune

direct flight not available from Nashik to Pune

Enter your choice = 4

Number of cities = 4
Number of flights = 8
Adjacency Matrix storage = 16
Adjacency List storage = 12

list uses less storage for sparse graph

Enter your choice = 8

Invalid choice

Enter your choice = 5

Exiting....
*/
